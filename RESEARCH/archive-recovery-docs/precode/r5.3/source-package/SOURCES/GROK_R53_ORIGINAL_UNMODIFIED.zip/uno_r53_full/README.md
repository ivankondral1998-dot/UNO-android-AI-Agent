# README — UNO R5.3 Full Candidate Package
**Статус:** PRECODE_CANDIDATE_READY_FOR_OWNER_REVIEW  
**НЕ OWNER_APPROVED_PRECODE**  
Дата: 2026-11-02

## Содержимое
- `SPEC/UNO_R53_FULL_NORMATIVE_SPECIFICATION.md` — полная нормативная спецификация с уравнениями, реестрами, доказательствами, контрпримерами и матрицами.
- Этот README — краткий указатель.

## Ключевые исправления
- \(c_M\) вместо безусловного 0.95.
- Memory modes + RetrieveExact.
- Dual-option WAKE/SENSOR.
- Явное разделение causal / receipt и STOP semantics.

## Открытые gates
См. раздел 12 спецификации.

Production-код не включён. Baseline не утверждён.
