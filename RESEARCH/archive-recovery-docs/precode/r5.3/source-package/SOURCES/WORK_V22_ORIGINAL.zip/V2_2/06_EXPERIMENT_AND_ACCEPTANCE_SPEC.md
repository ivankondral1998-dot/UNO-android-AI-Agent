# 06. Приёмочные эксперименты и источники платформенных границ (без запуска UNO)

## 1. Before any locked testing

Сначала owner-approved manifest: `taskJ / q_j / coverageMin_j / unsafeMax_j / successPredicate / oracle version / stratum / 95% familywise CI allocation / acceptable PSS / p95/p99 latency / J_per_task / idle energy / min device runtime / privacy+license / false-action bound / STOP latency limit`. Численные значения не назначаются автором, так как это решение владельца с привязкой к продукту/риску. Зафиксировать denominator на **всех issued tasks**; отдельно NOOP, CLARIFY, DENY, UNKNOWN, PERMISSION_BLOCKED.

Независимые splits: train, model-development, calibration, locked final. Разграничение на уровне speakers/users/sessions/app versions/task families/time; duplicate-audio and image near-dup block. NCR-EVO evaluation families отделены; при раскрытии locked labels H3 не использовать его повторно как свежий финальный тест после подгонки. Native action data include permission+consent provenance; no dangerous experimentation on third-party accounts.

## 2. Statistical certificates (mathematically exact for the assumptions)

If `n` iid Bernoulli unsafe-action exposures in fixed stratum show zero failures, exact one-sided upper probability bound `p_U=1−α_j^(1/n)`. Hypothetical familywise α_total=.05 split 10 ways; desired p_U≤.001 → `n≥5296` independent zero-failure exposures **for each** stratum. Numbers illustrate the sample consequences only; neither α allocation nor 0.001 are approved thresholds. Session-correlated frames do not count as independent trials. For task quality use paired evaluations, precommitted LCB per task and multiple comparison correction; confidence cannot be improved by hiding abstentions.

For NCR-EVO: fixed pool inclusion `p_i=1−(1−π_i)^B`; HT unbiased conditional on fixed labels/pool and known sampling probabilities (variance can explode). For paired D∈[−1,1], `LCB=mean(D)−sqrt(2ln(1/α)/n)`. In the illustrative example from V2.1 (α=.025, β=.2, delta=.05), sufficient distribution-free n=8138 independent matched units, not 8138 mutations. Enforce equal *total* CPU/joules/storage including search and surrogate.

## 3. A52 measurement record (real device required)

`deviceModel/Android/securityPatch/targetSdk/cpuGovernor/ambientTemp/batteryState/backend/toolchain/graphDigest/quantDigest`; benchmark FP32/FP16/INT8 exact shapes, audio DSP/STFT/GL, mixed load/idle. Record per-run actual MAC counted, sustained MAC/s, traffic bytes/s, measured p50/p95/p99 with trace, PSS incl. mmaps/staging, thermal curves over ≥30 min, per-10ms-frame deadline misses, wake false pos/neg and joules, network-offline. One short peak TOPS figure is not sufficient. For each verb, audit native readback or UNKNOWN and explicit user permission.

Model comparison report each candidate `(graphFamily,d,rank,quantClass,K/mask schedule, tokenizer/DSP, security version)` with identical heldout. Acceptance if **every** mandatory class passes quality/coverage/safety and resource caps and permissions; otherwise feasible set may be empty. Pareto choice only within feasible set; do not select LR64 by F MAC alone.

## 4. Android platform verification (official sources checked 2026-11-02)

- MediaProjection: for Android14+ user approval each capture session; token one-use. https://developer.android.com/media/grow/media-projection . Therefore cached consent token cannot authorize new sessions.
- FGS/while-in-use: https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start and https://developer.android.com/develop/background-work/services/fgs/service-types . `RECORD_AUDIO` being granted while app not visible does not by itself authorize starting a background microphone service. User visibility and exemptions must be evaluated at dispatch.
- Background activity launch restrictions: https://developer.android.com/guide/components/activities/secure-bal . Cannot assume any app can be launched unrestricted from background.
- KeyMint rollback-resistance semantics: https://source.android.com/docs/security/features/keystore/implementer-ref . `ROLLBACK_RESISTANCE` for key deletion protects against resurrecting deleted keys in supported hardware; **not** by itself a general monotonic trusted counter that prevents restoring an older valid application snapshot. Hardware feature/device attestation still needed, else SAFE_MODE under rollback threat.

These references constrain feasibility, do not verify the current Samsung A52 runtime permissions, targetSdk, active Android profile, policy compliance or actual app contracts.

## 5. Required oracle families

`O01–O14` source originals retained, `O15–O20` V2.1 preserved; add V2.2 audit obligations:

- `O21`: quantClass permutation e_tau FP32 vs INT8 and w_wake FP32 vs INT8, with distinct digests and byte-exact manifest.
- `O22`: LR64 rank≤128 combined h-directions cannot represent dense span129 example; no equality claim.
- `O23`: full output token budget for 128 words/tokens includes tied vocab, not just F/audio.
- `O24`: under STOP after dispatch, readback OBSERVED and P unchanged; restart twice and ensure no physical auto resend.
- `O25`: scripted 4-block PL permutations reproduce positive coverage for each 3-prefix and gradient FD.
- `O26`: modelVersion/P frozen, late task TRUE cannot produce P update; I pinned if still unresolved.
- `O27`: archived but valid MAC under rollback root without trusted freshness => SAFE_MODE.
- `O28`: external interference yields true predicate but attribution observational; no causal training label.

`O21–O28` are **specified tests**, not implemented Android/native or run end-to-end. Arithmetic simulation O21/O22/O23/O25 has been independently analyzed; only numerical oracle script O25 and tensor formula enumeration are executed.
