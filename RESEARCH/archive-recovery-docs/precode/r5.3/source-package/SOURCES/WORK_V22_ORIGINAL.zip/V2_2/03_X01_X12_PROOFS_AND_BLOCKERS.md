# 03. Дополнительные X01–X12: доказательства и блокеры

`P` математически доказано только внутри явно указанной модели; `C` условное доказательство; `R` конкретное опровержение сильной версии; `E/U` эмпирическое отсутствие данных/источника. X01–X12 из V2.1 сохранены под теми же идентификаторами.

## X01 — train/runtime mask support

**R (старый каталог)**: при `n_b=16`, бюджет допускает ровно q=3, runtime BudgetTop выбирает подмножество из трёх блоков. Каталог Work `{∅, singleton, full}` не содержит 3-block mask: вероятность 0. **P (новый sampler, structural support):** finite scores, T>0 дают π_PL(σ)>0 любой перестановке σ. RuntimeBuilder — детерминированная функция σ и допустимого бюджета; любая маска из image(RuntimeBuilder) имеет хотя бы одну σ с ненулевой π, поэтому её вероятность >0. Это точная конечная теорема, но только при **идентичном** builder/cost/reserve/tie train/runtime. В аудите численно перебраны все 4! перестановки и 4 различных 3-prefix sets. **E:** при T→0 вероятности редких масок практически нулевые; нужен measured training coverage, calibration and locked performance. X01 structural solution P/C; practical X01 не PASS.

## X02 — correct gradient through PL+K+wake

**P/C:** для `L(Θ,σ)` на конечном σ с параметр-независимыми dataset/cost decisions `∇ΣπL = Σπ(∇L+L∇logπ)`; baseline b(history) не зависит от sampled action, поэтому `E[b∇logπ]=0`. Факторизовать π для PL order×wake×halt при полном учёте зависимостей h/Θ. Аудит n4 finite differences по ranking совпал с exact score derivative (`abs diff<1e-9`). **Контрпример:** stop-gradient scheduler input z(Θ) теряет `∂logπ/∂z ∂z/∂Θ`, поэтому уже не полный gradient. **E:** device-backed sampler/estimator, stochastic variance, quality, feasible-set dependence не проверены. При K forced budget probability of forced stop =1; учитывать zero log gradient на forced branch.

## X03 — late physical effect after STOP

**C:** trusted op-log I не обнуляется вместе с pending D. STOP invalidates epoch for learning, not for read-only observation. `physicalStatus` может перейти UNKNOWN→OBSERVED poststate при позднем native readback, но `decisionStatus=CANCELLED` остаётся и P'=P. **Контрпример необходимости:** удалить I на STOP после side-effect dispatch → последующее физическое изменение остаётся без track/reconcile. **E:** live Android readback/provenance, permission after revoke and persistence не проверены.

## X04 — blind retry after ambiguous crash

**P (невозможность общего exactly-once локальной ОС):** H0 persist MAY_HAVE_SENT→crash до native call; H1 persist MAY_HAVE_SENT→native effect→crash. Локальный durable state одинаков, истинный эффект различен. Алгоритм, видящий только этот state, либо повторит обе истории (double effect в H1), либо не повторит обе (missing effect в H0). Нужны idempotent app-specific token/readback/reconcile или owner intervention; generic blind retry запрещён. **E:** перечень supported verbs/idempotency/readback не установлен.

## X05 — atomicity of online P and trusted evidence

**C:** если ledger and P blob фиксируются **одной** атомарной durable транзакцией при едином storage root, marker used и P' не расходятся после recovery. **R (без A_tx):** `write P' → crash → used-marker not written` приводит к double gradient при повторе; обратный порядок теряет gradient. Cross-file atomicity из «две записи в WAL» без общего commit protocol не следует. **E:** нужно проверить конкретные Android storage/backend semantics и rollback protection; X05 не PASSED.

## X06 — decoded norm + quant parity

**C:** после export проверять `max_i Σ_j |A_dequant[i,j]|≤a0` и аналогично для B; для факторов `(norm U)*(norm V)*norm B≤γ` достаточно для contraction fixed F. Если quant errors ограничены `εA,εB`, norm product ≤(a0+εA)(b0+εB), но такой bound не гарантирует quality. **Контрпример:** две близкие логитные величины по разные стороны typed argmax могут поменять действие при arbitrarily small quant perturbation. **E:** нет decoded weights, rare-action parity, calibration corpus or backend; не PASS.

## X07 — W1 versus LR64 tradeoff

**P:** exact 8 shape-derived param/MAC counts совпали с V2.1; LR64 существенно меньше F MAC. **R:** аналогичное/большее качество LR64 из числа параметров не следует; конкретный dense F с 129-мерным градиентным span не может быть точно выражен двумя rank64 branches (документ 01). **E:** WER, semantic task success, optimizer dynamics, energy/latency unknown. Arch choice UNRESOLVED.

## X08 — additional 128(d+1) in Astra figure

**P:** `55 451 639−55 320 439=131 200=128×1025`. **U:** то же число может быть суммой нескольких иных тензоров/изменённых shapes или совпадением; без manifest определить actual tensor identity невозможно. B2 128-output-head — гипотеза, не принятие конструкции.

## X09 — full 100 fps ASR path workload

**P:** при d1024,M4096,q16,K8 `3 522 560 +32 832 +8(17 301 504+1024)+131 104=142 106 720 MAC/frame`, то есть `14 210 672 000 MAC/s` при 100fps; для LR64 `4 983 203 200 MAC/s`. **R:** assertion «14.21G уже измерено на A52» ложно: это лишь модель стоимости при заданном планировщике. **E:** DSP/transfer/TTS/thermal/power unknown.

## X10 — NCR-EVO adaptive holdout isolation

**C:** locked H3 labels не доступны mutation/surrogate/early-stop loop; финальный кандидат frozen до единственного H3, после отказа новый H3/проверенный reusable-holdout protocol. Доказательство условно на control-plane isolation and no side-channel. **Контрпример:** многократный подбор гиперпараметров по результатам того же H3 делает его development set независимо от именования «locked». **E:** execution pipeline and leakage audit отсутствуют.

## X11 — Android verb legality, consent and readback

**S:** каждое разрешённое действие описать `verbId, version, precondition, ownerScope, consentDigest, targetSdk, OS API, foreground eligibility, permissionNow, idempotencyClass, independent readback, timeout, STOP behavior, UNKNOWN policy`. Verb ID capacity 128 не делает 128 доступных API. **Подтверждённые публичные Android ограничения:** при Android14+ MediaProjection требует согласия на **каждую** session/однократное использование token; микрофонные FGS и while-in-use permissions ограничивают создание службы из background, простой PermissionChecker недостаточен; background activity launch ограничен. Официальные URL и дата сверки — `06`. **E:** конкретное устройство/targetSdk/verb/support и права не исследованы.

## X12 — real newly trained weights, retention and full organism

**R:** формулы размерности, Lipschitz и конечности не означают успешное понимание русского, ASR, естественную речь, память/действия, continual learning или recovery. Нулевая инициализация или Θ=0 удовлетворяет многим norm constraints, но не задаёт нужную компетенцию — строгий контрпример достаточности чистой математики. **E:** нет легальных завершённых данных, trained weights, q_j, locked task results или forgetting curves; нет оснований одобрить full UNO.

## Итог X

| ID | Проверено | Полный статус |
|---|---|---|
|X01|R old; P/C full-support revised PL|E calibrated runtime quality|
|X02|P/C exact finite gradient under assumptions|E variance/backend|
|X03|C separation decision/physical|E trusted persisted device ledger|
|X04|P impossibility generic exactly-once|E app-specific readback/retry|
|X05|C atomicity theorem, R nontransaction|E backend and fresh anchor|
|X06|C norm certificates, R quality from norm|E quant weights/results|
|X07|P math; R equal expressivity|E quality/resources|
|X08|P delta arithmetic|U actual Astra registry|
|X09|P arithmetic|E physical device|
|X10|C holdout isolation protocol|E leakage audit|
|X11|S API-level verb contract|E permissions/readback policy|
|X12|R norm→quality implication|E model/data/locked tasks|

**X01–X12 все остаются НЕ полностью закрытыми** в смысле product acceptance. Теоремы X04 и отдельные арифметические части X07/X09 закрыты как математические утверждения; это не глобальный PASS системы.
