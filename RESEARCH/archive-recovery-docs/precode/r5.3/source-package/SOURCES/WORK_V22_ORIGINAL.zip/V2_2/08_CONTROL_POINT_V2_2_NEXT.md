# UNO V2.2 — ПРОВЕРЕННАЯ КОНТРОЛЬНАЯ ТОЧКА (НЕ PRE-CODE BASELINE)

**Дата:** 2026-11-02. **Вход:** неизменённый V2.1 ZIP (внутри V2/Work/Grok/NCR original). **Выход:** новые документы 00–08, независимый audit-only Python oracle, JSON фактически выполненного пересчёта, SHA-256 manifest.

## Проверенные на этой контрольной точке факты

1. 18 из 18 исходных элементов V2 проверены по оригинальным SHA256+bytes; отдельно проверен V2.1 manifest и исходный ZIP checksum.
2. Геометрия всех W1/LR64 тензоров отдельно перечислена для d512/d1024/d1536/d2048. **Все 8** totals P/F MAC совпали с V2.1. Факт не распространяется на реальную backend runtime layout.
3. Аудио d1024 full,K8,100Hz: W1 14 210 672 000 MAC/s, LR64 4 983 203 200 MAC/s — **оценка указанной схемы**, не тест устройства.
4. W1 d1024 55 320 439 params, LR64 43 786 103 params; LR64 F 5 767 168 vs W1 17 301 504 MAC/step; LR64 **не равно выразителен W1**: приведён span129 mathematical counterexample.
5. INT8 `quantClass` не задан явно для e_tau и w_wake; прежний файл-size справедлив только при одной определённой политике. Это исправление контракта, не изменение прошлой математики параметров.
6. Старая `C_mask` опровергнута q3-контрпримером. Обновлённый PL sampler имеет формально полный finite support на image runtime feasible builder при positive T; small n=4 4! test и FD gradient-check PASS. На практике quality/variance не проверены.
7. Потенциально отправленные OS effects нельзя автоматически отменить или exactly-once восстановить локально после crash. Need I/UNKNOWN/readback; STOP and online learning separated.
8. В математическом budget текста при 128 tokens требуется 4.294967296 млрд MAC только на tied output projection, с K8 full F ещё до 22.011707392 млрд MAC. Не смешивать с ASR FPS.
9. NCR-EVO fixed-pool HT and E2 bound are conditional statistical identities, not demonstrated evolution/speedup. Illustrative E2 n=8138 independent matched units.
10. 22 обязательства D/X имеют отдельные proof/counterexample/blocker rows; **ни одно D01–D10 не имеет полного empirical PASS**.

## Незакрытые вопросы — точные входы и критерии

|Blocking ID|What is missing|Exact closure artifact/criterion|
|---|---|---|
|B01 owner acceptance|q_j,c_j,f_j per task stratum, p95/p99, energy and RAM caps, significance allocation|owner-approved immutable `acceptance_plan` with units/denominators|
|B02 legal data|RU speech/text screen/TTS/action/memory datasets, consent and licensing|signed/hash verified dataset manifests + train/dev/cal/H3 contamination audit|
|B03 trained new Θ|full trained weights and gradient coverage of all tensorIds + replay retention|training hashes+run log+tensor targets+locked task metrics; P separate|
|B04 quant ABI|explicit e_tau/w_wake quantClass, kernel packing, scales, rounding and norm certificate|unambiguous owner-reviewed versioned ABI + decoded norm/parser oracle|
|B05 model selection|quality/efficiency W1 vs LR64 at several d|same locked tasks and thermal energy metrics; feasible Pareto set|
|B06 A52 resources|MAC throughput, DSP latency, PSS, energy, sustained thermal, wake and TTS|repeatable physical traces, offline environment, sustained p99 and cap review|
|B07 Android verbs|per-verb native APIs, permissions, readback fidelity, idempotency, foreground constraints|capability table on actual targetSdk/device + native test traces|
|B08 trust and storage|A_cap/A_tx/A_fs/A_gen and STOP dispatch serialization incl rollback threat model|trusted anchor decision; crash/rollback/STOP stress tests, else SAFE_MODE narrower guarantee|
|B09 memory/retention|migration tested with raw provenance, verified ledger quotas, expiry and re-key quality|repro tests, retention outcomes, safe unresolved I saturation|
|B10 NCR-EVO|isolated sandbox, pre-registered equal budget comparison, H3 not leaked|sandbox security audit + independent matched trials with multiplicity|
|B11 external review|independent reviewer of complete V2.2 and any later Astra|signed/hashed row-by-row critique; address new findings|
|B12 Astra registry|actual result not proven available|separate hashed ASTRA output and fully independent integration check; NOT required to continue other blockers|
|B13 TTS/ASR/screen success|independent linguistic and UI ground truth, real device capture|stratified WER/CER/intelligibility/grounding results, rights verified|
|B14 toolchain/release|lockfile, toolchain, SBOM, offline audit, build/integration tests|only after explicit owner authorization to proceed to code|

## Gating verdict

- `G0`: not passed — owner numerical acceptance definitions incomplete.
- `G1`: conditional mathematical subclaims, with explicitly refuted universal claims; no formal overall PASS.
- `G2`: not passed — D01–D10 have empirical/ABI blockers.
- `G3`: not passed — no trained full Θ/locked capability tests/physical A52 measurements.
- `G4`: **NOT AUTHORISED**. The owner has explicitly reserved final PRE-CODE BASELINE decision.
- `G5/G6`: not attempted; no APK or production work.

## Preservation and next safe starting point

Read `00_READ_FIRST_AND_SCOPE.md`, `08_CONTROL_POINT_V2_2_NEXT.md`, and then `01`–`07`, audit script/JSON and SHA manifest. `SOURCE_V2_1_UNMODIFIED.zip` is original V2.1 including entire V2; do not delete/modify its nested Work originals. New direct work should target B01–B14 only; avoid rewriting already proven source derivations. If sufficient data are unavailable, the result is `EMPIRICAL_BLOCK`, not plan disguised as completion. 

Production UNO code, trained assets, Android APK, repos, GitHub Actions and originals **not** modified or created here. The only `.py` is an audit-only tensor enumeration/finite probability checker.
