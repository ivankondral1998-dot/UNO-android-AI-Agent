# 05. Adversarial re-audit V2.1→V2.2; old claims preserved

## Матрица первичных M01–M44 (исторические статусы НЕ пересмотрены ретроспективно)

Эти статусы относятся к Work v1.1, не к утверждённому продукту. `P` локальный математический PASS; `C` условный PASS; `R` отвергнуто; `D` REQUIRES_DATA; `U` UNDETERMINED. Не переносить на обновлённые X/D без новых доказательств.

|IDs|Original|V2.2 reevaluation / scope guard|
|---|---|---|
|M01,M02,M03|P,P,P|separation/types/original brief preserved|
|M04|C|external kernel remains unknown|
|M05,M06|P,P|W1 validated via explicit tensor enumeration; INT8 quant ABI ambiguous|
|M07,M08,M09|D,U,D|quality d*, new Θ unmeasured|
|M10|P|old weights not inherited|
|M11,M12,M13|C,P,P|δ needs trusted I; shapes/boundedness demonstrated|
|M14,M15,M16,M17,M18|R,C,R,C,R|no universal convergence; only fixed F and fair masks|
|M19,M20,M21,M22|P,C,D,P|event arithmetic; physical energy needs c_i verification|
|M23,M24,M25,M26,M27,M28,M29|C,C,R,C,R,C,D|gate, STOP, rollback only under strong trust assumptions|
|M30,M31,M32|P,P,R|UNKNOWN not false; model text not receipt; receipt not causality|
|M33,M34,M35,M36|C,P,C,R|gradient formula conditional; old train catalogue support refuted|
|M37,M38|C,P|finite quota/control coverage; no success denominator tricks|
|M39,M40,M41,M42,M43,M44|P,C,D,C,R,P|NCR analytic proof; not validated deployed regeneration|

Counts preserved: **16 P,14 C,8 R,5 D,1 U** =44. This is a historical audit matrix, not 30 runnable tests. V2.2 provides eight arithmetic registry checks plus finite small-n PL derivative oracle; it does not execute Work O01–O20 Android tests.

## Новые/усиленные findings

|Ref|Finding|Verdict|Corrective contract / remaining proof|
|---|---|---|---|
|V22-F01|W1 tensors/W1 F and LR64 shape enumeration agree with source calculations for four d|P arithmetic|actual runtime ops/kernel unverified|
|V22-F02|Quant storage partition of `e_tau` and `w_wake` ambiguous in natural-language ABI; legacy arithmetic encodes policy decisions not declared as quantClass|S gap / R universal file-size interpretation|make quantClass explicit and canonical; recalc packed bytes|
|V22-F03|LR64 exactly as expressive as dense W1|R, rank/gradient-span129 counterexample|do not adopt by MAC alone; matched heldout|
|V22-F04|Full 128-token output can be evaluated using ASR 14.21G MAC/s budget alone|R, different task path|account tied V-head 4.295G MAC + full F up to 17.717G MAC for 128 tokens|
|V22-F05|Positive PL support implies bounded regret or low-variance gradient|R|temperature/loss calibration and sample estimates|
|V22-F06|Proof `STOP` cancels already-sent side effects|R (H0/H1)|persist I; reconcile read-only; disclose UNKNOWN|
|V22-F07|Verified predicate=true gives causal action credit|R (third-party interference)|store attribution separately, P models post-attempt outcome only|
|V22-F08|A valid hash/MAC always implies newest checkpoint|R (rollback)|trusted epoch anchor or SAFE_MODE|
|V22-F09|All 128 model action slots imply callable Android verbs|R|per-verb signed policy + native API proof|
|V22-F10|Device 100fps achieved when theoretical workload finite|R|effective sustained throughput + DSP and thermal checks|
|V22-F11|CTC/spectral/goal loss guarantees user's requested full capabilities|R|trained Θ and independent heldout for each modality|
|V22-F12|Fixed pool HT conditional estimator applies to adaptive reuse of test labels|R|freeze independent family/pool and single-use locked test|

## Quant ambiguity detail

Two valid ways to encode `e_tau` coexist: as six small FP32 embedding rows (`Pvec+=6d`) or as INT8 matrix with six FP32 scales (`Rows+=6`). Their difference in bytes is `18d−24`. Independently `w_wake` length 32 may be FP32 vector instead of `1×32` INT8 row: difference `+92` bytes. Neither affects W1 P or F MAC. Original `B_int8` is *conditionally* correct for `e_tau:FP32`, `w_wake:INT8_ROW`. The original claims that every matrix is quantized can only be read consistently if `e_tau` is explicitly excluded, despite its 2D shape. **No physical correction of existing weights is performed**; future ABI must resolve both before export.

## Mathematical proof obligations no longer worth redoing without evidence

- T3 is a fixed-F contraction theorem, not general adaptive runtime convergence. It is already proved given decoded norm bounds; hardware norms remain missing.
- L2 is a local **per-example** descent inequality with denominator epsilon+||h||², not retention guarantee.
- θ sum/geometry are independent of whether any training succeeded.
- No finite-data theorem can force all original tasks to be solved by a particular Θ size without specifying data distribution/target complexity.

## Conditions for a credible external audit

Reviewer should receive the nested original archives and the **entire** V2.2, run source SHA audit, independently enumerate model tensors and at least one LR64 expression counterexample, attempt alternative crashed-OS interleavings, audit PL support builder and sample finite gradient, enumerate actual Android verbs on target device, examine statistical independent sampling and negative outcomes. Merely reporting 30 old PASS or using the same equations without source review is insufficient.

**Consolidated verdict:** FORMAL SUBCLAIMS P/C, **NOT READY for PRE-CODE BASELINE**. No G4 approval.
