# 04. Динамика полного UNO: инварианты на границах подсистем

## 1. Один neural organism, разные уровни доверия

Математическое состояние `(world w, unified neural S, trusted T, reactor R)` дополняется ledger I **внутри T**, не новой когнитивной нейросетью. Общая Θ/F используется текстом, аудио, зрением, сенсорами, goal-logic, retrieval и генерацией, состояние s и owner-goal g версионируются. Android OS — внешний actuator/readback на отдельном trust boundary. NCR-EVO — внешний эксперимент с immutable policy/verifier, не runtime self-rewriting. CELL/PMB/старые Jarvis weights отсутствуют; сеть/облако отсутствуют в целевом runtime. Отдельная OS authority необходима и не противоречит отсутствию интеллектуальных мостов.

## 2. Согласованные поля и редуцированный переход

`State=(v,ν,e,STOP, s,g,β,M,P, D,I,Q, modelRoot, schemaRoot, permissionState, eventQueue)`.

При `OBSERVATION`: validate→admit→encode→memory read→F(K,q)→heads/proposal. Neural confidence / policy P не повышают capability. При authorization: exact schema/predicate/owner/ref/confirmation → durable MAY_HAVE_SENT → native call → async result → independent fresh readback → verify taskPredicate and attribution separately → compare freshness/epoch → commit P only when valid; write OBSERVED separately from P when late/cancelled. STOP, restart, revoke and deadline invalidate old work; I remains until reconciled/unknown preserved. Cross-version M re-key or quarantine. No task completion solely from model text or from dispatchReceipt.

## 3. Проверяемые условия перехода

- **INV-1 type:** `(x,Θ,Γ,manifest)` must have matching schema, fixed shapes, finite numbers, reserved nonces. Invalid input leads bounded INVALID, not an untyped action.
- **INV-2 bounded state:** `||s||∞≤1`, `||g||∞≤1`, `||P_a||₂≤pmax`, bounded M/Q/D/I/queue; proof by tanh, convex leaky update, row projection and quotas. This **does not** imply correct semantic output.
- **INV-3 monotonic authorization:** the model cannot widen owner-intent or permission. Gate accepts only exact intersection of current ownerScope and current OS eligibility. Adding a goal changes no authority.
- **INV-4 STOP:** latch linearization happens before any later dispatch linearization; already initiated native effects remain unresolved obligations. This needs trusted serialization and correct platform behavior; it is conditional.
- **INV-5 no stale training:** on STOP/epoch/ν/v mismatch or unknown evidence, `P'=P`. Task readback is not erased and cannot become a fresh ticket.
- **INV-6 storage:** after restart all old tickets invalidated; untrusted snapshot cannot restore authority. If fresh epoch cannot be established, remain SAFE_MODE. Authenticated root ≠ secure nonrollback freshness.
- **INV-7 memory provenance:** no stored natural-language assertion can produce its own trusted OS receipt; stale embeddings quarantined or re-keyed via authorized raw input.
- **INV-8 learning:** θ offline training only under new immutable datasets and heldout; P online update only after fresh trusted task outcome, no causal claims from observational true.
- **INV-9 lab containment:** NCR changes candidates AST/Θ_lab/archives only, not Θ_deployed, T, ownerScope, STOP or production release without promotion review.
- **INV-10 energy:** when work budget exhausted, deny additional neural work but preserve independent STOP control reserve. Formal reserve != verified Android scheduler latency.

## 4. Adversarial interleavings

| Case | Sequence | Required result | Proof class |
|---|---|---|---|
|A|STOP before authorize|no ticket/dispatch; neural work stops|C with atomic latch|
|B|STOP after durable MAY_HAVE_SENT, before native effect|no blind retry, I UNKNOWN; restart cannot assume none|P impossibility of inference|
|C|STOP while in-flight OS call|may finish physically, I persists; no stale P|C|
|D|TRUE readback after deadline|OBSERVED only when fresh readback; task not learned|C|
|E|replay TRUE twice|at most one P commit if A_tx|C; non-A_tx counterexample|
|F|permission revoked during readback|UNKNOWN, not FALSE or TRUE; pinned I until policy|C|
|G|checkpoint rollback with valid hash|SAFE_MODE absent fresh trusted generation anchor|P counterexample to hash-only freshness|
|H|third-party changes volume before receipt|postpredicate TRUE; attribution UNKNOWN/OBSERVATIONAL|P counterexample to causal inference|
|I|model-version changed after dispatch|incompatible P ticket blocked, provenance retained|C|
|J|NCR candidate attempts gate access|sandbox deny; abort experiment on escape|C until penetration-test|
|K|budget quota full with unresolved I|new dispatch denied, older op tracking retained|C|
|L|heavy ASR loop saturates CPU|STOP responds only if independent preemption scheduling works|E; bounded K is not real-time|

## 5. Dependency proof graph

`shape valid` → `matmul defined` → `F bounded`; `decoded norm + static z/Θ + fair block coverage` → `fixed-F contraction` (not cognitive convergence). `trusted permission+intent+epoch+native API` → `dispatch allowed`. `durable I + isolated STOP` → `known/UNKNOWN eventual reconciliation` (not guaranteed successful completion). `fresh independent readback + unused ticket + A_tx` → `one online P update`. `training data+trainability+heldout+device` → **future empirical ability**, never inferred from earlier arrows. `NCR safety sandbox + owner promotion` → **possible** improvement candidates, not auto self-regeneration.

## 6. Non-theorems and hard limits

No universal OS exactly-once; no guaranteed intervention after STOP; no Android API reachability implied by 128 verb logits; no universal perfect memory/regeneration without original information; no future-task zero forgetting; no privacy/trust guarantee from plain file hashes; no 100fps real-time certificate from MAC counts; no demonstrated Russian TTS from magnitude-only spectral loss. Any of these affirmative claims should be rejected by a later reviewer.
