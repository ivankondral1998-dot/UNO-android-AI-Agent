# 07. Astra: статус и процедура возможного включения

На 2026-11-02 в переданном `SOURCE_V2_1_UNMODIFIED.zip` лежат `ASTRA_INPUT_NOT_OUTPUT.zip` и косвенные промежуточные сведения (55 451 639 параметров при d1024; 14.21G MAC/s full audio). **Финальный output Astra со своими проверяемыми tensor tables, вычислениями, proofs и audit не входит в исходный V2.1.** Доступ к запущенной Work-задаче этой контрольной точки не подтверждён; считать её completed/in-progress/current в серверном смысле нельзя.

Если позже появится реальный `ASTRA_RESULT...`:

1. Сохранить **неизменённым** отдельным входом, SHA256/bytes/source provenance и дату получения; не заменять старые исходники.
2. Сверить source SHA внутри Astra с оригиналами Work mandate и NCR brief; обнаруженное несовпадение явно отметить.
3. Построить её complete tensor-registry с shapes/alias/strides, operator graph и quantClass; не вывести назначение тензора только из разности P.
4. По каждому утверждению на сопоставимых единицах проверить W1/Astra params, F/audio/text MAC, K/mask, P adaptation, storage/Android STOP, learned labels и per-verbs.
5. Проверить original and V2.2 counterexamples (H0/H1, PL q3, LR64 span129, rollback, causal receipt, magnitude speech) и новые ошибки.
6. Выпустить независимую `ASTRA_COMPARISON` с `ACCEPT / REJECT / UNVERIFIED` **по каждому** результату, а не единственным общим PASS.

Данная работа не ждёт Astra и ни одну собственную поправку не приписывает её авторству.
