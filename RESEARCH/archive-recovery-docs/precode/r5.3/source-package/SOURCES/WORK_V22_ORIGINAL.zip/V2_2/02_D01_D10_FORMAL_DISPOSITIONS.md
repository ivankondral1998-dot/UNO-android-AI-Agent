# 02. D01–D10 — формальное решение, доказательство, фальсификатор и точный остаток

**Правило:** «описана методика» не тождественно «обязательство закрыто». Для каждого D ниже различаются решённая математическая часть и эмпирический блокер. Преемственность V2.1 сохранена.

## D01: Полная task battery — S / E

**Формальное решение:** задача j задаётся кортежем `J_j=(input stratum, permitted action space, original owner predicate, independent label source, success/abstain/unsafe classifiers, resource measurement, confidence procedure, owner thresholds q_j,c_j,f_j)`. Нельзя заменить 13 классов RU-TEXT/RU-ASR/WAKE/RU-TTS/SCREEN/SENSOR/GOALS/PLANNING/ACTION/MEMORY/ADAPTATION/RESOURCE/OFFLINE-SECURITY одной перплексией. Для каждого выпуска вычислять LCB(success_j), LCB(coverage_j), UCB(false action_j) по заранее определённому знаменателю **всех выданных задач** и множительной поправке на сравнения.

**Доказательство отрицательного вывода:** два агента с одинаковым text perplexity могут иметь разную вероятность точных OS-последствий (модель мира и permissions отличаются). Следовательно language loss не сертификат D01. **Точный блокер:** независимые метки, q/c/f, распределение задач, согласие, правомерный корпус, объём independent trials отсутствуют. Нет D01 PASS.

## D02: Веса, оператор, tensor/graph ABI — P для геометрии; S/E для реального ABI

**Формальное решение:** перечислены уникальные ordered tensorIds, dtype, shape, role, alias и train-target. `E_text` tied text-output — одна storage identity. W1 и LR64 имеют разные `graphFamily`/tensorId set/modelDigest. Дополнительное поле **обязательно**: `quantClass` для e_tau (шесть FP32-векторов либо 2D INT8_ROW) и w_wake (FP32_VECTOR либо INT8_ROW 1×32), storage vs logical shape, scale/zero policy; без него прежний INT8 count неоднозначен. Model loader должен удостоверить dimension equality каждого matmul, finite params, device backend capability, model/graph/tokenizer/feature/action/quant hash, norm certificate **после dequant**. Формально `P=sum_i prod(shape_i)` и `C_F=sum_matmul prod(shape_i)`; восьмикратный независимый подсчёт завершён.

**Доказательство/контрпример:** W1/LR64 размерности совпадают; равная выразительность LR64 опровергнута функцией с градиентным span129 (документ 01). **Блокер:** backend layout, полнота Astra revised registry, согласование quantClass, численная устойчивость на runtime и решение владельца об ABI. Нет D02 deploy PASS.

## D03: Offline training полного Θ, online P, scheduler — P/C для градиентов; S/E для обучения

**Формальное решение:** независимый лицензированный loss и gradient pathway для *каждого* tensorId; при m_j=0 отсутствующий ground truth **не заменяется pseudo-label**. Текст, RU-audio, speech synthesis, screen grounding, native action supervision, memory/goal/state, wake/risk/conf/halt и scheduler требуют собственных классов обучающих данных. PL sampler по конечным перестановкам + идентичный RuntimeBudgetBuilder устраняет **structural** zero-support gap; estimator ∇E[L]=E[∇L + (L-b)∇logπ] при параметрически независимых внешних данных, конечных costs, полном pathwise gradient и baseline, не зависящем от sample.

**Доказательство:** конечная сумма `Σσ πΘ(σ)LΘ(σ)` дифференцируется покомпонентно; `∇π=π∇logπ`. Exhaustive n=4 проверка и FD score-gradient в JSON. Нормализованный logistic online P имеет Hessian ≤.25+λ и bounded projected descent при fresh target (Work L2). **Блокер:** данные и права, coverage gradients на фактическом backend, variance, целевые качества, retrain после quant, стоимость. Ни одного trained Θ. D03 training PASS отсутствует.

## D04: Память, версии и persistence — C / E

**Формальное решение:** `M` = недоверенные индексируемые эпизоды, `L/I` = отдельный trusted source-of-truth и in-flight physical obligation, `U` = гипотезы. `P` — быстрые параметры, не privileged state. Запись использует `recordDigest, sourceRef, featureDigest, modelVersion, payloadRef, expiry, trustClass`; reader проверяет root и не повышает trust по семантическому содержанию. Для change modelVersion: валидированное re-encode через новый W_k/W_v при доступном raw и consent, иначе quarantine (не использовать stale embedding как актуальный). Unresolved I pinned до trusted reconcile; при переполнении новые dispatch DENY, а не silent discard.

**Доказательство:** если сырой источник недоступен, два исходных raw с одинаковым старым lossy embedding могут давать разные новые embedding, поэтому точная migration невыводима без raw. **Блокер:** Android disk atomicity/rollback/freshness, key custody, quotas under crash, контроль retention на собственных задачах. D04 storage PASS отсутствует.

## D05: Android authority, OwnerGate, STOP и effect ledger — C, некоторые запреты P; E для ОС

**Формальное решение:** typed proposal — предложение без полномочий. Dispatch может начинаться только при `allow=ownerIntent ∧ schemaDigest ∧ digest(args) ∧ permissionNow ∧ foregroundEligibility ∧ ¬STOP ∧ epochFresh ∧ nonceUnused ∧ prestateValid ∧ confirmationIfRequired`. На критической границе проверка и регистрация действия сериализуются с STOP-latch; до native call persisted MAY_HAVE_SENT; после crash **не повторять автоматически**. `decisionStatus` и `physicalStatus` независимы; поздний readback после STOP может сохранить observed poststate без обучения P.

**Доказательство:** при A_cap+A_tx+A_gen и сериализации STOP/dispatch, индукция по разрешённым transitions исключает new dispatch после STOP linearization; не запрещает уже запущенный effect. Истории H0/H1 с одинаковым MAY_HAVE_SENT дают no-local-exactly-once counterexample. **Блокер:** per-verb реальный API, runtime permissions, доступные readbacks, atomic WAL/epoch anchor, threat model, независимая проверка пользователя/consent и targetSdk. Универсальное Android authority не доказано.

## D06: Восприятие, речь, генерация и расписание — P/S геометрии; E качества

**Формальное решение:** единый F принимает TEXT/AUDIO/IMAGE/SENSOR/OS признаки и выдаёт text/CTC/speech/typed proposal, через M, s, goal и отдельных trusted gate. 16kHz PCM→hop160→100 кадр/s log-mel80→F/CTC128; vision RGB patch16×16×3→W_image, последовательный screen grounding; speech 257 magnitudes+stop и bounded GL DSP; token output tied E_text. Каждый pipeline bounded frames/tokens/work/cost; отсутствие permissions, privacy-screen или failure STFT → UNKNOWN/ABSTAIN, не self-declared observation.

**Контрпример достаточности:** совпадение target STFT magnitude не определяет единственную фазу waveform: разные сигналы имеют одинаковую/близкую magnitude; intelligibility не выводится из L_spec. **Блокер:** RU-ASR WER, TTS слушательский тест, CTC temporal quality, wake/privacy, image grounding, real-time Android, energy. D06 не PASS.

## D07: Ресурсные сертификаты — P арифметика; E физическая осуществимость

**Формальное решение:** `reserve(control,stop,verification)` перед admission, `Σ certifiedCost_primitive ≤ taskBudget` по каждой размерности квот при условии действительно верхних c_i; compute K≤8, q≤n_b. Проверять frame pipeline cost (doc01), vector resource `(MAC, moved bytes, joules, PSS, p99 latency, thermals, storage)`. Для неперекрываемых стадий `latency ≥ max(MAC/μ_MAC, bytes/μ_BW)+fixedDSP+OS`; это **нижняя**, не верхняя граница. Hard time/energy test требует фактический upper-tail, а не roofline theory.

**Доказательство:** индукция по недоиспользованным остаткам гарантирует списанные сертифицированные quotas; если с_i не являются реальными worst-case, гарантия теряется. **Блокер:** μ, workspace, thermal derating, PSS, mic windows, latency, drain on A52 и owner caps. D07 не PASS.

## D08: NCR-EVO — P/C статистическая идентичность; E эффективность

**Формальное решение:** внешняя изолированная лаборатория: fixed `G_const`, bounded typed AST, cheap model `S_φ`, rare/novelty acquisition, independent deep evaluator, MAP-Elites archive, owner-only promotion. Для fixed candidate pool inclusion `p_i=1−(1−π_i)^B`, HT estimator `1/N Σ I_iℓ_i/p_i` несмещён для фиксированной finite population conditional on selection history/known π_i. Explicit cost all-in includes mutate, surrogate, deep, calibrate, archive and machine resource; paired independent task family blocks, locked heldout sealed.

**Контрпример:** при tiny p_i>0 variance HT может быть сколь угодно большой; clipping вносит смещение; при адаптивном reuse locked labels ошибочно снижается uncertainty. **Блокер:** sandbox security verification, законные experimental data, независимые replicated outcomes, superiority under equal total energy/compute. D08 не PASS.

## D09: Предкодовая artifact graph и ABI BOM — S / E

**Формальное решение:** manifest dependency DAG требует `task thresholds → data+split+source → geometry+tokenizer+DSP → train spec → weights FP32 → quant exports → independent oracles → Android legal/gate backend → device benchmark → locked review → separate owner approval`. Все производные артефакты content-addressed, canonical length/dtype/hash and schemaVersion; unknown required field FAIL-closed. Old Θ and new P/tickets не загружаются cross-version без explicit migration. Лицензии и source digests входят в подписанный release root, приватные ключи не распространяются.

**Доказательство:** топологический порядок конечного DAG исключает использование несуществующего обязательного предшественника, если checker реализован failclosed; не доказывает качество самих артефактов. **Блокер:** версии toolchain, crypto trust root, device packers, BOM dependencies, SBOM, actual weights. D09 не PASS.

## D10: Threat model и release stop — S/E

**Формальное решение:** нельзя release при любом unauthorized dispatch, replay applied as fresh, unresolved I silently dropped, mandatory STOP bypass, task coverage below approved minimum, uncertified quant-norm, legal rights unknown, offline dependency, or elevated false-action risk. Отдельно контролировать semantics/consent, stored-data privacy, third-party UI limitations, OS callback races, rollback, thermal, false confidence, adaptively overfit evaluations.

**Контрпример:** даже криптографически подлинный ранее сохранённый snapshot может быть rollback; MAC проверяет подлинность, не свежесть, если нет trusted nonrollback counter. **Блокер:** утверждение владельцем норм и угроз, независимый security audit, per-verb capability validation, фактические rate estimates. D10 не PASS.

## Матрица итогового закрытия D

| ID | Формально решённая часть | Текущее состояние полного обязательства |
|---|---|---|
|D01|Определён независимый task/metric contract|E: нет q,c,f и выборок|
|D02|P: реестр и MAC; R: LR64 expressive equality; исправлен ABI gap|S/E: ABI не закреплён|
|D03|C: градиент, masks, training flow|E: нет обученных весов/labels|
|D04|C: migrate, source/trust/ledger|E: persistence+retention|
|D05|C: STOP/authority; P: no-exactly-once counterexample|E: device/permissions|
|D06|P: shapes/pipelines; R: magnitude≠speech|E: ASR/TTS/vision quality|
|D07|P: quota induction/counts|E: power/PSS/p99|
|D08|P: fixed-pool HT identity, R: universal speedup|E: tests/sandbox|
|D09|S: full dependency graph|E: artifacts/backend|
|D10|S: stop conditions|E: tests/thresholds|

**Общий D01–D10 verdict: NOT PASS**. Формальные части дальше не следует бездоказательно заменять новой разработкой: они либо условно завершены, либо имеют явно перечисленный невозможный на бумаге остаток.
