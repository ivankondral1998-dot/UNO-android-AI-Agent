#!/usr/bin/env python3
"""Independent audit-only calculations and finite counterexamples; NEVER production UNO code."""
from pathlib import Path
import hashlib, json, zipfile, math, itertools

ROOT=Path(__file__).resolve().parent
DIMS=(512,1024,1536,2048)
SRC=ROOT/'SOURCE_V2_1_UNMODIFIED.zip'

# Independent enumeration of tensor shapes, intentionally NOT using W1/LR64 equations as source.
def tensor_registry(d, family='W1', r=64):
    V,m,A,b,chi,J=32768,128,128,64,4,2
    n=d//b
    assert d%b==0
    dims={}
    def add(k,*shape):
        if k in dims: raise ValueError(k)
        assert all(x>0 for x in shape)
        dims[k]=shape
    add('E_text',V,d)
    for name,width in [('W_audio',80),('W_image',768),('W_sensor',64),('W_meta',32)]: add(name,d,width)
    add('e_tau',6,d); add('b_z',d)
    for name in ('U_s','U_g'):add(name,d,d)
    for name in ('W_q','W_k','W_v'):add(name,m,d)
    add('W_r',d,m)
    for l in range(J):
        for j in range(n):
            p=f'{l:02d}.{j:02d}'
            for name in ('A','C'):
                if family=='W1':add(f'{name}.{p}',chi*b,d)
                else:
                    add(f'{name}.U.{p}',chi*b,r)
                    add(f'{name}.V.{p}',r,d)
            add(f'B.{p}',b,chi*b)
            add(f'a.{p}',chi*b); add(f'b.{p}',b)
    for name,h in [('W_a',A),('W_p',A),('W_ctc',128),('W_b',128),('W_speech',258),('w_value',1),('w_risk',1),('w_halt',1),('w_conf',1)]:
        add(name,h,d)
        add('bias.'+name,h)
    add('b_text',V);add('W_M',n,2*d+4);add('b_M',n);add('w_wake',1,32);add('b_wake',1)
    return dims

def volume(shape):return math.prod(shape)
def digest(b):return hashlib.sha256(b).hexdigest()

def calc(d,fam):
    reg=tensor_registry(d,fam)
    params=sum(volume(s) for s in reg.values())
    vector_count=sum(volume(s) for s in reg.values() if len(s)==1)
    matrix_rows=sum(s[0] for s in reg.values() if len(s)==2)
    int8_bytes_strict_tensor_ndim=params+3*vector_count+4*matrix_rows
    # Work V1/V2.1 explicitly treats six modality rows of e_tau as FP32 vectors,
    # despite declaring e_tau as a 2D (6,d) tensor. Quant classification is an ABI decision.
    vector_count_legacy=vector_count+6*d
    matrix_rows_legacy=matrix_rows-6
    int8_bytes_legacy=params+3*vector_count_legacy+4*matrix_rows_legacy
    # Only F matmul tensors; deliberately count independently by tensor name/prefix.
    fmac=sum(volume(shape) for name,shape in reg.items() if name.startswith(('A.','C.','B.')))
    # Per 10ms AUDIO frame includes full W1 W_audio+U_s+U_g+W_meta+W_r+W_q+W_M,
    # K F iterations, and a full CTC head; W_v/W_k only used on memory WRITE.
    n=d//64;m=128;mem=4096
    frame_base=2*d*d+80*d+32*d+2*m*d+2*mem*m+n*(2*d+4)+128*d+32
    frame_k1=frame_base+fmac+d
    frame_k8=frame_base+8*(fmac+d)
    return dict(d=d,family=fam,tensors=len(reg),params=params,fp16_bytes=2*params,
                int8_bytes_legacy=int8_bytes_legacy,int8_bytes_strict_2d=int8_bytes_strict_tensor_ndim,
                vector_count=vector_count,matrix_rows=matrix_rows,
                F_MAC=fmac,audio_MAC_frame_K1=frame_k1,audio_MAC_frame_K8=frame_k8,
                audio_MAC_sec_K8_100fps=100*frame_k8,
                text_output_128_tokens_lower_bound_MAC=128*(32768*d),
                text_F_K8_128_tokens_MAC=128*(8*fmac),
                registry_sha256=digest(json.dumps(reg,sort_keys=True).encode()))

# Exact probability over all permutations: rank sampling and gradient identity at n=4.
def pl_prob(order,logits):
    remaining=list(range(len(logits)));prob=1.
    for i in order:
        mx=max(logits[j] for j in remaining)
        denom=sum(math.exp(logits[j]-mx) for j in remaining)
        prob*=math.exp(logits[i]-mx)/denom
        remaining.remove(i)
    return prob

def test_pl():
    logits=[-.2,.1,.4,-.1];perms=list(itertools.permutations(range(4)))
    probs=[pl_prob(p,logits) for p in perms]
    assert abs(sum(probs)-1)<1e-13
    assert all(p>0 for p in probs)
    # Function of selected 3-block set, smooth loss under any ranking.
    def loss(p):return (p[0]*.12+p[1]*.29+p[2]*.47)**2
    def mean(ls):return sum(pl_prob(p,ls)*loss(p) for p in perms)
    eps=1e-5
    lplus=logits.copy();lminus=logits.copy();lplus[2]+=eps;lminus[2]-=eps
    fd=(mean(lplus)-mean(lminus))/(2*eps)
    # REINFORCE score for selected coordinate via finite-diff of log probabilities.
    score=0
    for p in perms:
        plus=pl_prob(p,lplus);minus=pl_prob(p,lminus)
        score+=pl_prob(p,logits)*loss(p)*(math.log(plus)-math.log(minus))/(2*eps)
    assert abs(fd-score)<1e-9
    return dict(n=4,total_permutations=len(perms),probability_sum=sum(probs),
                minimum_probability=min(probs),all_three_prefix_sets=len(set(tuple(sorted(p[:3])) for p in perms)),
                d_expected_loss_numeric=fd,d_score_estimator_exact=score,absolute_difference=abs(fd-score),
                coverage_counterexample_old_catalog='q3 feasible, n_b=16; no size3 mask in {empty,single,full}')

def test_dense_rank129_counterexample():
    # Dense branch's 129 gradient observations form a matrix
    # [sech^2(t) on diagonal, 1 off diagonal] up to positive common scaling.
    # The two LR64 A factors have combined fixed input rank <=128.
    t=1.0
    sech_sq=1.0/(math.cosh(t)**2)
    eig_parallel=128.0+sech_sq
    eig_orthogonal=sech_sq-1.0
    assert eig_parallel>0 and eig_orthogonal<0
    return dict(number_independent_gradients=129,LR64_two_branch_max_rank=128,
                t=t,sech2=sech_sq,eigen_parallel=eig_parallel,
                eigen_orthogonal=eig_orthogonal,conclusion='exact W1-to-LR64 equivalence refuted')

def test_math():
    rows=[calc(d,f) for d in DIMS for f in ('W1','LR64')]
    old={x['d']:x for x in json.loads(zipfile.ZipFile(SRC).read('ARITHMETIC_VERIFIED.json'))['rows']}
    for row in rows:
        p=old[row['d']];fam=row['family']
        assert row['params']==p['params' if fam=='W1' else 'lowrank_r64_params']
        assert row['F_MAC']==p['F_MAC' if fam=='W1' else 'lowrank_r64_F_MAC']
        if fam=='W1':
            assert row['int8_bytes_legacy']==p['int8_bytes']
            assert row['int8_bytes_strict_2d']==p['int8_bytes']-(18*row['d']-24)
            assert row['audio_MAC_sec_K8_100fps']==p['audio_100fps_K8_allblocks_noDSP']
    d1=next(x for x in rows if x['d']==1024 and x['family']=='W1')
    assert d1['audio_MAC_frame_K1']==20989024
    assert d1['params']==55320439
    assert 55451639-55320439==128*(1024+1)
    assert math.ceil(math.log(.05/10)/math.log(1-.001))==5296
    assert math.ceil(math.log(.1)/math.log(.95))==45
    n_e2=2*(math.sqrt(math.log(1/.025))+math.sqrt(math.log(1/.2)))**2/(.05**2)
    assert 8130<n_e2<8145
    return rows,n_e2

def integrity():
    with zipfile.ZipFile(SRC) as z:
        bad=z.testzip();assert bad is None
        v21manifest=json.loads(z.read('SHA256_MANIFEST_V2_1.json'))
        for fname,info in v21manifest.items():
            data=z.read(fname)
            assert len(data)==info['bytes'] and digest(data)==info['sha256'],fname
        with zipfile.ZipFile(z.open('SOURCE_V2_UNMODIFIED.zip')) as zv2:
            manifest=json.loads(zv2.read('SHA256_MANIFEST.json'))
            assert len(manifest)==18
            for name,info in manifest.items():
                blob=zv2.read(name)
                assert len(blob)==info['bytes'] and digest(blob)==info['sha256'],name
    return {'v2_1_manifest_items':len(v21manifest),'v2_manifest_items':len(manifest),
            'source_v2_1_bytes':SRC.stat().st_size,'source_v2_1_sha256':digest(SRC.read_bytes())}

if __name__=='__main__':
    rows,e2=test_math();pl=test_pl();sources=integrity();lr_ce=test_dense_rank129_counterexample()
    result={'status':'AUDIT_ARITHMETIC_PASS_NOT_PRODUCT', 'unit':'MAC counts assume one multiply-accumulate per matrix coefficient',
           'registries':rows,'scheduler_pl_test':pl,'rank129_counterexample_check':lr_ce,'evo_analytic_E2b_n_real':e2,
           'evo_E2b_n_ceil':math.ceil(e2), 'source_integrity':sources,
           'counterexamples':{
               'exactly_once':'MAY_HAVE_SENT before OS dispatch and after side effect have indistinguishable local snapshots',
               'lowrank_expressivity':'one dense block can depend via first output on 129 independent tanh(h_i); two rank64 factors see at most rank128 fixed linear measurements of h',
               'old_mask_support':'q=3 chosen by runtime, catalog only q0/q1/q16',
               'fixedpoint_8':'0.95^8 > 0.1 and sparse mask not full contraction',
               'native_receipt_causality':'pre=false, third party changes setting, post=true, dispatch rejected: predicate is true but not caused by agent'}}
    outfile=ROOT/'INDEPENDENT_AUDIT_RESULTS.json';outfile.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('PASS independent source manifests, 8 tensor registries, int8 row count, cost arithmetic, PL exact finite probabilities/gradient, counterexamples')
    print('evo n',math.ceil(e2))
    for row in rows:print(row['d'],row['family'],'P',row['params'],'F_MAC',row['F_MAC'],'audio_MAC/s',row['audio_MAC_sec_K8_100fps'])
