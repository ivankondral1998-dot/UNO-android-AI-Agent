package org.unovyra.n004research;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * UNO-N0-04 — physical Android sensor experimental app, no cloud or external access.
 * Research only: this is NOT the production UNO organism or Android action interface.
 */
public final class MainActivity extends Activity implements SensorEventListener {
    private static final String[] STEPS={"A — ОБУЧЕНИЕ", "A — КОНТРОЛЬ", "B — ОБУЧЕНИЕ", "B — КОНТРОЛЬ", "A — ПОВТОР ПОСЛЕ ПЕРЕЗАПУСКА"};
    private static final boolean[] LEARNING={true,false,true,false,false};
    private static final String[] MODES={"A","A","B","B","A"};
    private static final int TARGET=80;
    private static final int WINDOW_MS=250;
    private static final long MAX_STAGE_NS=60_000_000_000L;
    private static final String PREFS="uno_n0_04_private_v1", CHECKPOINT="checkpoint";

    private SensorManager sensors;
    private Sensor sensor;
    private boolean fallbackAccel=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final double[] gravity={0,0,0};
    private boolean gravityInitialized=false;
    private double windowMax=0;
    private int windowEvents=0;
    private int totalSensorEvents=0;
    private long newestSensorAt=0;
    private boolean active=false;
    private boolean checkpointCorrupt=false;
    private boolean loadedFromDiskThisActivity=false;
    private int step=0;
    private int valid=0, dropped=0, changing=0, modelRight=0, tableRight=0, persistenceRight=0, alwaysStillRight=0;
    private int learnedBefore=0;
    private long inferenceTotalNs=0, inferenceMaxNs=0, stageStartNs=0;
    private final List<Long> inferenceNs=new ArrayList<>();
    private String prior=null, older=null;
    private String stageRollback=null;

    private NeuralGraph graph=new NeuralGraph();
    private NeuralGraph.MarkovBaseline baseline=new NeuralGraph.MarkovBaseline();
    private StringBuilder report=new StringBuilder();
    private TextView statusView, reportView;
    private Button startButton, stopButton, copyButton, resetButton;
    private long restoreHashCount=0;
    private String restoreStatus="NO_SAVED_STATE";
    private String saveStatus="NOT_SAVED";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
        if(sensors!=null){sensor=sensors.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
            if(sensor==null){sensor=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);fallbackAccel=sensor!=null;}}
        loadCheckpoint();
        ScrollView sc=new ScrollView(this);
        LinearLayout layout=new LinearLayout(this);
        layout.setPadding(dp(18),dp(20),dp(18),dp(30));layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xfff3f5f8);sc.addView(layout);
        TextView title=label("UNO N0-04 • Реальные события",22,true);layout.addView(title);
        layout.addView(label("Нейроны без числовых синаптических весов. Сигналы от физического акселерометра Android. Результат следующего измерения неизвестен модели при прогнозе.",14,false));
        statusView=label("",16,true);layout.addView(statusView);
        startButton=button(layout,"Запустить текущую стадию",v->startStage());
        stopButton=button(layout,"СТОП / отменить текущую стадию",v->abortStage("OWNER_STOP"));
        copyButton=button(layout,"Скопировать отчёт",v->{
            ClipboardManager clip=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(clip!=null)clip.setPrimaryClip(ClipData.newPlainText("UNO N0-04 / device test",fullReport()));
            android.widget.Toast.makeText(this,"Отчёт скопирован",android.widget.Toast.LENGTH_SHORT).show();
        });
        resetButton=button(layout,"Стереть только экспериментальные связи N0-04",v->resetResearch());
        reportView=label("",13,false);reportView.setTextIsSelectable(true);layout.addView(reportView);
        setContentView(sc);
        if(report.length()==0)report.append("UNO-N0-04 / REAL SENSOR / RESEARCH v0.4.0\n");
        line("Устройство: "+Build.MANUFACTURER+" "+Build.MODEL+" / Android API "+Build.VERSION.SDK_INT);
        line("Физический сенсор: "+(sensor==null?"NOT_AVAILABLE":sensor.getName()+" (type "+sensor.getType()+")"));
        line("Источник: "+(fallbackAccel?"TYPE_ACCELEROMETER + gravity filter":"TYPE_LINEAR_ACCELERATION"));
        line("Проверка сохранённого состояния: "+restoreStatus);
        line("Утверждение: NO learned numerical synaptic weights; числовые пороги датчика и счётчики остаются.");
        line("Ограничения: реальные показания датчика ≠ проверенные последствия внешних действий; никакой энергии/AGI здесь не измеряется.");
        refresh();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size,boolean bold){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(0xff17314a);v.setPadding(0,dp(7),0,dp(7));if(bold)v.setTypeface(null,1);return v;}
    private Button button(LinearLayout box,String title,View.OnClickListener fn){Button b=new Button(this);b.setText(title);b.setAllCaps(false);box.addView(b);b.setOnClickListener(fn);return b;}
    private void line(String s){report.append(s).append('\n');if(reportView!=null)reportView.setText(report.toString());}
    private String fullReport(){return report.toString()+"\nCHECKPOINT: "+saveStatus+"; RESTORE: "+restoreStatus+"; NEURONS: "+graph.neuronCount()+"; SYNAPSES: "+graph.synapseCount()+"\n";}
    private void refresh(){
        if(statusView==null)return;
        String label=step<STEPS.length?STEPS[step]:"ГОТОВО: полный протокол завершён";
        String task=step==0||step==1||step==4 ? "A: спокойное удержание телефона с редкими небольшими движениями" : "B: частые небольшие движения, без сильной тряски";
        String m="Текущая стадия: "+label+"\n"+task+"\n";
        if(step==4&&!loadedFromDiskThisActivity)m+="ТРЕБУЕТСЯ ЗАКРЫТЬ И ПОВТОРНО ОТКРЫТЬ ПРИЛОЖЕНИЕ перед повтором A.\n";
        if(active)m+="РЕАЛЬНЫЙ СЕНСОР: "+valid+"/"+TARGET+"; пропущено "+dropped+" окон; сенсорных событий "+totalSensorEvents+"\n";
        m+="Нейроны "+graph.neuronCount()+", связи "+graph.synapseCount()+", неоднозначные "+graph.contestedNeuronCount()+"\nСохранение: "+saveStatus;
        statusView.setText(m);
        startButton.setEnabled(!active&&!checkpointCorrupt&&sensor!=null&&step<STEPS.length&&(step!=4||loadedFromDiskThisActivity));
        stopButton.setEnabled(active);
        resetButton.setEnabled(!active);
    }
    private String mode(){return MODES[step];}
    private void startStage(){
        if(active||step>=STEPS.length||checkpointCorrupt||sensor==null||(step==4&&!loadedFromDiskThisActivity))return;
        stageRollback=serializePayload();
        valid=0;dropped=0;changing=0;modelRight=0;tableRight=0;persistenceRight=0;alwaysStillRight=0;
        totalSensorEvents=0;windowEvents=0;windowMax=0;newestSensorAt=0;prior=null;older=null;
        inferenceNs.clear();inferenceTotalNs=0;inferenceMaxNs=0;
        learnedBefore=graph.neuronCount();gravityInitialized=false;
        stageStartNs=SystemClock.elapsedRealtimeNanos();
        active=true;
        boolean registered=sensors.registerListener(this,sensor,SensorManager.SENSOR_DELAY_GAME);
        if(!registered){active=false;line("SENSOR_REGISTER_FAILED, стадия не начата");return;}
        line("\n=== START "+STEPS[step]+" / MODE="+mode()+" / learn="+LEARNING[step]+" ===");
        handler.postDelayed(tick,WINDOW_MS);
        refresh();
    }
    private final Runnable tick=new Runnable(){@Override public void run(){
        if(!active)return;
        long now=SystemClock.elapsedRealtimeNanos();
        if(now-stageStartNs>MAX_STAGE_NS){abortStage("TIMEOUT_NO_VALID_SENSOR_WINDOWS");return;}
        if(windowEvents==0||now-newestSensorAt>1_500_000_000L){dropped++;}
        else{
            String outcome=windowMax<0.65?NeuralGraph.STILL:(windowMax<2.5?NeuralGraph.MOVE:NeuralGraph.JOLT);
            if(prior!=null&&!prior.equals(outcome))changing++;
            if(prior!=null&&older!=null){
                NeuralGraph.EventContext context=new NeuralGraph.EventContext(mode(),prior,older);
                long begin=SystemClock.elapsedRealtimeNanos();
                NeuralGraph.Prediction decision=graph.predict(context);
                long predictNs=SystemClock.elapsedRealtimeNanos()-begin;
                inferenceNs.add(predictNs);inferenceTotalNs+=predictNs;if(predictNs>inferenceMaxNs)inferenceMaxNs=predictNs;
                String simple=prior;
                String table=baseline.predict(mode(),prior);
                if(outcome.equals(decision.label))modelRight++;
                if(outcome.equals(simple))persistenceRight++;
                if(outcome.equals(table))tableRight++;
                if(outcome.equals(NeuralGraph.STILL))alwaysStillRight++;
                if(LEARNING[step]){
                    // This update uses the NEXT real SensorEvent window AFTER the prediction was made.
                    graph.learn(context,outcome);
                    baseline.learn(mode(),prior,outcome);
                }
                valid++;
            }
            older=prior;prior=outcome;
        }
        windowEvents=0;windowMax=0;
        if(valid>=TARGET){finishStage();return;}
        refresh();handler.postDelayed(this,WINDOW_MS);
    }};
    @Override public void onSensorChanged(SensorEvent e){
        if(!active||sensor==null||e.sensor.getType()!=sensor.getType())return;
        if(e.values==null||e.values.length<3)return;
        double x=e.values[0],y=e.values[1],z=e.values[2];
        if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z))return;
        if(fallbackAccel){
            if(!gravityInitialized){gravity[0]=x;gravity[1]=y;gravity[2]=z;gravityInitialized=true;}
            for(int i=0;i<3;i++)gravity[i]=0.92*gravity[i]+0.08*e.values[i];
            x-=gravity[0];y-=gravity[1];z-=gravity[2];
        }
        double norm=Math.sqrt(x*x+y*y+z*z);
        if(!Double.isFinite(norm))return;
        windowMax=Math.max(windowMax,norm);
        windowEvents++;totalSensorEvents++;newestSensorAt=SystemClock.elapsedRealtimeNanos();
    }
    @Override public void onAccuracyChanged(Sensor s,int accuracy){}
    private void finishStage(){
        if(!active)return;
        handler.removeCallbacks(tick);sensors.unregisterListener(this);active=false;
        long elapsedMs=(SystemClock.elapsedRealtimeNanos()-stageStartNs)/1_000_000L;
        long meanUs=inferenceNs.isEmpty()?0:(inferenceTotalNs/inferenceNs.size())/1000L;
        List<Long> ordered=new ArrayList<>(inferenceNs);Collections.sort(ordered);
        long p95Us=ordered.isEmpty()?0:ordered.get((int)Math.ceil(ordered.size()*0.95)-1)/1000L;
        line("END "+STEPS[step]+"; valid="+valid+"; time="+elapsedMs+" ms; sensorEvents="+totalSensorEvents+"; skippedWindows="+dropped);
        line("Физических смен класса движения: "+changing+"; модель "+modelRight+"/"+valid+"; постоянство "+persistenceRight+"/"+valid+"; числовая Markov-таблица "+tableRight+"/"+valid+"; всегда STILL "+alwaysStillRight+"/"+valid);
        line("Новые нейроны: "+(graph.neuronCount()-learnedBefore)+"; всего "+graph.neuronCount()+"; connections "+graph.synapseCount()+"; CONTESTED="+graph.contestedNeuronCount());
        line("Вычисление прогноза: mean "+meanUs+" µs, p95 "+p95Us+" µs, max "+inferenceMaxNs/1000L+" µs (НЕ энергия/пиковая RAM)");
        Runtime r=Runtime.getRuntime();line("Java heap snapshot "+((r.totalMemory()-r.freeMemory())/1024)+" KiB; NOT PSS");
        if(changing<8)line("GATE: INVALID_LOW_MOTION_DIVERSITY; 8+ real transitions required per stage. Результат не принимать как доказательство адаптации.");
        else if(LEARNING[step]&&graph.neuronCount()==learnedBefore)line("GATE: NO_STRUCTURAL_GROWTH (not proof of learning)");
        else if(!LEARNING[step]&&modelRight<persistenceRight)line("GATE: FAIL_AGAINST_PERSISTENCE");
        else if(!LEARNING[step]&&modelRight<tableRight)line("GATE: FAIL_AGAINST_MARKOV_TABLE");
        else line("GATE: metric gate tentative PASS; check persistence and complete A→B→A protocol");
        step++;
        saveCheckpoint();
        line("CHECKPOINT: "+saveStatus);
        if(step==4){loadedFromDiskThisActivity=false;line("ОБЯЗАТЕЛЬНО закрой и повторно открой приложение для повторного TEST A.");}
        if(step==STEPS.length)line("DEVICE PROTOCOL COMPLETE. Передай весь отчёт, включая результаты сравнения и checkpoint. Не называй результат AGI.");
        refresh();
    }
    private void abortStage(String reason){
        if(!active)return;
        active=false;handler.removeCallbacks(tick);
        if(sensors!=null)sensors.unregisterListener(this);
        // Restore graph/table before the aborted block (not a passed/finished training stage).
        try {if(stageRollback!=null)decodePayload(new JSONObject(stageRollback));}catch(Exception e){checkpointCorrupt=true;line("ROLLBACK_FAILED: "+e.getClass().getSimpleName());}
        line("ABORTED: "+reason+"; partial measurements NOT accepted; graph restored from stage-start snapshot");
        saveCheckpoint();refresh();
    }
    @Override protected void onPause(){if(active)abortStage("ACTIVITY_PAUSED");super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(tick);if(sensors!=null)sensors.unregisterListener(this);super.onDestroy();}

    private String serializePayload(){
        try{
            JSONObject p=new JSONObject();p.put("schema",1);p.put("completedSteps",step);
            p.put("graph",graph.asJson());p.put("baseline",baseline.asJson());
            return p.toString();
        }catch(Exception e){throw new IllegalStateException("Cannot serialize research checkpoint",e);}
    }
    private void decodePayload(JSONObject p) throws JSONException {
        if(p.getInt("schema")!=1)throw new JSONException("Unknown checkpoint schema");
        int completed=p.getInt("completedSteps");if(completed<0||completed>5)throw new JSONException("Bad checkpoint stage");
        NeuralGraph g=NeuralGraph.fromJson(p.getJSONObject("graph"));
        NeuralGraph.MarkovBaseline b=NeuralGraph.MarkovBaseline.fromJson(p.getJSONObject("baseline"));
        step=completed;graph=g;baseline=b;
    }
    private static String sha256(String text) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder s=new StringBuilder();for(byte b:digest)s.append(String.format(Locale.US,"%02x",b&255));return s.toString();
    }
    private void loadCheckpoint(){
        SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);
        String envelope=p.getString(CHECKPOINT,null);
        if(envelope==null){restoreStatus="NO_CHECKPOINT_YET";return;}
        try{
            JSONObject item=new JSONObject(envelope);String payload=item.getString("payload");String expected=item.getString("sha256");
            String actual=sha256(payload);
            if(!expected.equals(actual))throw new IllegalStateException("Hash mismatch");
            decodePayload(new JSONObject(payload));
            report=new StringBuilder(p.getString("report",""));
            loadedFromDiskThisActivity=true;restoreHashCount++;
            restoreStatus="PASS_SHA256 / completed="+step+" / nodes="+graph.neuronCount()+" / "+actual.substring(0,16);
        }catch(Exception e){checkpointCorrupt=true;restoreStatus="CORRUPT_STOP "+e.getClass().getSimpleName()+": "+e.getMessage();}
    }
    private void saveCheckpoint(){
        if(checkpointCorrupt){saveStatus="REFUSED_CORRUPT";return;}
        try{
            String payload=serializePayload(),sum=sha256(payload);
            JSONObject envelope=new JSONObject();envelope.put("payload",payload);envelope.put("sha256",sum);
            SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);
            String storedReport=report.toString();if(storedReport.length()>40000)storedReport=storedReport.substring(storedReport.length()-40000);
            boolean success=p.edit().putString(CHECKPOINT,envelope.toString()).putString("report",storedReport).commit();
            String check=p.getString(CHECKPOINT,null);
            if(!success||check==null)throw new IllegalStateException("Commit/readback failed");
            JSONObject reloaded=new JSONObject(check);if(!sum.equals(sha256(reloaded.getString("payload"))))throw new IllegalStateException("Readback hash failed");
            saveStatus="COMMIT_AND_READBACK_PASS / "+sum.substring(0,16)+" / rules="+graph.neuronCount();
        }catch(Exception e){saveStatus="SAVE_FAILED "+e.getClass().getSimpleName()+": "+e.getMessage();}
    }
    private void resetResearch(){
        // Only after an explicit button press. No delete of any unrelated application data.
        if(active)return;
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(CHECKPOINT).remove("report").commit();
        checkpointCorrupt=false;loadedFromDiskThisActivity=false;step=0;
        graph=new NeuralGraph();baseline=new NeuralGraph.MarkovBaseline();
        report=new StringBuilder("UNO-N0-04 RESET (owner pressed reset)\n");
        restoreStatus="RESET_NEW_EXPERIMENT";saveStatus="NOT_SAVED";
        line("RESET: только данные UNO-N0-04, новый протокол может начаться с A");refresh();
    }
}
