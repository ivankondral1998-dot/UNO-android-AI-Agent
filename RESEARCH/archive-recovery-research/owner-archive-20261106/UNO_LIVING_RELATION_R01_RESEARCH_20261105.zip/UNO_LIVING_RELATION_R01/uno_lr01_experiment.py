#!/usr/bin/env python3
"""UNO-LR-01: isolated research fixture; typed contextual revision, NOT production UNO.

No external dependencies. Pre-registered experimental card is a separate immutable file.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import platform
import resource
import signal
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path

SEED = 20261105
LIMIT_SECONDS = 600
LIMIT_BYTES = 2 * 1024**3
ATTRIBUTES = ("surface", "treatment", "material")
VALUES = {
    "surface": ("ROUGH", "SLICK"),
    "treatment": ("NONE", "GRIP"),
    "material": ("WOOD", "METAL", "GLASS", "CERAMIC"),
}
ACTIONS = ("LEFT", "RIGHT")
COPY = "COPY"
INVERT = "INVERT"


def inverse(direction: str) -> str:
    return "RIGHT" if direction == "LEFT" else "LEFT"


def world_effect(ctx: dict, action: str) -> str:
    """Independent *synthetic* environment; model receives only verified receipts."""
    return inverse(action) if ctx["surface"] == "SLICK" and ctx["treatment"] == "NONE" else action


def structured_context(surface: str, treatment: str, material: str) -> dict:
    return dict(surface=surface, treatment=treatment, material=material)


def canonical_key(ctx: dict, action: str) -> tuple:
    return tuple(ctx[k] for k in ATTRIBUTES) + (action,)


@dataclass(frozen=True)
class Receipt:
    context: dict
    action: str
    observed_direction: str
    verified: bool
    evidence_id: str

    @property
    def transform(self) -> str:
        return COPY if self.observed_direction == self.action else INVERT


@dataclass(frozen=True)
class LivingRelation:
    """Executable relational 'weight': conditional transduction, not a scalar."""
    default: str
    guard: tuple[tuple[str, str], ...] = ()

    def transform(self, ctx: dict) -> str:
        matched = bool(self.guard) and all(ctx[name] == val for name, val in self.guard)
        if matched:
            return INVERT if self.default == COPY else COPY
        return self.default

    def effect(self, ctx: dict, action: str) -> str:
        return inverse(action) if self.transform(ctx) == INVERT else action

    def describe(self) -> str:
        if not self.guard:
            return f"DEFAULT {self.default}"
        body = " AND ".join(f"{name}={value}" for name, value in self.guard)
        opposite = INVERT if self.default == COPY else COPY
        return f"IF {body} THEN {opposite} ELSE {self.default}"


def candidate_guards() -> list[tuple]:
    literals = [(a, val) for a in ATTRIBUTES for val in VALUES[a]]
    guards = [()]
    guards += [(lit,) for lit in literals]
    guards += [tuple(pair) for pair in itertools.combinations(literals, 2) if pair[0][0] != pair[1][0]]
    # Low description length first. Prefer generic clauses not mentioning material when tied.
    guards.sort(key=lambda g: (len(g), sum(k == "material" for k, _ in g), g))
    return guards


GUARDS = candidate_guards()


class RevisionOrganism:
    """One shared executable relation; re-synthesized on every independent receipt."""

    def __init__(self):
        self.relation = LivingRelation(COPY)
        self.history: list[Receipt] = []
        self.conflicts: set[tuple] = set()
        self.versions: list[str] = [self.relation.describe()]
        self.status = "NO_EVIDENCE"

    def observe(self, item: Receipt) -> None:
        if not item.verified:
            raise ValueError("Only independently verified simulation receipts enter learning")
        if item.action not in ACTIONS or item.observed_direction not in ACTIONS:
            raise ValueError("Typed outcome required")
        self.history.append(item)  # Immutable evidence: never overwrite.
        self._revise()

    def _revise(self) -> None:
        values: dict[tuple, set[str]] = {}
        for r in self.history:
            values.setdefault(canonical_key(r.context, r.action), set()).add(r.observed_direction)
        self.conflicts = {key for key, outputs in values.items() if len(outputs) > 1}
        non_conflicting = [r for r in self.history if canonical_key(r.context, r.action) not in self.conflicts]
        solution = None
        for guard in GUARDS:
            for default in (COPY, INVERT):
                candidate = LivingRelation(default, guard)
                if all(candidate.effect(r.context, r.action) == r.observed_direction for r in non_conflicting):
                    solution = candidate
                    break
            if solution is not None:
                break
        if solution is None:
            self.status = "NO_CONSISTENT_PROGRAM_IN_GRAMMAR"
            self.relation = None
            self.versions.append("UNKNOWN")
        else:
            self.relation = solution
            self.status = "CONFLICT" if self.conflicts else "FITTED"
            self.versions.append(solution.describe())

    def predict_effect(self, ctx: dict, action: str) -> str | None:
        if canonical_key(ctx, action) in self.conflicts or self.relation is None:
            return None
        return self.relation.effect(ctx, action)

    def choose_action(self, ctx: dict, desired_direction: str) -> str | None:
        for action in ACTIONS:
            if self.predict_effect(ctx, action) == desired_direction:
                return action
        return None


class FixedCopy:
    def observe(self, _: Receipt) -> None:
        pass

    def predict_effect(self, ctx: dict, action: str) -> str | None:
        return action

    def choose_action(self, ctx: dict, desired_direction: str) -> str | None:
        return desired_direction


class MutableGlobal:
    def __init__(self):
        self.latest: str | None = None

    def observe(self, receipt: Receipt) -> None:
        self.latest = receipt.transform

    def predict_effect(self, ctx: dict, action: str) -> str | None:
        if self.latest is None:
            return None
        return action if self.latest == COPY else inverse(action)

    def choose_action(self, ctx: dict, desired_direction: str) -> str | None:
        if self.latest is None:
            return None
        return desired_direction if self.latest == COPY else inverse(desired_direction)


class ContextTable:
    def __init__(self, include_material: bool):
        self.include_material = include_material
        self.mapping: dict[tuple, str] = {}

    def _key(self, ctx: dict, action: str):
        fields = ("surface", "treatment", "material") if self.include_material else ("surface", "treatment")
        return tuple(ctx[field] for field in fields) + (action,)

    def observe(self, receipt: Receipt) -> None:
        self.mapping[self._key(receipt.context, receipt.action)] = receipt.observed_direction

    def predict_effect(self, ctx: dict, action: str) -> str | None:
        return self.mapping.get(self._key(ctx, action))

    def choose_action(self, ctx: dict, desired_direction: str) -> str | None:
        for action in ACTIONS:
            if self.predict_effect(ctx, action) == desired_direction:
                return action
        return None


def training_events(surface: str, treatments: tuple[str, ...], materials: tuple[str, ...], phase: str) -> list[Receipt]:
    records = []
    for treat, mat, action in itertools.product(treatments, materials, ACTIONS):
        context = structured_context(surface, treat, mat)
        observed = world_effect(context, action)
        records.append(Receipt(context, action, observed, True, f"{phase}-{len(records):02d}"))
    return records


def query_contexts(surfaces: tuple[str, ...], treatments: tuple[str, ...], materials: tuple[str, ...]):
    return [structured_context(surf, tr, mat) for surf, tr, mat in itertools.product(surfaces, treatments, materials)]


def evaluate(agent, contexts: list[dict]) -> dict:
    n = 0
    correct = 0
    unknown = 0
    for ctx, desired in itertools.product(contexts, ACTIONS):
        n += 1
        action = agent.choose_action(ctx, desired)
        if action is None:
            unknown += 1
        elif world_effect(ctx, action) == desired:
            correct += 1
    return dict(correct=correct, total=n, unknown=unknown, accuracy=round(correct / n, 6))


def run() -> dict:
    card_path = Path(__file__).with_name("EXPERIMENT_CARD_PRE_REGISTERED.md")
    card_hash = hashlib.sha256(card_path.read_bytes()).hexdigest()
    if card_hash != "36d3bf6e6e2bd196b5f72f33f9c84906e4ea7a6ca0829317fc1b82ee42f45e73":
        raise RuntimeError("Frozen card hash mismatch")

    phases = {
        "A": training_events("ROUGH", ("NONE", "GRIP"), ("WOOD", "METAL"), "A"),
        "B": training_events("SLICK", ("NONE",), ("WOOD", "METAL"), "B"),
        "C": training_events("SLICK", ("GRIP",), ("WOOD", "METAL"), "C"),
    }
    models = {
        "living_relation": RevisionOrganism(),
        "fixed_copy": FixedCopy(),
        "last_value": MutableGlobal(),
        "exact_table": ContextTable(include_material=True),
        "factor_table_oracle_features": ContextTable(include_material=False),
    }
    old_contexts = query_contexts(("ROUGH",), ("NONE", "GRIP"), ("WOOD", "METAL"))
    new_contexts = query_contexts(("SLICK",), ("NONE",), ("WOOD", "METAL"))
    treated_contexts = query_contexts(("SLICK",), ("GRIP",), ("WOOD", "METAL"))
    all_seen = old_contexts + new_contexts + treated_contexts
    unseen_materials = query_contexts(("ROUGH", "SLICK"), ("NONE", "GRIP"), ("GLASS", "CERAMIC"))
    output = {
        "candidate": "UNO-LR-01",
        "status": "HOST_RESEARCH_ONLY",
        "seed": SEED,
        "frozen_card_sha256": card_hash,
        "host": {"python": platform.python_version(), "platform": platform.platform()},
        "phases": {},
    }

    for phase, receipts in phases.items():
        for receipt in receipts:
            for model in models.values():
                model.observe(receipt)
        m = {}
        for name, model in models.items():
            entry = {"old": evaluate(model, old_contexts), "new": evaluate(model, new_contexts)}
            if phase == "B":
                entry["sparse_unseen_slick_grip"] = evaluate(model, treated_contexts)
            if phase == "C":
                entry["seen_all"] = evaluate(model, all_seen)
                entry["unseen_material_control"] = evaluate(model, unseen_materials)
            if name == "living_relation":
                entry["relation"] = model.relation.describe() if model.relation else None
                entry["history_len"] = len(model.history)
                entry["conflicts"] = len(model.conflicts)
            m[name] = entry
        output["phases"][phase] = m

    # This is a separate negative test; do not let it alter evaluated learning state.
    probe = RevisionOrganism()
    for receipts in phases.values():
        for r in receipts:
            probe.observe(r)
    first = phases["A"][0]
    contradictory = Receipt(first.context, first.action, inverse(first.observed_direction), True, "CONFLICT-PROBE")
    probe.observe(contradictory)
    output["conflict_probe"] = {
        "status": probe.status,
        "contradictory_input_refused": probe.predict_effect(first.context, first.action) is None,
        "raw_evidence_count": len(probe.history),
        "conflict_key_count": len(probe.conflicts),
    }
    rel = models["living_relation"]
    output["revision_trace"] = [rel.versions[0], rel.versions[8], rel.versions[12], rel.versions[16]]
    output["predeclared_gate"] = {
        "threshold": 0.90,
        "passed": (
            output["phases"]["C"]["living_relation"]["old"]["accuracy"] >= 0.90
            and output["phases"]["C"]["living_relation"]["new"]["accuracy"] >= 0.90
            and output["phases"]["C"]["living_relation"]["unseen_material_control"]["accuracy"] >= 0.90
        ),
    }
    return output


if __name__ == "__main__":
    # Isolated PC fixture only: explicit per-run safety caps.
    resource.setrlimit(resource.RLIMIT_AS, (LIMIT_BYTES, LIMIT_BYTES))
    signal.alarm(LIMIT_SECONDS)
    result = run()
    print(json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True))
