#!/usr/bin/env python3
"""Independent test harness: black-box checks of the frozen UNO-N0-01 source.

No modifications to learner's training program. This is a second research run
of same candidate (within the owner cap of three).
"""
import itertools
import json
from pathlib import Path
import uno_n0_event_graph as n


def verify():
    agent = n.StructuralNeurons()
    progress = {}
    for stage in "ABCD":
        for event in n.observed_phase(stage):
            agent.observe(event)
        progress[stage] = {
            "rule": agent.program.describe() if agent.program else "UNKNOWN",
            "old_retention": n.evaluate(agent, n.query_group("A")),
        }
    assert len(agent.receipts) == 24
    assert agent.graph is not None
    assert agent.graph.validate_no_scalar_synapses()
    assert len(agent.program.exceptions) == 2
    assert any(s.relation == "INHIBITS" for s in agent.graph.synapses)
    assert any(s.relation == "REQUIRES" for s in agent.graph.synapses)
    assert any(s.relation == "EXCITES" for s in agent.graph.synapses)

    # Leak check: disable the independent physics function during inference.
    physical_oracle = n.environment_readback
    def forbidden(*_args, **_kwargs):
        raise AssertionError("LEAK: physics readback invoked during inference")
    n.environment_readback = forbidden
    try:
        for c in n.query_group("UNSEEN_COMBINATION"):
            for desired in n.DIRECTIONS:
                action = agent.choose(c, desired)
                assert action in n.ACTIONS
    finally:
        n.environment_readback = physical_oracle

    exhaustive = {"correct": 0, "total": 0, "errors": []}
    # The finite world allows a full post-training truth-table audit; NOT
    # another training phase and NOT a hidden sealed third-party evaluation.
    for surf, tread, mag, mat, decor, action in itertools.product(
            n.VOCAB["SURFACE"], n.VOCAB["TREAD"], n.VOCAB["MAGNET"],
            n.VOCAB["MATERIAL"], n.VOCAB["DECOR"], n.ACTIONS):
        ctx = n.context(surf, tread, mag, mat, decor)
        actual = physical_oracle(ctx, action)
        predicted = agent.predict(ctx, action)
        exhaustive["total"] += 1
        exhaustive["correct"] += int(actual == predicted)
        if actual != predicted:
            exhaustive["errors"].append({"ctx": ctx, "action": action,
                                         "prediction": predicted, "actual": actual})
    assert exhaustive["correct"] == exhaustive["total"]

    # Epistemic negative control: a second verified contradictory outcome
    # must NOT secretly overwrite the first or claim both are true.
    before = n.context("DRY", "PLAIN", "OFF", "WOOD", "RED")
    agent.observe(n.Receipt(before, "PUSH_LEFT", "RIGHT", "CONFLICT_TEST", True))
    assert agent.predict(before, "PUSH_LEFT") is None
    nonconflict = n.context("ICE", "SPIKED", "OFF", "STEEL", "RED")
    assert agent.predict(nonconflict, "PUSH_RIGHT") == "RIGHT"
    return {"status": "PASS", "training_receipts": 24,
            "full_finite_world": exhaustive, "stages": progress,
            "no_scalar_synapse_params": True,
            "physics_disabled_during_inference": True,
            "conflict_abstention": True,
            "distinct_synapse_relations": sorted(set(s.relation for s in agent.graph.synapses))}


if __name__ == "__main__":
    print(json.dumps(verify(), ensure_ascii=False, indent=2, sort_keys=True))
