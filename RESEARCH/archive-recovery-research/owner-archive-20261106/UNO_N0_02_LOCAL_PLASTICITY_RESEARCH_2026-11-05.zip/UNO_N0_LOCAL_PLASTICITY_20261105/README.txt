UNO-N0-02 — локальная событийная пластичность без числовых синаптических весов.

Откройте RESULTS_AND_LIMITS_RU.md для результатов и ограничений.
FROZEN_CARD.md зафиксирована до первого запуска (и больше не изменялась).
train_local_event_net.py — алгоритм, сеть нейронов, генератор входных опытов, simulator, контрольные baselines.
stdout.json — точный вывод первого запуска, включая все 13 опыта, итоговую сеть и тесты.
independent_audit.py — отдельный интерпретатор структуры графа и проверка сохранённого результата.
audit.json — исправленная финальная аудиторская проверка.
audit_first_attempt_FAIL.json — сохранённый провал диагностического теста при неверном выборе пар.
*_resources.txt — реальные статистики запуска time -v; stderr — диагностические журналы.
SHA256_MANIFEST.txt — контрольные суммы файлов без самоссылки.

Для одного запуска в Linux/POSIX (повторный запуск — новый эксперимент; 3/3 уже исчерпаны для кандидата):
  timeout 600s bash -c 'ulimit -v 2097152; python3 train_local_event_net.py' > stdout.json 2> stderr.txt
  timeout 600s bash -c 'ulimit -v 2097152; python3 independent_audit.py' > audit.json 2> audit_stderr.txt

Это только исследовательский прототип. Никакой production-код или Android APK не создавался.
