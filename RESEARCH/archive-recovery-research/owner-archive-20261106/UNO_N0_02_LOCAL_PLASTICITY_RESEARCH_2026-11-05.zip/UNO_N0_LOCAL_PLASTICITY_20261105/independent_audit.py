#!/usr/bin/env python3
"""Independent outcome/parity re-evaluation from saved N0-02 graph evidence.

Does NOT call original `train` or physics_readback; reconstructs the graph output
from serialized synapse types and compares with an independently expressed
reference for all states. Also replays training receipts via class for determinism.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import resource
import signal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = ("SURFACE", "MAGNET", "FIELD", "COLOR", "MATERIAL")
DIMS = (("DRY", "ICE"), ("OFF", "ON"), ("LOW", "HIGH"),
        ("RED", "BLUE"), ("WOOD", "STEEL", "GLASS"))
ACTIONS = ("PUSH_LEFT", "PUSH_RIGHT")


def read_graph(snap: dict, context: dict[str, str], action: str) -> str:
    gate = snap["default"]
    edges = snap["synapses"]
    neurons = {row["name"] for row in snap["neurons"]}
    assert "STATE:PARITY" in neurons
    active = {f"SENSE:{f}={context[f]}" for f in FIELDS}
    for edge in edges:
        if edge["relation"] != "FLIP" or edge["target"] != "STATE:PARITY":
            continue
        mod = edge["source"]
        if mod not in neurons:
            raise AssertionError("FLIP edge source is not a neuron")
        incoming = [row for row in edges if row["relation"] == "EXCITES" and row["target"] == mod]
        if any(row["source"] in active for row in incoming):
            gate = "COPY" if gate == "INVERT" else "INVERT"
    action_dir = action.removeprefix("PUSH_")
    return action_dir if gate == "COPY" else ("LEFT" if action_dir == "RIGHT" else "RIGHT")


def independent_world(ctx: dict[str, str], action: str) -> str:
    reversed_motion = ((ctx["SURFACE"] == "ICE") != (ctx["MAGNET"] == "ON")) != (ctx["FIELD"] == "HIGH")
    initial = action.removeprefix("PUSH_")
    return ("LEFT" if initial == "RIGHT" else "RIGHT") if reversed_motion else initial


def run() -> dict:
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    signal.alarm(580)
    saved = json.loads((ROOT / "stdout.json").read_text())
    assert saved["card_sha256"] == hashlib.sha256((ROOT / "FROZEN_CARD.md").read_bytes()).hexdigest()
    snapshot = saved["model"]
    expected_wires = {("SURFACE", "ICE"), ("MAGNET", "ON"), ("FIELD", "HIGH")}
    assert {tuple(row) for row in snapshot["modulators_flip"]} == expected_wires
    assert {tuple(row) for row in snapshot["modulators_stable"]} == {
        ("COLOR", "BLUE"), ("MATERIAL", "STEEL")}
    assert snapshot["synapse_count"] == len(snapshot["synapses"])
    assert snapshot["neuron_count"] == len(snapshot["neurons"])
    assert all(set(row) == {"source", "target", "relation"} for row in snapshot["synapses"])
    assert not any(any(isinstance(v, (float, int)) for v in row.values()) for row in snapshot["synapses"])
    assert not any(row["relation"] in ("STRENGTH", "SCALAR_WEIGHT") for row in snapshot["synapses"])

    saved_keys = {tuple(r["context"][f] for f in FIELDS) + (r["action"],)
                  for r in saved["training_receipts"]}
    cases = []
    for values in itertools.product(*DIMS):
        c = dict(zip(FIELDS, values))
        for a in ACTIONS:
            prediction = read_graph(snapshot, c, a)
            expected = independent_world(c, a)
            cases.append({"seen": tuple(values) + (a,) in saved_keys,
                          "prediction": prediction, "expected": expected,
                          "causes": sum((c["SURFACE"] == "ICE", c["MAGNET"] == "ON", c["FIELD"] == "HIGH"))})
    all_correct = sum(t["prediction"] == t["expected"] for t in cases)
    unseen = [t for t in cases if not t["seen"]]
    multiple = [t for t in cases if t["causes"] >= 2]
    scores = {
        "all": [all_correct, len(cases)],
        "unseen": [sum(t["prediction"] == t["expected"] for t in unseen), len(unseen)],
        "multiple": [sum(t["prediction"] == t["expected"] for t in multiple), len(multiple)],
    }

    # Replay verification (same code, separate process) is intentionally not
    # described as independent implementation of the plasticity law.
    from train_local_event_net import LocalEventOrganism, Receipt
    replay = LocalEventOrganism()
    for r in saved["training_receipts"]:
        replay.observe(Receipt(**r))
    identical_graph = replay.snapshot() == snapshot
    assert identical_graph
    assert scores["all"] == [96, 96]
    assert scores["unseen"] == [89, 89]
    assert scores["multiple"] == [48, 48]

    # Diagnostic outside the preregistered gates: no contrast -> no new wiring.
    # Demonstrates that learning requires an experimenter to supply paired trials.
    sparse = LocalEventOrganism()
    raw = saved["training_receipts"]
    for i in (0, 10, 3):  # Action differs on both transitions; no eligible paired trial.
        sparse.observe(Receipt(**raw[i]))
    no_new_wires_without_pairs = len(sparse.active_modulators) == 0

    return {
        "candidate": saved["candidate"], "source_stdout_sha256": hashlib.sha256((ROOT / "stdout.json").read_bytes()).hexdigest(),
        "independent_graph_interpreter": scores,
        "saved_graph_counts": [snapshot["neuron_count"], snapshot["synapse_count"]],
        "independent_plasticity_implementation": False,
        "same_code_replay_graph_identical": identical_graph,
        "absence_of_contrast_diagnostic": {"no_new_wires": no_new_wires_without_pairs,
                                              "label": "EXPLORATORY_POST_HOC"},
        "pass": all_correct == 96 and identical_graph and no_new_wires_without_pairs,
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, ensure_ascii=False, sort_keys=True))
