#!/usr/bin/env python3
"""UNO-N0-02: research-only local event-pair structural plasticity.

No trainable scalar synaptic weights. This is a Boolean symbolic neuron
network with a manually specified pair-contrast plasticity law; it is not
fully autonomous artificial general intelligence or biophysical neurons.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import platform
import resource
import signal
from dataclasses import asdict, dataclass
from pathlib import Path

CARD_SHA256 = "45d224f03d5190c9388cbad946ecda6177e67cdecc2975cf141fb64c03cd6e6c"
HERE = Path(__file__).resolve().parent
FEATURES = ("SURFACE", "MAGNET", "FIELD", "COLOR", "MATERIAL")
VOCAB: dict[str, tuple[str, ...]] = {
    "SURFACE": ("DRY", "ICE"), "MAGNET": ("OFF", "ON"),
    "FIELD": ("LOW", "HIGH"), "COLOR": ("RED", "BLUE"),
    "MATERIAL": ("WOOD", "STEEL", "GLASS"),
}
ACTIONS = ("PUSH_LEFT", "PUSH_RIGHT")
DIRECTIONS = ("LEFT", "RIGHT")
COPY, INVERT, UNKNOWN = "COPY", "INVERT", "UNKNOWN"


def flip(value: str) -> str:
    assert value in (COPY, INVERT)
    return INVERT if value == COPY else COPY


def opposite_direction(value: str) -> str:
    assert value in DIRECTIONS
    return "LEFT" if value == "RIGHT" else "RIGHT"


def direction(action: str) -> str:
    assert action in ACTIONS
    return action.removeprefix("PUSH_")


def relation_of(action: str, observed: str) -> str:
    assert observed in DIRECTIONS
    return COPY if direction(action) == observed else INVERT


def realized(action: str, relation: str) -> str:
    if relation not in (COPY, INVERT):
        return UNKNOWN
    return direction(action) if relation == COPY else opposite_direction(direction(action))


def ctx(**kwargs: str) -> dict[str, str]:
    if set(kwargs) != set(FEATURES):
        raise ValueError("missing or extra sensor")
    if any(kwargs[k] not in VOCAB[k] for k in FEATURES):
        raise ValueError("invalid categorical sensor")
    return dict(kwargs)


def base_context() -> dict[str, str]:
    return ctx(SURFACE="DRY", MAGNET="OFF", FIELD="LOW", COLOR="RED", MATERIAL="WOOD")


def with_value(base: dict[str, str], name: str, value: str) -> dict[str, str]:
    result = dict(base)
    result[name] = value
    return ctx(**result)


def all_contexts():
    for values in itertools.product(*(VOCAB[f] for f in FEATURES)):
        yield ctx(**dict(zip(FEATURES, values)))


def evidence_key(context: dict[str, str], action: str) -> tuple[str, ...]:
    return tuple(context[k] for k in FEATURES) + (action,)


@dataclass(frozen=True)
class Neuron:
    name: str
    role: str


@dataclass(frozen=True)
class Synapse:
    source: str
    target: str
    relation: str  # REQUIRES | EXCITES | FLIP | STABILIZES. No scalar field.


@dataclass(frozen=True)
class Receipt:
    context: dict[str, str]
    action: str
    result: str
    evidence_id: str
    verified: bool

    @property
    def relation(self) -> str:
        return relation_of(self.action, self.result)


class LocalEventOrganism:
    """Single shared event network plus last-event trace and immutable ledger.

    It only compares consecutive verified events, never fits a global rule list.
    This is *event-pair-local*, NOT proven synapse-local biological plasticity.
    """

    def __init__(self):
        self.neurons: dict[str, Neuron] = {
            "STATE:PARITY": Neuron("STATE:PARITY", "BOOLEAN_PARITY"),
            "MOTOR:COPY": Neuron("MOTOR:COPY", "OUTCOME"),
            "MOTOR:INVERT": Neuron("MOTOR:INVERT", "OUTCOME"),
        }
        for feature in FEATURES:
            for value in VOCAB[feature]:
                name = f"SENSE:{feature}={value}"
                self.neurons[name] = Neuron(name, "SENSORY")
        self.synapses: set[Synapse] = set()
        self.reference: dict[str, str] | None = None
        self.default: str | None = None
        self.active_modulators: set[tuple[str, str]] = set()
        self.stable_modulators: set[tuple[str, str]] = set()
        self.ambiguous_modulators: set[tuple[str, str]] = set()
        self.previous: Receipt | None = None
        self.evidence: list[Receipt] = []
        self.known: dict[tuple[str, ...], str] = {}
        self.conflicts: set[tuple[str, ...]] = set()
        self.events: list[dict] = []

    def _attach(self, feature: str, value: str, kind: str) -> None:
        name = f"MODULATOR:{feature}={value}"
        self.neurons[name] = Neuron(name, "EXPERIENCE_GATED_CONTRAST")
        sensor = f"SENSE:{feature}={value}"
        self.synapses.add(Synapse(sensor, name, "EXCITES"))
        self.synapses.add(Synapse(name, "STATE:PARITY", kind))

    def observe(self, receipt: Receipt) -> dict:
        event = {"evidence_id": receipt.evidence_id, "accepted": False, "update": "NONE"}
        if not receipt.verified:
            event["update"] = "UNVERIFIED_REJECTED"
            self.events.append(event)
            return event
        if set(receipt.context) != set(FEATURES) or any(
                receipt.context[f] not in VOCAB[f] for f in FEATURES
        ) or receipt.action not in ACTIONS or receipt.result not in DIRECTIONS:
            event["update"] = "BAD_RECEIPT_REJECTED"
            self.events.append(event)
            return event

        k = evidence_key(receipt.context, receipt.action)
        if k in self.known and self.known[k] != receipt.result:
            self.conflicts.add(k)
            self.evidence.append(receipt)
            event["update"] = "EXACT_CONFLICT_NO_REWIRE"
            self.events.append(event)
            return event
        self.known[k] = receipt.result
        self.evidence.append(receipt)
        event["accepted"] = True
        if self.reference is None:
            self.reference = dict(receipt.context)
            self.default = receipt.relation
            self.neurons[f"DEFAULT:{self.default}"] = Neuron(f"DEFAULT:{self.default}", "DEFAULT_CIRCUIT")
            self.synapses.add(Synapse(f"DEFAULT:{self.default}", "STATE:PARITY", "EXCITES"))
            event["update"] = "REFERENCE_AND_DEFAULT_ESTABLISHED"
        else:
            before = self.previous
            if before is not None and before.action == receipt.action:
                changed = [feature for feature in FEATURES
                           if before.context[feature] != receipt.context[feature]]
                if len(changed) == 1:
                    f = changed[0]
                    vref = self.reference[f]
                    changed_pair = {before.context[f], receipt.context[f]}
                    # More than one non-reference value is not identifiable by
                    # this one-edge local contrast. Do not silently guess.
                    if vref not in changed_pair:
                        event["update"] = "NONREFERENCE_PAIR_UNKNOWN"
                    else:
                        alt = next(v for v in changed_pair if v != vref)
                        token = (f, alt)
                        kind = "FLIP" if before.relation != receipt.relation else "STABILIZES"
                        existing = ("FLIP" if token in self.active_modulators
                                    else "STABILIZES" if token in self.stable_modulators
                                    else None)
                        if existing and existing != kind:
                            self.ambiguous_modulators.add(token)
                            event["update"] = f"CONTRADICTED_{f}={alt}"
                        elif existing:
                            event["update"] = f"CONFIRMED_{kind}_{f}={alt}"
                        else:
                            if kind == "FLIP":
                                self.active_modulators.add(token)
                            else:
                                self.stable_modulators.add(token)
                            self._attach(f, alt, kind)
                            event["update"] = f"LOCALLY_WIRED_{kind}_{f}={alt}"
                else:
                    event["update"] = "NOT_SINGLE_FEATURE_CONTRAST"
            else:
                event["update"] = "NO_SAME_ACTION_CONTRAST"
        self.previous = receipt
        self.events.append(event)
        return event

    def infer_relation(self, context: dict[str, str], action: str) -> str:
        if self.reference is None or self.default is None or action not in ACTIONS:
            return UNKNOWN
        if set(context) != set(FEATURES) or any(
            context[f] not in VOCAB[f] for f in FEATURES
        ):
            return UNKNOWN
        if evidence_key(context, action) in self.conflicts:
            return UNKNOWN
        if any(context[f] == value for f, value in self.ambiguous_modulators):
            return UNKNOWN
        sensory_firings = {f"SENSE:{f}={context[f]}" for f in FEATURES}
        relation = self.default
        # Every active modulator sends one Boolean FLIP event into one shared
        # parity neuron. No multiplication, scalar weights or vector logits.
        for source, value in sorted(self.active_modulators):
            gate = f"MODULATOR:{source}={value}"
            if f"SENSE:{source}={value}" in sensory_firings and \
                    Synapse(f"SENSE:{source}={value}", gate, "EXCITES") in self.synapses and \
                    Synapse(gate, "STATE:PARITY", "FLIP") in self.synapses:
                relation = flip(relation)
        return relation

    def predict(self, context: dict[str, str], action: str) -> str:
        return realized(action, self.infer_relation(context, action))

    def choose_action(self, context: dict[str, str], target: str) -> str:
        if target not in DIRECTIONS:
            return UNKNOWN
        matches = [a for a in ACTIONS if self.predict(context, a) == target]
        return matches[0] if len(matches) == 1 else UNKNOWN

    def snapshot(self) -> dict:
        return {
            "reference": self.reference, "default": self.default,
            "modulators_flip": [list(x) for x in sorted(self.active_modulators)],
            "modulators_stable": [list(x) for x in sorted(self.stable_modulators)],
            "modulators_ambiguous": [list(x) for x in sorted(self.ambiguous_modulators)],
            "neuron_count": len(self.neurons), "synapse_count": len(self.synapses),
            "neurons": [asdict(n) for n in sorted(self.neurons.values(), key=lambda n: n.name)],
            "synapses": [asdict(s) for s in sorted(self.synapses,
                                                  key=lambda s: (s.source, s.target, s.relation))],
        }

    def synapses_have_no_numeric_weight(self) -> bool:
        return all(set(asdict(s)) == {"source", "target", "relation"}
                   and all(type(value) is str for value in asdict(s).values())
                   for s in self.synapses)


# External simulator. Learner observes its result, but no learner method calls it.
def physics_readback(context: dict[str, str], action: str, world: str = "XOR") -> str:
    ice = context["SURFACE"] == "ICE"
    magnet = context["MAGNET"] == "ON"
    field = context["FIELD"] == "HIGH"
    if world == "XOR":
        inverse = (ice != magnet) != field
    elif world == "AND":
        inverse = ice and magnet
    else:
        raise ValueError("unknown world")
    return realized(action, INVERT if inverse else COPY)


def schedule() -> list[tuple[dict[str, str], str]]:
    b = base_context()
    return [
        (b, "PUSH_RIGHT"),
        (with_value(b, "SURFACE", "ICE"), "PUSH_RIGHT"), (b, "PUSH_RIGHT"),
        (with_value(b, "MAGNET", "ON"), "PUSH_RIGHT"), (b, "PUSH_RIGHT"),
        (with_value(b, "COLOR", "BLUE"), "PUSH_RIGHT"), (b, "PUSH_RIGHT"),
        (with_value(b, "MATERIAL", "STEEL"), "PUSH_RIGHT"), (b, "PUSH_RIGHT"),
        (b, "PUSH_LEFT"),
        (with_value(b, "FIELD", "HIGH"), "PUSH_LEFT"), (b, "PUSH_LEFT"),
        (b, "PUSH_RIGHT"),
    ]


def train(world: str = "XOR") -> tuple[LocalEventOrganism, list[dict]]:
    organism = LocalEventOrganism()
    chronology = []
    for index, (context, action) in enumerate(schedule()):
        before = organism.predict(context, action)
        actual = physics_readback(context, action, world)
        receipt = Receipt(dict(context), action, actual, f"SIM-{world}-{index:02}", True)
        update = organism.observe(receipt)
        chronology.append({"context": context, "action": action,
                           "predicted_before": before, "independent_result": actual,
                           "predicted_after": organism.predict(context, action),
                           "local_update": update})
    return organism, chronology


def score(model: LocalEventOrganism, pairs, oracle) -> dict:
    rows = [(context, action, model.predict(context, action), oracle(context, action))
            for context, action in pairs]
    ok = sum(prediction == actual for _, _, prediction, actual in rows)
    return {"correct": ok, "total": len(rows), "accuracy": ok / len(rows) if rows else None,
            "unknown": sum(predicted == UNKNOWN for _, _, predicted, _ in rows)}


def main() -> dict:
    global physics_readback
    actual_card = hashlib.sha256((HERE / "FROZEN_CARD.md").read_bytes()).hexdigest()
    if actual_card != CARD_SHA256:
        raise RuntimeError(f"Pre-registered card changed: {actual_card}")
    signal.alarm(580)
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    model, chronology = train("XOR")
    all_pairs = [(c, a) for c in all_contexts() for a in ACTIONS]
    observed_keys = set(model.known)
    unseen = [(c, a) for c, a in all_pairs if evidence_key(c, a) not in observed_keys]
    retention_contexts = {tuple(c[f] for f in FEATURES): c for c, _ in schedule()}
    retention = [(c, a) for c in retention_contexts.values() for a in ACTIONS]
    composed = [(c, a) for c, a in all_pairs
                if sum([c["SURFACE"] == "ICE", c["MAGNET"] == "ON", c["FIELD"] == "HIGH"]) >= 2]

    truth = lambda c, a: physics_readback(c, a, "XOR")
    scores = {
        "retention": score(model, retention, truth),
        "full_world": score(model, all_pairs, truth),
        "unseen_exact": score(model, unseen, truth),
        "composed_multi_cause": score(model, composed, truth),
    }

    def exact(c, a):
        return model.known.get(evidence_key(c, a), UNKNOWN)
    baselines = {
        "fixed_copy": score(model, [], truth),
        "exact_key": score(model, [], truth),
        "privileged_xor": score(model, [], truth),
    }
    for name, pred in {
        "fixed_copy": lambda c, a: direction(a),
        "exact_key": exact,
        "privileged_xor": truth,
    }.items():
        for split, pairs in {"unseen_exact": unseen, "composed_multi_cause": composed}.items():
            rows = [(pred(c, a), truth(c, a)) for c, a in pairs]
            baselines[name][split] = {"correct": sum(a == b for a, b in rows),
                                       "total": len(rows)}

    # Independent-world law not representable from one-feature baseline contrasts.
    and_model, _ = train("AND")
    and_pair = with_value(with_value(base_context(), "SURFACE", "ICE"), "MAGNET", "ON")
    and_counterexample = {
        "context": and_pair, "action": "PUSH_RIGHT",
        "prediction": and_model.predict(and_pair, "PUSH_RIGHT"),
        "actual": physics_readback(and_pair, "PUSH_RIGHT", "AND"),
        "is_failure": and_model.predict(and_pair, "PUSH_RIGHT") != physics_readback(and_pair, "PUSH_RIGHT", "AND"),
    }

    # Negative fixtures on isolated copies, with no contamination of final model.
    from copy import deepcopy
    negative = deepcopy(model)
    initial_snapshot = negative.snapshot()
    unverified = Receipt(base_context(), "PUSH_RIGHT", "LEFT", "UNVERIFIED", False)
    denied = negative.observe(unverified)
    unchanged_after_unverified = negative.snapshot() == initial_snapshot
    conflict = Receipt(base_context(), "PUSH_RIGHT", "LEFT", "SIM-CONTRADICTION", True)
    conflicting = negative.observe(conflict)
    exact_unknown = negative.predict(base_context(), "PUSH_RIGHT") == UNKNOWN
    other_ctx = with_value(base_context(), "SURFACE", "ICE")
    other_intact = negative.predict(other_ctx, "PUSH_RIGHT") == model.predict(other_ctx, "PUSH_RIGHT")
    missing_sensor_unknown = negative.predict({"SURFACE": "DRY"}, "PUSH_RIGHT") == UNKNOWN
    mutation_only_isolation = negative.snapshot() == initial_snapshot

    passed = {
        "retention": scores["retention"]["accuracy"] >= 0.90,
        "full_world": scores["full_world"]["accuracy"] >= 0.95,
        "unseen_exact": scores["unseen_exact"]["accuracy"] >= 0.90,
        "composed_multi_cause": scores["composed_multi_cause"]["accuracy"] >= 0.90,
        "negative_controls": (
            denied["update"] == "UNVERIFIED_REJECTED" and unchanged_after_unverified
            and conflicting["update"] == "EXACT_CONFLICT_NO_REWIRE" and exact_unknown
            and other_intact and missing_sensor_unknown and mutation_only_isolation),
        "AND_counterexample_exists": and_counterexample["is_failure"],
        "no_scalar_synapses": model.synapses_have_no_numeric_weight(),
    }

    # Oracle is expressly made inaccessible while checking inference.
    saved_physics = physics_readback
    try:
        physics_readback = lambda *args, **kwargs: (_ for _ in ()).throw(
            RuntimeError("oracle forbidden inside neural inference"))
        oracle_free = all(model.predict(c, a) in DIRECTIONS for c, a in all_pairs)
        goal_choice = model.choose_action(with_value(base_context(), "SURFACE", "ICE"), "RIGHT")
    finally:
        physics_readback = saved_physics
    passed["inference_no_oracle"] = oracle_free and goal_choice == "PUSH_LEFT"

    return {"candidate": "UNO-N0-02", "card_sha256": CARD_SHA256,
            "environment": {"python": platform.python_version(), "platform": platform.platform(),
                            "synthetic_world": "XOR-with-three-causes", "training_events": len(schedule()),
                            "research_only": True},
            "chronology": chronology, "training_receipts": [asdict(r) for r in model.evidence],
            "model": model.snapshot(), "scores": scores, "baselines": baselines,
            "AND_counterexample": and_counterexample, "negative": {
                "unverified_rejected": denied["update"],
                "snapshot_unchanged_after_unverified": unchanged_after_unverified,
                "exact_conflict_rejected": conflicting["update"],
                "exact_conflict_unknown": exact_unknown,
                "other_context_intact": other_intact,
                "missing_sensor_unknown": missing_sensor_unknown,
                "conflict_does_not_rewire_topology": mutation_only_isolation,
                "oracle_disabled_during_inference": oracle_free,
                "chosen_action_for_ice_right_target": goal_choice},
            "gates": passed, "complete_pass": all(passed.values())}


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, indent=2, sort_keys=True))
