package org.unovyra.n004research;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Research-only, one shared event-neuron graph. NO learned numeric synaptic weights.
 * The node output is a discrete event; its incoming connections are typed REQUIRE.
 * The rule of extending conjunctions is authored code, NOT self-invented learning law.
 */
public final class NeuralGraph {
    public static final String STILL = "STILL";
    public static final String MOVE = "MOVE";
    public static final String JOLT = "JOLT";
    private static final String[] EVENTS = {STILL, MOVE, JOLT};
    private static final int MAX_NEURONS = 120;

    public static final class EventContext {
        final String mode;
        final String previous;
        final String older;
        final String trend;
        EventContext(String mode, String previous, String older) {
            this.mode = mode;
            this.previous = previous;
            this.older = older;
            int a = rank(previous), b = rank(older);
            trend = a > b ? "RISE" : a < b ? "FALL" : "FLAT";
        }
        public Set<String> allCues() {
            LinkedHashSet<String> s = new LinkedHashSet<>();
            s.add("MODE:" + mode);
            s.add("PREV:" + previous);
            s.add("OLDER:" + older);
            s.add("TREND:" + trend);
            return s;
        }
        public Set<String> coarseCues() {
            LinkedHashSet<String> s = new LinkedHashSet<>();
            s.add("MODE:" + mode);
            s.add("PREV:" + previous);
            return s;
        }
    }

    private static int rank(String s) {
        if (JOLT.equals(s)) return 2;
        if (MOVE.equals(s)) return 1;
        return 0;
    }

    public static final class Neuron {
        public final String id;
        public final Set<String> require;
        public String emit;
        public boolean contested;
        Neuron(String id, Set<String> require, String emit) {
            this.id=id; this.require=new LinkedHashSet<>(require); this.emit=emit;
        }
        boolean fires(Set<String> actual) { return actual.containsAll(require); }
        JSONObject asJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("require", new JSONArray(require));
            o.put("emit", emit); o.put("contested", contested);
            return o;
        }
    }

    public static final class Prediction {
        public final String label;
        public final boolean fromLearnedNeuron;
        public final boolean ambiguous;
        Prediction(String label, boolean fromLearnedNeuron, boolean ambiguous) {
            this.label=label; this.fromLearnedNeuron=fromLearnedNeuron; this.ambiguous=ambiguous;
        }
    }

    private final List<Neuron> nodes = new ArrayList<>();
    public long growthEvents=0, contestEvents=0, skippedCapacity=0;

    public int neuronCount() { return nodes.size(); }
    public int synapseCount() {int n=0;for(Neuron r:nodes)n+=r.require.size()+1;return n;}
    public int contestedNeuronCount() {int n=0;for(Neuron r:nodes)if(r.contested)n++;return n;}

    /** Select the most specific currently firing neuron, falling back to sensor-state persistence. */
    public Prediction predict(EventContext context) {
        Set<String> cues = context.allCues();
        int best=-1;
        String decision=null;
        boolean ambiguous=false;
        for (Neuron n : nodes) {
            if(!n.fires(cues))continue;
            int specificity=n.require.size();
            if (specificity>best) {
                best=specificity;
                decision=n.emit;
                ambiguous=n.contested;
            } else if(specificity==best && (!n.emit.equals(decision)||n.contested)) {
                ambiguous=true;
            }
        }
        if(best<0||ambiguous) return new Prediction(context.previous, false, ambiguous);
        return new Prediction(decision, true, false);
    }

    private Neuron exact(Set<String> cues) {
        for(Neuron n:nodes) if(n.require.equals(cues))return n;
        return null;
    }
    private boolean create(Set<String> required, String actual) {
        if(nodes.size()>=MAX_NEURONS) { skippedCapacity++;return false; }
        if(exact(required)!=null) return false;
        Neuron n=new Neuron("COINCIDENCE_"+(nodes.size()+1), required, actual);
        nodes.add(n);growthEvents++;
        return true;
    }

    /**
     * Update AFTER scoring a prospective prediction using a new real accelerometer event.
     * On mismatch: form a low-order event conjunction; if it already exists, refine with
     * older-event and trend cues. Repeated contradicting fully specified cues are marked
     * CONTESTED and cannot be represented as deterministic knowledge.
     */
    public String learn(EventContext context,String actual) {
        if(!valid(actual))return "INVALID_OBSERVATION";
        Prediction before=predict(context);
        if(before.label.equals(actual))return "NO_CHANGE";
        Set<String> coarse=context.coarseCues();
        Neuron general=exact(coarse);
        if(general==null) return create(coarse,actual) ? "NEW_COARSE_NEURON" : "CAPACITY";
        Set<String> full=context.allCues();
        Neuron specific=exact(full);
        if(specific==null) return create(full,actual) ? "NEW_REFINEMENT_NEURON" : "CAPACITY";
        if(!specific.emit.equals(actual) && !specific.contested){specific.contested=true;contestEvents++;return "CONTESTED_UNKNOWN";}
        return "AMBIGUOUS_NO_REWIRE";
    }

    public static boolean valid(String s) {
        for(String e:EVENTS)if(e.equals(s))return true;
        return false;
    }

    public JSONObject asJson() throws JSONException {
        JSONObject o=new JSONObject();o.put("schema",1);
        o.put("growthEvents",growthEvents);o.put("contestEvents",contestEvents);o.put("skippedCapacity",skippedCapacity);
        JSONArray arr=new JSONArray();for(Neuron n:nodes)arr.put(n.asJson());o.put("neurons",arr);return o;
    }
    public static NeuralGraph fromJson(JSONObject o) throws JSONException {
        if(o.getInt("schema")!=1)throw new JSONException("Unsupported graph schema");
        NeuralGraph g=new NeuralGraph();
        JSONArray arr=o.getJSONArray("neurons");
        if(arr.length()>MAX_NEURONS)throw new JSONException("Too many neurons");
        for(int i=0;i<arr.length();i++){
            JSONObject row=arr.getJSONObject(i);JSONArray req=row.getJSONArray("require");
            LinkedHashSet<String> cues=new LinkedHashSet<>();
            for(int j=0;j<req.length();j++)cues.add(req.getString(j));
            String emit=row.getString("emit");if(!valid(emit))throw new JSONException("Invalid emission");
            if(cues.size()<2||cues.size()>4||g.exact(cues)!=null)throw new JSONException("Invalid rule");
            for(String c:cues) if(!c.startsWith("MODE:")&&!c.startsWith("PREV:")&&!c.startsWith("OLDER:")&&!c.startsWith("TREND:"))throw new JSONException("Unknown cue");
            Neuron n=new Neuron(row.getString("id"),cues,emit);n.contested=row.getBoolean("contested");g.nodes.add(n);
        }
        g.growthEvents=o.getLong("growthEvents");g.contestEvents=o.getLong("contestEvents");g.skippedCapacity=o.getLong("skippedCapacity");
        return g;
    }

    public String describe() {
        StringBuilder b=new StringBuilder();
        for(Neuron n:nodes){b.append(n.id).append(" ").append(n.require).append(" → ").append(n.emit);
            if(n.contested)b.append(" [CONTESTED]");b.append('\n');}
        return b.toString();
    }

    /** A numerical table is a deliberately separate comparison baseline, not the N0 graph. */
    public static final class MarkovBaseline {
        final int[][][] counts=new int[2][3][3];
        public String predict(String mode,String prev) {
            int m="B".equals(mode)?1:0,p=rank(prev),winner=p,max=0;
            for(int k=0;k<3;k++) if(counts[m][p][k]>max){max=counts[m][p][k];winner=k;}
            return EVENTS[winner];
        }
        public void learn(String mode,String prev,String actual) { counts["B".equals(mode)?1:0][rank(prev)][rank(actual)]++; }
        public JSONObject asJson() throws JSONException {
            JSONArray modes=new JSONArray();
            for(int[][] byPrev:counts){JSONArray rows=new JSONArray();for(int[] row:byPrev){JSONArray x=new JSONArray();for(int v:row)x.put(v);rows.put(x);}modes.put(rows);}
            JSONObject o=new JSONObject();o.put("counts",modes);return o;
        }
        public static MarkovBaseline fromJson(JSONObject obj) throws JSONException {
            MarkovBaseline b=new MarkovBaseline();JSONArray a=obj.getJSONArray("counts");
            if(a.length()!=2)throw new JSONException("Invalid modes");
            for(int m=0;m<2;m++){JSONArray rows=a.getJSONArray(m);if(rows.length()!=3)throw new JSONException("Invalid rows");
                for(int p=0;p<3;p++){JSONArray v=rows.getJSONArray(p);if(v.length()!=3)throw new JSONException("Invalid events");
                    for(int k=0;k<3;k++){int n=v.getInt(k);if(n<0||n>1000000)throw new JSONException("Invalid count");b.counts[m][p][k]=n;}}}
            return b;
        }
    }
}
