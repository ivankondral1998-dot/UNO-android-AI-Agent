package org.unovyra.n005audit;

/** Host-only equivalence test against untouched N0-04 source, seed fixed before device runs. */
public final class AuditHostTest {
    static long seed = 0x5EED00405L;
    static long next() {seed^=seed<<13;seed^=seed>>>7;seed^=seed<<17;return seed;}
    static int choose(int count) {return (int)((next() & Long.MAX_VALUE) % count);}
    static String[] labels={"STILL","MOVE","JOLT"};
    static int checks=0;
    static void eq(Object a,Object b,String why){checks++;if(!a.equals(b))throw new AssertionError(why+": "+a+" vs "+b);}
    static void is(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    public static void main(String[] args) throws Exception {
        NeuralGraph now=new NeuralGraph();
        org.unovyra.n004research.NeuralGraph old=new org.unovyra.n004research.NeuralGraph();
        int origins=0, contested=0, noMatch=0, neuron=0;
        java.lang.reflect.Constructor<org.unovyra.n004research.NeuralGraph.EventContext> ctor=
            org.unovyra.n004research.NeuralGraph.EventContext.class.getDeclaredConstructor(
                String.class,String.class,String.class);
        ctor.setAccessible(true);
        for(int i=0;i<2400;i++) {
            String mode=(choose(2)==0?"A":"B"), prev=labels[choose(3)],older=labels[choose(3)];
            NeuralGraph.EventContext nctx=new NeuralGraph.EventContext(mode,prev,older);
            org.unovyra.n004research.NeuralGraph.EventContext octx=ctor.newInstance(mode,prev,older);
            NeuralGraph.Prediction pn=now.predict(nctx);
            org.unovyra.n004research.NeuralGraph.Prediction po=old.predict(octx);
            eq(pn.label,po.label,"prediction same");
            eq(pn.fromLearnedNeuron,po.fromLearnedNeuron,"neuron origin same");
            eq(pn.ambiguous,po.ambiguous,"ambiguity same");
            is(pn.firingNeurons>=pn.tiedTopNeurons,"valid firing counts");
            is(pn.fromLearnedNeuron == "NEURON".equals(pn.origin),"origin classification");
            if(pn.origin.startsWith("CONTESTED"))contested++;
            if("NO_MATCH".equals(pn.origin))noMatch++;
            if("NEURON".equals(pn.origin))neuron++;
            origins++;
            if(i<1200) {
                String actual=labels[choose(3)];
                eq(now.learn(nctx,actual),old.learn(octx,actual),"learning status same");
                eq(now.neuronCount(),old.neuronCount(),"node counts same");
                eq(now.synapseCount(),old.synapseCount(),"synapse counts same");
                eq(now.contestedNeuronCount(),old.contestedNeuronCount(),"contested counts same");
            }
        }
        is(neuron+noMatch+contested<=origins,"exclusive classification");
        is(now.neuronCount()>0,"learned nodes appeared");
        is(now.contestedNeuronCount()>0,"contradiction exercised");
        is(contested>0,"contested path exercised");
        // After repeated stochastic contexts, graph may not beat persistence; this is not an accuracy experiment.
        System.out.println("HOST_AUDIT_REGRESSION_PASS tests="+checks+" contexts="+origins+
            " neuronOrigins="+neuron+" noMatchOrigins="+noMatch+
            " contestedOrigins="+contested+" nodes="+now.neuronCount()+
            " contestedNodes="+now.contestedNeuronCount());
        System.out.println("WARNING: No Android sensor, no actual checkpoint, no predictive superiority in host test.");
    }
}
