package org.unovyra.n005audit;

import org.unovyra.n007.TinyOrganism;
import java.util.*;
import java.io.*;

/** Independent deterministic synthetic research comparisons, NOT a real phone trace. */
public final class TinyOrganismHostTest {
    private static int checks=0;
    private static void require(boolean v,String reason){checks++;if(!v)throw new AssertionError(reason);}
    private static int ix(String s){return NeuralGraph.JOLT.equals(s)?2:NeuralGraph.MOVE.equals(s)?1:0;}
    private static String cls(int i){return TinyOrganism.CLASS_NAMES[i];}
    private static long seed=0x77aabb99L;
    private static int rnd(int bound){seed^=seed<<13;seed^=seed>>>7;seed^=seed<<17;return (int)Long.remainderUnsigned(seed,bound);}
    private static int nextPhysicalLabel(int mode,int prior,int index){
        int x=rnd(100);
        if(mode==0){
            if(prior==0)return x<72?0:x<95?1:2;
            if(prior==1)return x<35?0:x<90?1:2;
            return x<45?0:x<88?1:2;
        }
        if(prior==0)return x<38?0:x<85?1:2;
        if(prior==1)return x<30?0:x<78?1:2;
        return x<15?0:x<60?1:2;
    }
    private static int[] allSynthetic(int stage,int mode){
        int[] labels=new int[80];int prev=0;
        for(int i=0;i<labels.length;i++){labels[i]=nextPhysicalLabel(mode,prev,i);prev=labels[i];}
        return labels;
    }
    private static final class Results {
        int n,g,markov,persistence,alwaysStill,changes,contested,override,correctAdvantage,stage;
    }
    private static Results stage(TinyOrganism brain,NeuralGraph old,NeuralGraph.MarkovBaseline table,int stage,int mode,boolean learn,int[] labels){
        Results t=new Results();t.stage=stage;int older=0,prev=0,lastActual=0;
        String oldWeights=brain.weightsFingerprint();
        for(int i=0;i<labels.length;i++){
            int outcome=labels[i];
            TinyOrganism.Context ctx=new TinyOrganism.Context(mode,older,prev);
            TinyOrganism.Prediction pred=brain.predict(ctx);
            String modeText=mode==0?"A":"B";
            NeuralGraph.EventContext oldContext=new NeuralGraph.EventContext(modeText,cls(prev),cls(older));
            NeuralGraph.Prediction oldPred=old.predict(oldContext);
            String mk=table.predict(modeText,cls(prev));
            require(pred.computedBlocks==4&&pred.skippedBlocks==4,"real skipped kernels");
            for(double v:brain.currentState())require(Double.isFinite(v)&&v>=-1&&v<=1,"bounded state");
            require(pred.eventId>0,"event id");
            for(double x:pred.sensoryProb)require(x>=0&&x<=1&&Double.isFinite(x),"finite probability");
            if(pred.label==outcome)t.n++;
            if(ix(oldPred.label)==outcome)t.g++;
            if(ix(mk)==outcome)t.markov++;
            if(prev==outcome)t.persistence++;
            if(outcome==0)t.alwaysStill++;
            if(i>0&&lastActual!=outcome)t.changes++;
            if(oldPred.origin.startsWith("CONTESTED"))t.contested++;
            if(pred.label!=prev)t.override++;
            if(pred.label==outcome&&prev!=outcome)t.correctAdvantage++;
            // Future observation not accessed by either decision until right here.
            brain.observeSensor(outcome,learn);
            if(learn){old.learn(oldContext,cls(outcome));table.learn(modeText,cls(prev),cls(outcome));}
            older=prev;prev=outcome;lastActual=outcome;
        }
        if(learn)require(!oldWeights.equals(brain.weightsFingerprint()),"new neural weights updated");
        else require(oldWeights.equals(brain.weightsFingerprint()),"frozen neural weights stable");
        return t;
    }
    private static String summary(Results r){return "stage="+r.stage+" changes="+r.changes+" tinyF="+r.n+"/80 oldN005="+r.g+"/80 persistence="+r.persistence+"/80 Markov="+r.markov+"/80 STILL="+r.alwaysStill+"/80 oldCONTESTED="+r.contested+" tinyFOverrides="+r.override;}
    public static void main(String[] args)throws Exception{
        TinyOrganism n=new TinyOrganism(0x7a07L),clone=new TinyOrganism(0x7a07L);
        require(n.weightsFingerprint().equals(clone.weightsFingerprint()),"seed determinism");
        TinyOrganism.Context cx=new TinyOrganism.Context(0,0,1);
        TinyOrganism.Prediction p=n.predict(cx),p2=clone.predict(cx);
        require(p.label==p2.label && Arrays.equals(p.sensoryProb,p2.sensoryProb),"deterministic inference");
        n.observeSensor(0,true);clone.observeSensor(0,true);
        require(n.weightsFingerprint().equals(clone.weightsFingerprint()),"deterministic learned weights");
        require(n.sensoryLearningCount()==1,"sensory learning counter");
        require(n.retrieveExact(p.eventId).status==TinyOrganism.ExactStatus.COMPLETE,"exact observable provenance");
        for(int i=0;i<15;i++){
            n.predict(cx);n.teachOwnerIntent(1);n.observeSensor(0,false);
        }
        require(n.ownerTeachingCount()==15,"owner correction count");
        String fw=n.weightsFingerprint();n.predict(cx);n.teachOwnerIntent(0);require(!fw.equals(n.weightsFingerprint()),"owner supervision updates intent head");
        require(n.mockOutcomeCount()==0,"owner did not authorize OS outcome");
        TinyOrganism.MockTicket good=new TinyOrganism.MockTicket(n.epoch(),100,1000,true);
        TinyOrganism.MockReceipt valid=new TinyOrganism.MockReceipt(n.epoch(),100,1200,true,true,true);
        double before=n.plasticNorm();
        require(!n.learnMockVerifiedOutcome(new TinyOrganism.MockTicket(n.epoch(),100,1000,false),valid,1),"capability absent must reject");
        require(!n.learnMockVerifiedOutcome(good,new TinyOrganism.MockReceipt(n.epoch(),101,1200,true,true,true),1),"operation mismatch reject");
        require(!n.learnMockVerifiedOutcome(good,new TinyOrganism.MockReceipt(n.epoch(),100,1200,false,true,true),1),"unknown outcome reject");
        require(!n.learnMockVerifiedOutcome(good,new TinyOrganism.MockReceipt(n.epoch(),100,1200,true,false,true),1),"dispatch-only rejected");
        require(!n.learnMockVerifiedOutcome(good,new TinyOrganism.MockReceipt(n.epoch(),100,900,true,true,true),1),"stale readback rejected");
        require(!n.learnMockVerifiedOutcome(good,new TinyOrganism.MockReceipt(n.epoch(),100,1200,true,true,false),1),"no matching postcondition rejected");
        require(n.mockOutcomeCount()==0&&n.plasticNorm()==before,"no P mutation without mock receipt");
        n.stop();require(!n.learnMockVerifiedOutcome(good,valid,1),"STOP blocks mock admission");
        n.ownerClearStop();require(!n.learnMockVerifiedOutcome(good,valid,1),"STOP epoch stale even after owner clear");
        TinyOrganism.MockTicket current=new TinyOrganism.MockTicket(n.epoch(),100,1000,true);
        TinyOrganism.MockReceipt fresh=new TinyOrganism.MockReceipt(n.epoch(),100,1200,true,true,true);
        require(n.learnMockVerifiedOutcome(current,fresh,1),"fresh matched mock receipt admits P");
        require(n.plasticNorm()>before&&n.plasticNorm()<=1&&n.mockOutcomeCount()==1,"P projection on matched mock");
        double admittedNorm=n.plasticNorm();
        require(!n.learnMockVerifiedOutcome(current,fresh,1)&&n.plasticNorm()==admittedNorm,"duplicate ticket cannot learn twice");
        require(!n.learnMockVerifiedOutcome(new TinyOrganism.MockTicket(n.epoch(),101,1000,true),new TinyOrganism.MockReceipt(n.epoch(),101,62001,true,true,true),1),"expired receipt invalid");
        byte[] cp=n.checkpoint();String hash=TinyOrganism.sha256(cp);
        TinyOrganism restored=TinyOrganism.restore(cp);
        require(Arrays.equals(cp,restored.checkpoint()),"checksum checkpoint roundtrip exact");
        require(hash.equals(TinyOrganism.sha256(restored.checkpoint())),"checksum preserved");
        restored.predict(cx);
        require(!restored.learnMockVerifiedOutcome(current,fresh,1),"replayed receipt stays rejected across restart");
        byte[] corrupt=cp.clone();corrupt[corrupt.length/2]^=1;
        boolean rejected=false;try{TinyOrganism.restore(corrupt);}catch(IOException ok){rejected=true;}
        require(rejected,"SHA256 mismatch must reject corruption");
        for(int i=0;i<180;i++){restored.predict(cx);restored.observeSensor(i%3,false);}
        require(restored.activeMemoryEntries()==TinyOrganism.MEMORY_CAP,"exact ledger bounded");
        require(restored.retrieveExact(p.eventId).status==TinyOrganism.ExactStatus.TRUNCATED,"cannot fake exact recall after bounded memory eviction");
        require(restored.retrieveExact(99999999).status==TinyOrganism.ExactStatus.UNKNOWN,"unknown not asserted");
        System.out.println("UNIT_CONTRACT_PASS checks="+checks+" tinyD="+TinyOrganism.D+" K="+TinyOrganism.K+" executedBlocks="+restored.executedBlocks()+" skippedBlocks="+restored.skippedBlocks()+" mockAdmits="+n.mockOutcomeCount()+" checkpointSHA256="+hash);
        TinyOrganism brain=new TinyOrganism(0x7a07L);
        NeuralGraph graph=new NeuralGraph();NeuralGraph.MarkovBaseline markov=new NeuralGraph.MarkovBaseline();
        int[] modes={0,0,1,1,0};boolean[] learn={true,false,true,false,false};
        int totalTiny=0,totalOld=0,totalMarkov=0,totalPersistence=0;
        for(int stage=0;stage<5;stage++){
            Results r=stage(brain,graph,markov,stage+1,modes[stage],learn[stage],allSynthetic(stage,modes[stage]));
            System.out.println("SYNTHETIC "+summary(r));
            if(!learn[stage]){totalTiny+=r.n;totalOld+=r.g;totalMarkov+=r.markov;totalPersistence+=r.persistence;}
            if(stage==3){
                byte[] saved=brain.checkpoint();String sha=TinyOrganism.sha256(saved);
                brain=TinyOrganism.restore(saved);
                require(sha.equals(TinyOrganism.sha256(brain.checkpoint())),"frozen checkpoint before final A retained");
                System.out.println("SYNTHETIC_RESTORE_PASS sha256="+sha);
            }
        }
        System.out.println("FROZEN_AGGREGATE tinyF="+totalTiny+"/240 oldN005="+totalOld+"/240 persistence="+totalPersistence+"/240 Markov="+totalMarkov+"/240");
        System.out.println("CHECKS_TOTAL="+checks);
        System.out.println("RESULT HOST_TESTED_SYNTHETIC_ONLY - no device test, no native Android readback, no G4/G5 adoption");
    }
}
