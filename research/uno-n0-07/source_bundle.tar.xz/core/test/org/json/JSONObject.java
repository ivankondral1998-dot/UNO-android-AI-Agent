package org.json;
public class JSONObject {
    // COMPILE-ONLY stub; host test covers graph inference/learning, NOT persistence/JSON.
    public JSONObject() {}
    public JSONObject put(String key,Object value) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public JSONArray getJSONArray(String key) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public JSONObject getJSONObject(String key) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public String getString(String key) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public int getInt(String key) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public long getLong(String key) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public boolean getBoolean(String key) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
}
