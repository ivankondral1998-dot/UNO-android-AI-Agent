package org.json;
import java.util.Collection;
public class JSONArray {
    public JSONArray() {}
    public JSONArray(Collection<?> values) {}
    public JSONArray put(Object value) {throw new UnsupportedOperationException("JSON stub");}
    public int length() {throw new UnsupportedOperationException("JSON stub");}
    public JSONObject getJSONObject(int i) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public JSONArray getJSONArray(int i) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public String getString(int i) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
    public int getInt(int i) throws JSONException {throw new UnsupportedOperationException("JSON stub");}
}
