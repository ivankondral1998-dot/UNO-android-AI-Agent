#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Must point to local Android SDK 35 (with build-tools/35.0.0)}"
BUILD="$ANDROID_HOME/build-tools/35.0.0"
API="$ANDROID_HOME/platforms/android-35/android.jar"
for cmd in "$BUILD/d8" "$BUILD/aapt2" "$BUILD/zipalign" "$BUILD/apksigner" "$BUILD/aapt"; do test -x "$cmd" || { echo "MISSING: $cmd"; exit 2; }; done
test -f "$API" || { echo "MISSING: $API"; exit 2; }
mkdir -p android/build/{classes,dex,res}
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp "$API" -d android/build/classes \
  core/src/org/unovyra/n007/TinyOrganism.java android/src/org/unovyra/n007/MainActivity.java
"$BUILD/d8" --min-api 26 --lib "$API" --output android/build/dex $(find android/build/classes -name '*.class' | sort)
"$BUILD/aapt2" compile --dir android/res -o android/build/res
"$BUILD/aapt2" link --version-code 1 --version-name 0.7.0-research -o android/build/unsigned.apk \
  --manifest android/AndroidManifest.xml -I "$API" --min-sdk-version 26 --target-sdk-version 35 \
  $(find android/build/res -name '*.flat' | sort)
(cd android/build/dex && zip -q -0 ../unsigned.apk classes.dex)
"$BUILD/zipalign" -f -p 4 android/build/unsigned.apk android/build/aligned.apk
# One-off research signing key, NOT for shipping/production. This key must not be reused as a release identity.
keytool -genkeypair -keystore android/build/temporary-research-debug.jks -storepass android -alias research -keypass android -keyalg RSA -keysize 2048 -validity 365 -dname 'CN=UNO N007 Research,O=UNOVYRA,C=XX' -noprompt >/dev/null 2>&1
"$BUILD/apksigner" sign --ks android/build/temporary-research-debug.jks --ks-key-alias research --ks-pass pass:android --key-pass pass:android \
  --out android/build/UNO_N0_07_TINY_F_RESEARCH.apk android/build/aligned.apk
"$BUILD/apksigner" verify --verbose --print-certs android/build/UNO_N0_07_TINY_F_RESEARCH.apk
"$BUILD/aapt" dump badging android/build/UNO_N0_07_TINY_F_RESEARCH.apk | head -10
"$BUILD/aapt" dump permissions android/build/UNO_N0_07_TINY_F_RESEARCH.apk
unzip -t android/build/UNO_N0_07_TINY_F_RESEARCH.apk | tail -1
sha256sum android/build/UNO_N0_07_TINY_F_RESEARCH.apk
