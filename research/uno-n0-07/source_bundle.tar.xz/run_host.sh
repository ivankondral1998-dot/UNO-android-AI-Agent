#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p core/build
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -d core/build \
    core/src/org/unovyra/n007/TinyOrganism.java \
    core/test/org/json/*.java \
    core/ref_n005/NeuralGraph.java \
    core/test/org/unovyra/n005audit/TinyOrganismHostTest.java
java -cp core/build org.unovyra.n005audit.TinyOrganismHostTest
