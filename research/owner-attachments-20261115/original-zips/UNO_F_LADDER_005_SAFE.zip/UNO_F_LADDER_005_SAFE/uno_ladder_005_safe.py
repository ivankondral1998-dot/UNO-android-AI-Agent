"""Fail-safe research runner for Claude's UNO F LADDER 005.

Keeps original UNO F, data generator, GRU and comparison math unchanged.
Adds atomic optimizer+model checkpoints, stepwise timeout, and no blocking lag
profile in the training process. Does NOT magically recover the old in-memory
1500 steps of an already-running original trainer.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

import torch
from torch.nn import functional as F
import uno_ladder_005 as original


def atomic_torch_save(obj, path: Path):
    tmp = path.with_suffix(path.suffix + '.tmp')
    torch.save(obj, tmp)
    os.replace(tmp, path)


def atomic_json_save(obj, path: Path):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
    os.replace(tmp, path)


class StrictGuard(original.Guard):
    """Fail closed on sensor errors, unlike the original runner."""
    def poll(self):
        try:
            proc = subprocess.run(
                ['nvidia-smi', '--query-gpu=temperature.gpu,memory.used',
                 '--format=csv,noheader,nounits'],
                capture_output=True, text=True, check=True, timeout=5,
            )
            line = proc.stdout.strip().splitlines()[0]
            temp, mem = [float(v.strip()) for v in line.split(',')]
            if not (0.0 < temp < 150.0 and mem >= 0.0):
                raise ValueError('implausible sensor values')
        except Exception as exc:
            raise RuntimeError('STOP: unable to monitor GPU temperature/memory') from exc
        self.peak_temp = max(self.peak_temp, temp)
        self.peak_mib = max(self.peak_mib, mem)
        if temp >= self.max_temp or mem >= self.max_mib:
            raise RuntimeError(f'STOP: GPU {temp} C / {mem} MiB exceeds safe threshold')


def train_one(name, rung, args, device, guard, outdir):
    torch.manual_seed(args.seed)
    model = original.build(name).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = torch.Generator().manual_seed(args.seed + 101)
    ck = outdir / f'{rung}__{name}.checkpoint.pt'
    params = sum(p.numel() for p in model.parameters())
    hist = []
    solved_at = None
    streak = 0
    completed = 0
    t0 = time.time()
    fingerprint = {
        'schema': 'UNO_F_LADDER_005_SAFE_V1',
        'name': name, 'rung': rung, 'seed': args.seed,
        'lr': args.lr, 'warmup': args.warmup,
        'batch': args.batch, 'eval_every': args.eval_every,
        'core_sha': original.CORE_SHA,
    }

    if ck.exists():
        stored = torch.load(ck, map_location=device, weights_only=True)
        if stored.get('fingerprint') != fingerprint:
            raise RuntimeError(f'Checkpoint config mismatch: {ck}; do not overwrite it')
        if args.steps < int(stored['step']):
            raise RuntimeError('New steps count smaller than saved checkpoint step')
        model.load_state_dict(stored['model'])
        opt.load_state_dict(stored['optimizer'])
        rng.set_state(stored['data_rng'])
        torch.set_rng_state(stored['cpu_rng'].cpu())
        if device.type == 'cuda' and stored.get('cuda_rng') is not None:
            torch.cuda.set_rng_state_all(stored['cuda_rng'])
        completed = int(stored['step'])
        hist = stored['hist']
        solved_at = stored.get('solved_at')
        streak = int(stored['streak'])
        print(f'RESUMED {rung} {name} from step {completed}', flush=True)

    def checkpoint(step):
        # All data are tensors, primitives and dicts; safe weights_only reload.
        obj = {
            'fingerprint': fingerprint, 'step': step,
            'model': model.state_dict(), 'optimizer': opt.state_dict(),
            'data_rng': rng.get_state(), 'cpu_rng': torch.get_rng_state(),
            'cuda_rng': torch.cuda.get_rng_state_all() if device.type == 'cuda' else None,
            'hist': hist, 'solved_at': solved_at, 'streak': streak,
        }
        atomic_torch_save(obj, ck)
        print(f'SAVED {rung} {name} step={step}', flush=True)

    if not solved_at:
        for step in range(completed + 1, args.steps + 1):
            if not guard.time_ok():
                checkpoint(step - 1)
                print(f'TIME_LIMIT in {rung} {name}: resume via START_SAFE_005.cmd', flush=True)
                return None
            if device.type == 'cuda' and step % 50 == 1:
                # Fail closed if the sensor is unavailable.
                guard.poll()
            model.train()
            length = original.TRAIN_LENGTHS[int(torch.randint(
                0, len(original.TRAIN_LENGTHS), (1,), generator=rng))]
            x, y = original.make_batch(args.batch, length, rung, rng)
            for group in opt.param_groups:
                group['lr'] = args.lr * min(1.0, step / args.warmup)
            opt.zero_grad(set_to_none=True)
            lg, _ = model.sequence(x.to(device))
            loss = F.binary_cross_entropy_with_logits(lg, y.to(device))
            if not torch.isfinite(loss):
                raise RuntimeError('nonfinite loss')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            opt.step()
            model.after_step()
            if step % args.eval_every == 0 or step == args.steps:
                ev = original.evaluate(model, device, rung, 24, args.seed + 5, 512)
                row = {
                    'step': step, 'train_bce': round(loss.item(), 4),
                    'eval24_acc': ev['acc'], 'sec': round(time.time() - t0),
                }
                hist.append(row)
                print(name, rung, json.dumps(row), flush=True)
                streak = streak + 1 if ev['acc'] >= 0.98 else 0
                if streak >= 2:
                    solved_at = step
            if step % args.save_every == 0 or step == args.steps or solved_at:
                checkpoint(step)
            if solved_at:
                break
    last_step = solved_at if solved_at else args.steps
    if not ck.exists():
        checkpoint(last_step)
    print(f'POSTTRAIN {rung} {name} step={last_step}; checkpoint saved', flush=True)

    res = {
        'model': name, 'rung': rung, 'params': params,
        'steps_run': last_step, 'solved_at_step': solved_at,
        'history': hist, 'final': {}, 'erased_control': {},
        'lag_profile_len24': None,
        'lag_profile_status': 'SKIPPED_IN_TRAIN_PROCESS_TO_PREVENT_STALL',
        'checkpoint': ck.name,
    }
    for L in original.EVAL_LENGTHS:
        if device.type == 'cuda':
            guard.poll()
        if not guard.time_ok():
            print(f'TIME_LIMIT during evaluation {rung} {name}; training checkpoint kept', flush=True)
            return None
        res['final'][str(L)] = original.evaluate(
            model, device, rung, L, args.seed + 2000 + L, args.eval_samples)
        res['erased_control'][str(L)] = original.evaluate(
            model, device, rung, L, args.seed + 2000 + L, args.eval_samples, erase=True)
        print(f'EVAL {rung} {name} L{L}: {res["final"][str(L)]["acc"]}', flush=True)
    last = [r['train_bce'] for r in hist[-3:]]
    res['verdict'] = ('SOLVED' if solved_at else
                      'PLATEAU_AT_CHANCE' if last and all(abs(v - 0.69314718) < 0.02 for v in last)
                      else 'PARTIAL')
    res['peak_temp_c'] = guard.peak_temp
    res['peak_gpu_mib'] = guard.peak_mib
    return res


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=r'D:\OwnNeuralNet\uno_ladder_005_gpu')
    ap.add_argument('--device', default='cuda', choices=['cuda', 'cpu'])
    ap.add_argument('--rungs', default=','.join(original.RUNGS))
    ap.add_argument('--models', default='gru,uno_f')
    ap.add_argument('--steps', type=int, default=4000)
    ap.add_argument('--batch', type=int, default=256)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--warmup', type=int, default=100)
    ap.add_argument('--eval-every', type=int, default=250)
    ap.add_argument('--eval-samples', type=int, default=2048)
    ap.add_argument('--save-every', type=int, default=50)
    ap.add_argument('--seed', type=int, default=47)
    ap.add_argument('--max-temp', type=float, default=80)
    ap.add_argument('--max-gpu-used-mib', type=float, default=7000)
    ap.add_argument('--max-minutes', type=float, default=90)
    args = ap.parse_args(argv)
    if min(args.steps, args.batch, args.warmup, args.eval_every, args.eval_samples, args.save_every) <= 0:
        ap.error('training/saving parameters must be positive')
    if original.sha(Path(__file__).parent / 'uno_f_pilot.py') != original.CORE_SHA:
        raise RuntimeError('CORE_SHA mismatch')
    device = torch.device(args.device)
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable')
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    guard = StrictGuard(args.max_temp, args.max_gpu_used_mib, args.max_minutes * 60)
    if device.type == 'cuda':
        guard.poll()  # refuse to start if live monitoring is unavailable
    for rung in args.rungs.split(','):
        for name in args.models.split(','):
            if rung not in original.RUNGS or name not in ('gru', 'uno_f'):
                raise ValueError(f'unsupported pair {rung}/{name}')
            f = out / f'{rung}__{name}.json'
            if f.exists():
                print('SKIP finished result:', f.name, flush=True)
                continue
            if not guard.time_ok():
                print('TIME_LIMIT between runs', flush=True)
                original.summarize(out)
                return
            res = train_one(name, rung, args, device, guard, out)
            if res is None:
                original.summarize(out)
                return
            atomic_json_save(res, f)
            print(f'DONE {rung} {name} verdict={res["verdict"]}', flush=True)
    original.summarize(out)


if __name__ == '__main__':
    main()
