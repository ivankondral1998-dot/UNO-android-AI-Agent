import argparse, json, tempfile, unittest
from pathlib import Path
import torch
import uno_ladder_005 as base
import uno_ladder_005b as r

CUDA = torch.cuda.is_available()


def ns(**kw):
    d = dict(batch=8, lr=1e-3, warmup=20, seed=47, eval_every=25, ckpt_every=50, steps=110, eval_samples=64)
    d.update(kw)
    return argparse.Namespace(**d)


def guard(dev="cpu", secs=1e9):
    return r.Guard(80, 7000, secs, require_monitor=False)


def same_state(a, b, tol=0.0):
    for k in a:
        if tol == 0.0:
            if not torch.equal(a[k].cpu(), b[k].cpu()):
                return False
        elif not torch.allclose(a[k].cpu(), b[k].cpu(), atol=tol, rtol=0):
            return False
    return True


def opt_equal(m1, m2, tol=0.0):
    s1, s2 = m1["opt"]["state"], m2["opt"]["state"]
    if s1.keys() != s2.keys():
        return False
    for k in s1:
        for kk in s1[k]:
            a, b = torch.as_tensor(s1[k][kk]).cpu(), torch.as_tensor(s2[k][kk]).cpu()
            if not (torch.equal(a, b) if tol == 0.0 else torch.allclose(a, b, atol=tol, rtol=0)):
                return False
    return True


def strip(h):
    return [{k: v for k, v in row.items() if k != "sec"} for row in h]


class Crash(RuntimeError):
    pass


class T(unittest.TestCase):
    dev = "cpu"
    tol = 0.0

    def run_cont(self, d, name, rung, a):
        m, tr = r.train_resumable(name, rung, a, torch.device(self.dev), guard(), Path(d) / "c.ckpt.pt")
        return m, tr, torch.load(Path(d) / "c.ckpt.pt", weights_only=True)

    # --- 6: math unchanged
    def test_base_and_core_pinned(self):
        here = Path(r.__file__).parent
        self.assertEqual(base.sha(here / "uno_ladder_005.py"), r.BASE_SHA)
        self.assertEqual(base.sha(here / "uno_f_pilot.py"), r.CORE_SHA)

    def test_same_trajectory_as_original_train_one(self):
        for name in ("gru", "uno_f"):
            a = ns(steps=40, eval_every=20, ckpt_every=20, batch=8)
            o = argparse.Namespace(**vars(a)); o.steps = 40
            with tempfile.TemporaryDirectory() as d:
                orig = base.train_one(name, "r1_single", o, torch.device(self.dev), base.Guard(80, 7000, 1e9), Path(d))
                _, tr = r.train_resumable(name, "r1_single", a, torch.device(self.dev), guard(), Path(d) / "x.ckpt.pt")
            self.assertEqual(strip(orig["history"]), strip(tr["history"]), name)
            self.assertEqual(orig["steps_run"], tr["steps_run"])

    # --- 7: continuous vs interrupted+resumed
    def _resume_equal(self, name, interrupt):
        a = ns()
        dev = torch.device(self.dev)
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            m1, tr1, ck1 = self.run_cont(d1, name, "r1_single", a)
            ck = Path(d2) / "c.ckpt.pt"
            if interrupt == "crash":      # process dies at step 73, only the step-50 checkpoint exists
                def boom(s):
                    if s == 73:
                        raise Crash()
                with self.assertRaises(Crash):
                    r.train_resumable(name, "r1_single", a, dev, guard(), ck, crash_hook=boom)
                self.assertEqual(torch.load(ck, weights_only=True)["step"], 50)
            else:                         # controlled stop at step 61 -> checkpoint at 60
                with self.assertRaises(r.StopTraining):
                    r.train_resumable(name, "r1_single", a, dev, guard(), ck, stop_hook=lambda s: s == 61)
                self.assertEqual(torch.load(ck, weights_only=True)["step"], 60)
            m2, tr2 = r.train_resumable(name, "r1_single", a, dev, guard(), ck)
            ck2 = torch.load(ck, weights_only=True)
            self.assertTrue(same_state(m1.state_dict(), m2.state_dict(), self.tol), "weights differ")
            self.assertTrue(opt_equal(ck1, ck2, self.tol), "Adam state differs")
            self.assertTrue(torch.equal(ck1["rng"], ck2["rng"]), "rng differs")
            self.assertEqual(strip(tr1["history"]), strip(tr2["history"]))
            self.assertEqual(ck1["step"], ck2["step"])

    def test_resume_after_crash_gru(self): self._resume_equal("gru", "crash")
    def test_resume_after_crash_unof(self): self._resume_equal("uno_f", "crash")
    def test_resume_after_timestop_gru(self): self._resume_equal("gru", "stop")
    def test_resume_after_timestop_unof(self): self._resume_equal("uno_f", "stop")

    # --- 1/2: atomicity, corruption, config mismatch
    def test_atomic_and_fallback(self):
        a = ns(steps=60)
        with tempfile.TemporaryDirectory() as d:
            ck = Path(d) / "c.ckpt.pt"
            r.train_resumable("gru", "r1_single", a, torch.device(self.dev), guard(), ck)
            self.assertFalse(list(Path(d).glob("*.tmp")))
            self.assertTrue(ck.with_name("c.ckpt.pt.prev").exists())
            good_prev = torch.load(ck.with_name("c.ckpt.pt.prev"), weights_only=True)["step"]
            ck.write_bytes(b"garbage")
            self.assertEqual(r.load_ckpt(ck)["step"], good_prev)           # falls back to .prev
            ck.with_name("c.ckpt.pt.prev").write_bytes(b"garbage")
            with self.assertRaises(RuntimeError):
                r.load_ckpt(ck)                                              # never silently restart

    def test_config_mismatch_refused(self):
        with tempfile.TemporaryDirectory() as d:
            ck = Path(d) / "c.ckpt.pt"
            r.train_resumable("gru", "r1_single", ns(steps=50), torch.device(self.dev), guard(), ck)
            with self.assertRaises(RuntimeError):
                r.train_resumable("gru", "r1_single", ns(steps=100, lr=5e-4), torch.device(self.dev), guard(), ck)

    # --- 5: limits inside training
    def test_time_limit_inside_training(self):
        with tempfile.TemporaryDirectory() as d:
            ck = Path(d) / "c.ckpt.pt"
            g = guard(secs=0.0)
            with self.assertRaises(r.StopTraining):
                r.train_resumable("gru", "r1_single", ns(), torch.device(self.dev), g, ck)
            self.assertTrue(ck.exists())

    def test_gpu_monitor_silence_and_limits(self):
        g = r.Guard(80, 7000, 1e9, require_monitor=True)
        orig = r.subprocess.run
        try:
            def fail(*a, **k): raise OSError("no nvidia-smi")
            r.subprocess.run = fail
            g.poll(); g.poll()
            with self.assertRaises(r.StopTraining):
                g.poll()
            class R: stdout = "85, 1000\n"
            r.subprocess.run = lambda *a, **k: R()
            g2 = r.Guard(80, 7000, 1e9, True)
            with self.assertRaises(r.StopTraining):
                g2.poll()
        finally:
            r.subprocess.run = orig

    # --- 3/4: saved before diagnostics, lag separate
    def test_weights_saved_before_final_eval_and_not_retrained(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d); a = ns(steps=50, eval_every=25)
            orig = r.final_eval
            def die(*x, **k): raise Crash()
            r.final_eval = die
            try:
                with self.assertRaises(Crash):
                    r.run_pair("r1_single", "gru", a, torch.device(self.dev), guard(), out)
            finally:
                r.final_eval = orig
            p = r.pair_paths(out, "r1_single", "gru")
            self.assertTrue(p["weights"].exists() and p["train"].exists() and not p["final"].exists())
            ot = r.train_resumable
            def nope(*x, **k): raise AssertionError("must not retrain")
            r.train_resumable = nope
            try:
                r.run_pair("r1_single", "gru", a, torch.device(self.dev), guard(), out)
            finally:
                r.train_resumable = ot
            res = json.loads(p["final"].read_text())
            self.assertIsNone(res["lag_profile_len24"]); self.assertIn("comparability_note", res)

    def test_lag_is_separate_stage(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d)
            args = ["--out", d, "--device", self.dev, "--rungs", "r1_single", "--models", "gru,uno_f", "--steps", "30",
                    "--eval-every", "10", "--eval-samples", "64", "--batch", "8", "--max-minutes", "5", "--lag-timeout", "120"]
            self.assertEqual(r.main(["--stage", "train"] + args), 0)
            self.assertFalse(list(out.glob("*.lag.json")))                  # train stage never touches lag_profile
            self.assertEqual(r.main(["--stage", "lag"] + args), 0)
            for n in ("gru", "uno_f"):
                lp = json.loads((out / f"r1_single__{n}.lag.json").read_text())["lag_profile_len24"]
                self.assertEqual(len(lp), 24)
            self.assertTrue((out / "SUMMARY.txt").exists())

    def test_main_stop_returns_2_and_resumes(self):
        with tempfile.TemporaryDirectory() as d:
            args = ["--out", d, "--device", self.dev, "--rungs", "r1_single", "--models", "gru", "--steps", "60",
                    "--eval-every", "20", "--eval-samples", "64", "--batch", "8"]
            self.assertEqual(r.main(["--stage", "train", "--max-minutes", "0"] + args), 2)
            self.assertEqual(r.main(["--stage", "train", "--max-minutes", "5"] + args), 0)
            self.assertTrue((Path(d) / "r1_single__gru.json").exists())

    def test_default_output_dir_is_new(self):
        src = Path(r.__file__).read_text()
        self.assertIn('"../uno_ladder_005b_gpu"', src)
        self.assertNotIn('"../uno_ladder_005_gpu"', src)


@unittest.skipUnless(CUDA, "CUDA not available here: GPU fix NOT verified in this environment")
class TCuda(T):
    dev = "cuda"
    tol = 1e-6          # GPU kernels may differ in the last bits; CPU class above requires exact equality

    def test_gru_lag_profile_on_cuda(self):     # the exact failure seen on the RTX
        m = base.build("gru").to("cuda")
        prof = base.lag_profile(m, torch.device("cuda"), "r1_single")
        self.assertEqual(len(prof), 24)

    def test_unof_lag_profile_on_cuda(self):
        m = base.build("uno_f").to("cuda")
        self.assertEqual(len(base.lag_profile(m, torch.device("cuda"), "r1_single")), 24)


if __name__ == "__main__":
    print("CUDA available:", CUDA)
    unittest.main(verbosity=2)
