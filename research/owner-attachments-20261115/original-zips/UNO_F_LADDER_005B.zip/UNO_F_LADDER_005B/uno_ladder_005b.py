"""UNO F LADDER-005B (research-only): crash-safe runner around the UNCHANGED 005 experiment.

Math is imported, not copied: data generator, UnoF, GRU control, evaluate(), lag_profile() come from
uno_ladder_005.py (SHA-256 pinned below). What 005B adds, and nothing else:
  * atomic checkpoint every 50 steps (weights, Adam, step, RNG, history) + real resume of the current pair
  * weights + training record saved BEFORE final evaluation and BEFORE lag_profile
  * lag_profile as a separate stage with a watchdog (a hang cannot destroy training results)
  * time limit and GPU-monitor health checked inside training; any stop saves a checkpoint first
Comparability caveat: UnoF applies an exact L1-ball projection after every optimizer step; the GRU does not.
"""
from __future__ import annotations
import argparse, json, math, os, subprocess, sys, threading, time
from pathlib import Path
import torch
from torch.nn import functional as F

import uno_ladder_005 as base
from uno_ladder_005 import (RUNGS, TRAIN_LENGTHS, EVAL_LENGTHS, build, evaluate, lag_profile, make_batch, sha)

BASE_SHA = "aa46b28e9924d3f50b08c53c7d0e3ee53aea024eee08d6b0ac126a80f5f4a584"
CORE_SHA = base.CORE_SHA
CFG_KEYS = ("batch", "lr", "warmup", "seed", "eval_every")


class StopTraining(Exception):
    """Controlled stop (time limit, GPU limit, GPU monitor silent). A checkpoint is written first."""


# ---------------------------------------------------------------- checkpoint I/O
def atomic_save(obj, path: Path):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "wb") as f:
        torch.save(obj, f)
        f.flush(); os.fsync(f.fileno())
    if path.exists():
        os.replace(path, path.with_name(path.name + ".prev"))
    os.replace(tmp, path)


def atomic_text(path: Path, text: str):
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def load_ckpt(path: Path):
    cands = [Path(path), Path(path).with_name(Path(path).name + ".prev")]
    existing = [c for c in cands if c.exists()]
    for c in existing:
        try:
            return torch.load(c, map_location="cpu", weights_only=True)
        except Exception as e:  # corrupt / truncated
            print(f"WARNING: cannot read {c.name}: {type(e).__name__}", flush=True)
    if existing:
        raise RuntimeError(f"All checkpoints for {Path(path).name} are unreadable; refusing to restart silently")
    return None


# ---------------------------------------------------------------- guard
class Guard:
    def __init__(self, max_temp, max_mib, max_seconds, require_monitor):
        self.t0 = time.time(); self.max_temp = max_temp; self.max_mib = max_mib
        self.max_seconds = max_seconds; self.require_monitor = require_monitor
        self.peak_temp = 0.0; self.peak_mib = 0.0; self.fails = 0

    def time_ok(self):
        return time.time() - self.t0 <= self.max_seconds

    def poll(self):
        if not self.require_monitor:
            return
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=temperature.gpu,memory.used", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5).stdout.strip().splitlines()[0]
            t, m = [float(v) for v in out.split(",")]
        except Exception:
            self.fails += 1
            if self.fails >= 3:
                raise StopTraining("GPU monitor (nvidia-smi) not responding 3 times in a row")
            return
        self.fails = 0
        self.peak_temp = max(self.peak_temp, t); self.peak_mib = max(self.peak_mib, m)
        if t >= self.max_temp or m >= self.max_mib:
            raise StopTraining(f"GPU limit reached: temp={t} C mem={m} MiB")


# ---------------------------------------------------------------- resumable training (same math as base.train_one)
def train_resumable(name, rung, a, device, guard, ckpt_path, *, stop_hook=None, crash_hook=None):
    torch.manual_seed(a.seed)
    model = build(name).to(device)
    params = sum(p.numel() for p in model.parameters())
    opt = torch.optim.Adam(model.parameters(), lr=a.lr)
    rng = torch.Generator().manual_seed(a.seed + 101)
    hist, solved_at, streak, step, prior = [], None, 0, 0, 0.0
    cfg = {k: getattr(a, k) for k in CFG_KEYS}; cfg.update(model=name, rung=rung)
    ck = load_ckpt(ckpt_path)
    if ck is not None:
        if ck["cfg"] != cfg:
            raise RuntimeError(f"Checkpoint config differs from current run: {ck['cfg']} vs {cfg}")
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); rng.set_state(ck["rng"])
        hist, solved_at, streak, step, prior = ck["hist"], ck["solved_at"], ck["streak"], ck["step"], ck["elapsed"]
        print(f"RESUMED {name} {rung} from step {step}", flush=True)
    t0 = time.time()
    if stop_hook is None:
        stop_hook = lambda s: not guard.time_ok()

    def save():
        atomic_save({"cfg": cfg, "model": model.state_dict(), "opt": opt.state_dict(), "rng": rng.get_state(),
                     "hist": hist, "solved_at": solved_at, "streak": streak, "step": step,
                     "elapsed": prior + time.time() - t0}, ckpt_path)

    while step < a.steps and solved_at is None:
        nxt = step + 1
        if stop_hook(nxt):
            save(); raise StopTraining("time limit reached")
        if crash_hook is not None:
            crash_hook(nxt)
        model.train()
        length = TRAIN_LENGTHS[int(torch.randint(0, len(TRAIN_LENGTHS), (1,), generator=rng))]
        x, y = make_batch(a.batch, length, rung, rng)
        for g in opt.param_groups:
            g["lr"] = a.lr * min(1.0, nxt / a.warmup)
        opt.zero_grad(set_to_none=True)
        lg, _ = model.sequence(x.to(device))
        loss = F.binary_cross_entropy_with_logits(lg, y.to(device))
        if not torch.isfinite(loss):
            raise RuntimeError("nonfinite loss")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step(); model.after_step()
        step = nxt
        if step % a.eval_every == 0 or step == a.steps:
            ev = evaluate(model, device, rung, 24, a.seed + 5, 512)
            row = {"step": step, "train_bce": round(loss.item(), 4), "eval24_acc": ev["acc"],
                   "sec": round(prior + time.time() - t0)}
            hist.append(row); print(name, rung, json.dumps(row), flush=True)
            streak = streak + 1 if ev["acc"] >= 0.98 else 0
            if streak >= 2:
                solved_at = step
        if step % a.ckpt_every == 0 or solved_at is not None or step == a.steps:
            try:
                guard.poll()
            except StopTraining:
                save(); raise
            save()
    return model, {"model": name, "rung": rung, "params": params, "steps_run": step, "solved_at_step": solved_at,
                   "history": hist}


# ---------------------------------------------------------------- pair pipeline
def pair_paths(out: Path, rung, name):
    b = out / f"{rung}__{name}"
    return {"ckpt": Path(str(b) + ".ckpt.pt"), "weights": Path(str(b) + ".weights.pt"),
            "train": Path(str(b) + ".train.json"), "final": Path(str(b) + ".json"), "lag": Path(str(b) + ".lag.json")}


def verdict_of(tr):
    last = [h["train_bce"] for h in tr["history"][-3:]]
    return ("SOLVED" if tr["solved_at_step"] else
            "PLATEAU_AT_CHANCE" if last and all(abs(v - math.log(2)) < 0.02 for v in last) else "PARTIAL")


def final_eval(model, tr, rung, a, device, guard):
    res = dict(tr)
    res["final"], res["erased_control"] = {}, {}
    for L in EVAL_LENGTHS:
        res["final"][str(L)] = evaluate(model, device, rung, L, a.seed + 2000 + L, a.eval_samples)
        res["erased_control"][str(L)] = evaluate(model, device, rung, L, a.seed + 2000 + L, a.eval_samples, erase=True)
    res["verdict"] = verdict_of(tr)
    res["lag_profile_len24"] = None  # filled by the separate lag stage (<pair>.lag.json)
    res["peak_temp_c"] = guard.peak_temp; res["peak_gpu_mib"] = guard.peak_mib
    res["comparability_note"] = ("UnoF is projected onto L1-balls after every step; the GRU is unconstrained. "
                                 "Same data/lr/clip for both; equal tuning is NOT guaranteed (lr not swept).")
    return res


def run_pair(rung, name, a, device, guard, out, **hooks):
    p = pair_paths(out, rung, name)
    if p["final"].exists():
        print("skip (done):", p["final"].name); return
    if p["weights"].exists() and p["train"].exists():
        model = build(name).to(device)
        model.load_state_dict(torch.load(p["weights"], map_location=device, weights_only=True))
        tr = json.loads(p["train"].read_text(encoding="utf-8"))
        print(f"{name} {rung}: training already saved, running final evaluation", flush=True)
    else:
        model, tr = train_resumable(name, rung, a, device, guard, p["ckpt"], **hooks)
        atomic_save({k: v.detach().cpu() for k, v in model.state_dict().items()}, p["weights"])  # BEFORE diagnostics
        atomic_text(p["train"], json.dumps(tr, indent=1))
    res = final_eval(model, tr, rung, a, device, guard)
    atomic_text(p["final"], json.dumps(res, indent=1))
    print("DONE", rung, name, res["verdict"], flush=True)


# ---------------------------------------------------------------- stages
def run_lag_stage(a, device, out):
    for w in sorted(out.glob("*__*.weights.pt")):
        rung, name = w.name[:-len(".weights.pt")].split("__")
        dst = w.with_name(w.name[:-len(".weights.pt")] + ".lag.json")
        if dst.exists():
            continue
        wd = threading.Timer(a.lag_timeout, lambda: os._exit(3)); wd.daemon = True; wd.start()
        try:
            model = build(name).to(device)
            model.load_state_dict(torch.load(w, map_location=device, weights_only=True))
            prof = lag_profile(model, device, rung)
            atomic_text(dst, json.dumps({"rung": rung, "model": name, "lag_profile_len24": prof}))
            print("LAG", rung, name, ["%.1e" % v for v in prof[:8]], flush=True)
        finally:
            wd.cancel()


def summarize(out: Path):
    rows = []
    for f in sorted(out.glob("*__*.json")):
        if f.name.endswith((".train.json", ".lag.json")):
            continue
        r = json.loads(f.read_text(encoding="utf-8"))
        lagf = f.with_name(f.name[:-5] + ".lag.json")
        lag = ""
        if lagf.exists():
            lp = json.loads(lagf.read_text(encoding="utf-8"))["lag_profile_len24"]
            lag = f" | lag0/6/12: {lp[0]:.1e} {lp[6]:.1e} {lp[12]:.1e}"
        accs = " ".join(f"L{L}:{r['final'][L]['acc']:.2f}" for L in r["final"])
        ctl = " ".join(f"{r['erased_control'][L]['acc']:.2f}" for L in r["erased_control"])
        rows.append(f"{r['rung']:13} {r['model']:6} {r['verdict']:18} steps={r['steps_run']:5} | {accs} | erased: {ctl}{lag}")
    text = "\n".join(rows)
    atomic_text(out / "SUMMARY.txt", text + "\n")
    print("\n" + text)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=("train", "lag", "summary"), default="train")
    ap.add_argument("--out", default="../uno_ladder_005b_gpu")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--rungs", default=",".join(RUNGS))
    ap.add_argument("--models", default="gru,uno_f")
    ap.add_argument("--steps", type=int, default=4000)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--warmup", type=int, default=100)
    ap.add_argument("--eval-every", type=int, default=250)
    ap.add_argument("--eval-samples", type=int, default=2048)
    ap.add_argument("--ckpt-every", type=int, default=50)
    ap.add_argument("--seed", type=int, default=47)
    ap.add_argument("--max-temp", type=float, default=80)
    ap.add_argument("--max-gpu-used-mib", type=float, default=7000)
    ap.add_argument("--max-minutes", type=float, default=90)
    ap.add_argument("--lag-timeout", type=float, default=300)
    a = ap.parse_args(argv)
    here = Path(__file__).parent
    if sha(here / "uno_ladder_005.py") != BASE_SHA:
        raise SystemExit("ERROR: uno_ladder_005.py differs from the pinned original (SHA-256 mismatch)")
    if sha(here / "uno_f_pilot.py") != CORE_SHA:
        raise SystemExit("ERROR: uno_f_pilot.py SHA-256 mismatch")
    device = torch.device(a.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("ERROR: CUDA requested but unavailable")
    out = (here / a.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    if a.stage == "summary":
        summarize(out); return 0
    if a.stage == "lag":
        run_lag_stage(a, device, out); summarize(out); return 0
    guard = Guard(a.max_temp, a.max_gpu_used_mib, a.max_minutes * 60, require_monitor=(device.type == "cuda"))
    try:
        guard.poll()
        for rung in a.rungs.split(","):
            for name in a.models.split(","):
                run_pair(rung, name, a, device, guard, out)
    except StopTraining as e:
        print(f"\nSTOPPED: {e}. Checkpoint saved; start again to resume from it.", flush=True)
        summarize(out); return 2
    summarize(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
