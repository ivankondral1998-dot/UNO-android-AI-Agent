"""UNO F LADDER-005 (research-only).

Question: where exactly does the recurrent F stop being able to remember, and is the
data/training setup sound at all? A GRU of similar size (~394k params) is trained on the
SAME data as a control. Existing F (uno_f_pilot.py) is imported unchanged (SHA-256 checked).

Rungs (all: noise in EVERY channel at every non-write event, query on the last event):
  r1_single   one write at random time, answer = sign of written value
  r2_two      two slots, indexed query
  r3_three    three slots, indexed query       (= MEMORY-004 'indexed')
  r4_overwrite three slots + one extra write, last write to queried slot wins
  r5_order    two writes, which slot was written later
Each rung/model trains FROM SCRATCH (no MEMORY-003 weights), so one failure cannot poison the next.
"""
from __future__ import annotations
import argparse, hashlib, json, math, subprocess, sys, time
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
from uno_f_pilot import UnoF

CORE_SHA = "d290ff97eb9c58fd609d97a3c74c2a06c2b5fc0a561a3c9489776e9f8913046a"
RUNGS = ("r1_single", "r2_two", "r3_three", "r4_overwrite", "r5_order")
TRAIN_LENGTHS = (12, 24, 32)
EVAL_LENGTHS = (12, 24, 48, 96)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ---------------------------------------------------------------- data
def make_batch(batch, length, rung, rng, *, erase=False):
    """x[...,0]=value, x[...,1]=slot code, x[...,2]=op (+1 write, 0 noise, -1 indexed query, -2 last-write query).
    Independent of any network. Returns x [B,L,3], y [B] in {0,1}."""
    if rung not in RUNGS or length < 10:
        raise ValueError("bad rung/length")
    x = torch.empty(batch, length, 3)
    x[..., 0] = torch.rand(batch, length, generator=rng) * 2 - 1
    x[..., 1] = torch.rand(batch, length, generator=rng) * 2 - 1
    x[..., 2] = 0
    window = min(length - 2, max(5, (length + 1) // 2))
    ar = torch.arange(batch)
    if rung == "r5_order":
        stamps = torch.rand(batch, window, generator=rng).argsort(1)[:, :2].sort(1).values
        first_pos = torch.randint(0, 2, (batch,), generator=rng).bool()
        code_first = torch.where(first_pos, 1.0, -1.0)
        for j, code in ((0, code_first), (1, -code_first)):
            x[ar, stamps[:, j], 1] = code
            x[ar, stamps[:, j], 2] = 1
        y = (-code_first > 0).float()                       # later write is slot +1 ?
        if erase:
            for j in (0, 1):
                x[ar, stamps[:, j], 1] = 0
        x[:, -1] = torch.tensor([0.0, 0.0, -2.0])
        return x, y
    k = {"r1_single": 1, "r2_two": 2, "r3_three": 3, "r4_overwrite": 3}[rung]
    codes = {1: (0.0,), 2: (-1.0, 1.0), 3: (-1.0, 0.0, 1.0)}[k]
    code_t = torch.tensor(codes)
    n_writes = k + (1 if rung == "r4_overwrite" else 0)
    stamps = torch.rand(batch, window, generator=rng).argsort(1)[:, :n_writes].sort(1).values
    order = torch.rand(batch, k, generator=rng).argsort(1)             # slot written at each of first k stamps
    slots = order
    if rung == "r4_overwrite":
        extra = torch.randint(0, k, (batch, 1), generator=rng)
        slots = torch.cat([order, extra], 1)
    query = torch.randint(0, k, (batch,), generator=rng)
    values = torch.rand(batch, n_writes, generator=rng) * 2 - 1
    last = torch.zeros(batch)
    for j in range(n_writes):                                          # later writes overwrite earlier ones
        hit = slots[:, j] == query
        last = torch.where(hit, values[:, j], last)
    for j in range(n_writes):
        x[ar, stamps[:, j], 0] = values[:, j]
        x[ar, stamps[:, j], 1] = code_t[slots[:, j]]
        x[ar, stamps[:, j], 2] = 1
    y = (last > 0).float()
    if erase:                                                          # keep label, destroy evidence about queried slot
        for j in range(n_writes):
            hit = slots[:, j] == query
            x[ar[hit], stamps[hit, j], 0] = 0.0
    x[:, -1, 0] = 0
    x[:, -1, 1] = code_t[query]
    x[:, -1, 2] = -1
    return x, y


# ---------------------------------------------------------------- models
class GRUControl(nn.Module):
    def __init__(self, h=360):
        super().__init__()
        self.gru = nn.GRU(3, h, batch_first=True)
        self.out = nn.Linear(h, 1)

    def sequence(self, x, **_):
        o, _h = self.gru(x)
        return self.out(o[:, -1]).squeeze(-1), None


class UnoWrap(nn.Module):
    def __init__(self):
        super().__init__()
        self.m = UnoF()

    def sequence(self, x, **_):
        return self.m.sequence(x, mode="full")

    def after_step(self):
        self.m.enforce_constraints()


def build(name):
    m = UnoWrap() if name == "uno_f" else GRUControl()
    if not hasattr(m, "after_step"):
        m.after_step = lambda: None
    return m


# ---------------------------------------------------------------- eval
def evaluate(model, device, rung, length, seed, n, batch=256, erase=False):
    rng = torch.Generator().manual_seed(seed)
    model.eval()
    ok = tot = 0
    loss = 0.0
    with torch.no_grad():
        while tot < n:
            b = min(batch, n - tot)
            x, y = make_batch(b, length, rung, rng, erase=erase)
            lg, _ = model.sequence(x.to(device))
            y = y.to(device)
            ok += int(((lg >= 0) == (y >= .5)).sum()); tot += b
            loss += float(F.binary_cross_entropy_with_logits(lg, y, reduction="sum"))
    p = ok / tot
    return {"acc": round(p, 4), "ci95": round(1.96 * math.sqrt(max(p * (1 - p), 1e-9) / tot), 4),
            "bce": round(loss / tot, 4), "n": tot}


def lag_profile(model, device, rung, length=24, n=128):
    """mean |d logit / d x_t| by distance from the end (lag 0 = last event). Shows how fast history fades."""
    rng = torch.Generator().manual_seed(777)
    x, _ = make_batch(n, length, rung, rng)
    x = x.to(device).requires_grad_(True)
    model.train()  # cuDNN RNN backward needs train mode; no dropout/batchnorm anywhere, so numerics are identical
    lg, _ = model.sequence(x)
    g, = torch.autograd.grad(lg.sum(), x)
    prof = g.abs().sum(-1).mean(0).flip(0).cpu().tolist()
    return [float(f"{v:.3e}") for v in prof]


# ---------------------------------------------------------------- safety
class Guard:
    def __init__(self, max_temp, max_mib, max_seconds):
        self.t0 = time.time(); self.max_temp = max_temp; self.max_mib = max_mib; self.max_seconds = max_seconds
        self.peak_temp = 0.0; self.peak_mib = 0.0

    def time_ok(self):
        return time.time() - self.t0 <= self.max_seconds

    def poll(self):
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=temperature.gpu,memory.used", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5).stdout.strip().splitlines()[0]
            t, m = [float(v) for v in out.split(",")]
        except Exception:
            return
        self.peak_temp = max(self.peak_temp, t); self.peak_mib = max(self.peak_mib, m)
        if t >= self.max_temp or m >= self.max_mib:
            raise SystemExit(f"STOPPED: GPU temp={t} C mem={m} MiB limit reached")


# ---------------------------------------------------------------- train
def train_one(name, rung, args, device, guard, outdir):
    torch.manual_seed(args.seed)
    model = build(name).to(device)
    params = sum(p.numel() for p in model.parameters())
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = torch.Generator().manual_seed(args.seed + 101)
    hist = []; solved_at = None; streak = 0; t0 = time.time()
    for step in range(1, args.steps + 1):
        if step % 50 == 1:
            guard.poll()
        model.train()
        length = TRAIN_LENGTHS[int(torch.randint(0, len(TRAIN_LENGTHS), (1,), generator=rng))]
        x, y = make_batch(args.batch, length, rung, rng)
        for g in opt.param_groups:
            g["lr"] = args.lr * min(1.0, step / args.warmup)
        opt.zero_grad(set_to_none=True)
        lg, _ = model.sequence(x.to(device))
        loss = F.binary_cross_entropy_with_logits(lg, y.to(device))
        if not torch.isfinite(loss):
            raise RuntimeError("nonfinite loss")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step(); model.after_step()
        if step % args.eval_every == 0 or step == args.steps:
            ev = evaluate(model, device, rung, 24, args.seed + 5, 512)
            row = {"step": step, "train_bce": round(loss.item(), 4), "eval24_acc": ev["acc"], "sec": round(time.time() - t0)}
            hist.append(row); print(name, rung, json.dumps(row), flush=True)
            streak = streak + 1 if ev["acc"] >= 0.98 else 0
            if streak >= 2:
                solved_at = step; break
    res = {"model": name, "rung": rung, "params": params, "steps_run": step, "solved_at_step": solved_at,
           "history": hist, "final": {}, "erased_control": {}, "lag_profile_len24": lag_profile(model, device, rung)}
    for L in EVAL_LENGTHS:
        res["final"][str(L)] = evaluate(model, device, rung, L, args.seed + 2000 + L, args.eval_samples)
        res["erased_control"][str(L)] = evaluate(model, device, rung, L, args.seed + 2000 + L, args.eval_samples, erase=True)
    last = [h["train_bce"] for h in hist[-3:]]
    res["verdict"] = ("SOLVED" if solved_at else
                      "PLATEAU_AT_CHANCE" if last and all(abs(v - math.log(2)) < 0.02 for v in last) else "PARTIAL")
    return res


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="../uno_ladder_005_gpu")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--rungs", default=",".join(RUNGS))
    ap.add_argument("--models", default="gru,uno_f")
    ap.add_argument("--steps", type=int, default=4000)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--warmup", type=int, default=100)
    ap.add_argument("--eval-every", type=int, default=250)
    ap.add_argument("--eval-samples", type=int, default=2048)
    ap.add_argument("--seed", type=int, default=47)
    ap.add_argument("--max-temp", type=float, default=80)
    ap.add_argument("--max-gpu-used-mib", type=float, default=7000)
    ap.add_argument("--max-minutes", type=float, default=90)
    a = ap.parse_args(argv)
    here = Path(__file__).parent
    if sha(here / "uno_f_pilot.py") != CORE_SHA:
        raise SystemExit("ERROR: uno_f_pilot.py SHA-256 mismatch")
    device = torch.device(a.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("ERROR: CUDA requested but unavailable")
    out = (here / a.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    guard = Guard(a.max_temp, a.max_gpu_used_mib, a.max_minutes * 60)
    for rung in a.rungs.split(","):
        for name in a.models.split(","):
            f = out / f"{rung}__{name}.json"
            if f.exists():
                print("skip (done):", f.name); continue
            if not guard.time_ok():
                print("TIME LIMIT reached between runs. Finished runs are saved; start again to continue."); summarize(out); return
            res = train_one(name, rung, a, device, guard, out)
            res["peak_temp_c"] = guard.peak_temp; res["peak_gpu_mib"] = guard.peak_mib
            f.write_text(json.dumps(res, indent=1), encoding="utf-8")
            print("DONE", rung, name, res["verdict"], flush=True)
    summarize(out)


def summarize(out: Path):
    rows = []
    for f in sorted(out.glob("*__*.json")):
        r = json.loads(f.read_text(encoding="utf-8"))
        accs = " ".join(f"L{L}:{r['final'][L]['acc']:.2f}" for L in r["final"])
        ctl = " ".join(f"{r['erased_control'][L]['acc']:.2f}" for L in r["erased_control"])
        rows.append(f"{r['rung']:13} {r['model']:6} {r['verdict']:18} steps={r['steps_run']:5} | {accs} | erased: {ctl}")
    text = "\n".join(rows)
    (out / "SUMMARY.txt").write_text(text + "\n", encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
