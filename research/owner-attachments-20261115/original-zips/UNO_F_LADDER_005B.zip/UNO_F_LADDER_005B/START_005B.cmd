@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_ladder_005b_gpu"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing: %PY% & goto FAIL)
echo === Step 1/3: checks (CPU + CUDA) ===
"%PY%" -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)"
if errorlevel 1 (echo ERROR: CUDA not available & goto FAIL)
"%PY%" -m unittest test_ladder_005b
if errorlevel 1 (echo CHECKS FAILED - run not started & goto FAIL)
echo === Step 2/3: training (checkpoint every 50 steps; run this file again to resume) ===
"%PY%" uno_ladder_005b.py --stage train --device cuda --out "%OUT%" --steps 4000 --batch 256 --eval-samples 2048 --ckpt-every 50 --max-temp 80 --max-gpu-used-mib 7000 --max-minutes 90
if errorlevel 1 goto STOPPED
echo === Step 3/3: lag profile (separate process, 300 s watchdog) ===
"%PY%" uno_ladder_005b.py --stage lag --device cuda --out "%OUT%" --lag-timeout 300
echo.
echo DONE. See %OUT%\SUMMARY.txt
pause
exit /b 0
:STOPPED
echo.
echo STOPPED by a limit or an error. Checkpoint is saved: run START_005B.cmd again to resume.
pause
exit /b 2
:FAIL
echo.
echo REFUSED. Nothing was changed.
pause
exit /b 1
