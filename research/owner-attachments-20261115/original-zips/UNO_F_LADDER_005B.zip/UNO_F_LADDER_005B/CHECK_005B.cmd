@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing: %PY% & pause & exit /b 1)
"%PY%" -c "import torch,sys; print('torch',torch.__version__,'CUDA available:',torch.cuda.is_available()); sys.exit(0 if torch.cuda.is_available() else 1)"
if errorlevel 1 (echo ERROR: CUDA not available - GPU checks cannot run & pause & exit /b 1)
"%PY%" -m unittest -v test_ladder_005b
if errorlevel 1 (echo CHECKS FAILED - do not start the run & pause & exit /b 1)
echo CHECKS PASSED (CPU and CUDA classes; look for "skipped" in the summary - there must be none)
pause
