@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_f_working_memory_004_gpu"
set "SOURCE=D:\OwnNeuralNet\uno_f_memory_003_gpu\weights_step_000060_research_only.pt"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing: %PY% & goto FAIL)
if not exist "%SOURCE%" (echo ERROR: MEMORY-003 weights missing: %SOURCE% & goto FAIL)
if exist "%OUT%\run_manifest.json" (echo REFUSED: run exists. Use RESUME_004.cmd. & goto FAIL)
"%PY%" uno_working_memory.py --device cuda --output "%OUT%" --init-weights "%SOURCE%" --steps 240 --batch 24 --eval-samples 192 --max-temp 80 --max-gpu-used-mib 7000 --max-seconds 600
if errorlevel 1 goto FAIL
echo.
echo SUCCESS. Results: %OUT%
pause
exit /b 0
:FAIL
echo.
echo STOPPED OR REFUSED. Older models were not modified.
pause
exit /b 1
