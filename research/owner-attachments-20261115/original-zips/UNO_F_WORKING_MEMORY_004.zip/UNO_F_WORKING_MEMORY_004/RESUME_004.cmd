@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_f_working_memory_004_gpu"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing & goto FAIL)
if not exist "%OUT%\run_manifest.json" (echo ERROR: No existing 004 run. Use START_004.cmd. & goto FAIL)
"%PY%" uno_working_memory.py --device cuda --output "%OUT%" --resume --steps 240 --batch 24 --eval-samples 192 --max-temp 80 --max-gpu-used-mib 7000 --max-seconds 600
if errorlevel 1 goto FAIL
echo.
echo SUCCESS. Results: %OUT%
pause
exit /b 0
:FAIL
echo.
echo STOPPED OR REFUSED. See error above.
pause
exit /b 1
