@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python not found & pause & exit /b 1)
"%PY%" -m unittest -v test_working_memory_004
if errorlevel 1 (echo TESTS FAILED & pause & exit /b 1)
echo TESTS PASSED
pause
