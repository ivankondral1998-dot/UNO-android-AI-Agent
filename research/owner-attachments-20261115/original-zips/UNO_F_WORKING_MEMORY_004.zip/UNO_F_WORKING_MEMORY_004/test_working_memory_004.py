"""CPU tests. Run: python -m unittest -v test_working_memory_004"""
import json
import tempfile
import unittest
from pathlib import Path

import torch
from uno_f_pilot import UnoF
from uno_gpu_safe import Guard, InputError, digest
from uno_working_memory import (NEW_TASKS, new_batch, legacy_batch, check_sources,
                                init_verified, eval_case, latest_checkpoint)


class WorkingMemory004Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.device = torch.device('cpu')

    def rng(self, seed=13):
        return torch.Generator(device='cpu').manual_seed(seed)

    def test_core_untouched(self):
        check_sources()

    def test_label_from_latest_matching_write(self):
        for task in NEW_TASKS:
            for length in (12,24,48,96):
                with self.subTest(task=task,length=length):
                    x, label = new_batch(40,length,task,self.rng(),self.device)
                    self.assertEqual(tuple(x.shape),(40,length,3))
                    self.assertEqual(tuple(label.shape),(40,))
                    self.assertTrue(torch.all(x[:,-1,0]==0).item())
                    self.assertEqual((x[:,:,:-1].isfinite().all()).item(),True)
                    reconstructed = []
                    for i in range(len(label)):
                        writes=(x[i,:,2]==1).nonzero().flatten().tolist()
                        self.assertLess(max(writes),length//2+1)
                        if task=='order':
                            self.assertEqual(len(writes),2)
                            expected=float(x[i,writes[-1],1]>0)
                            self.assertEqual(float(x[i,-1,2]),-2.)
                        else:
                            self.assertEqual(len(writes),4 if task=='overwrite' else 3)
                            slot=x[i,-1,1]
                            candidates=[t for t in writes if x[i,t,1]==slot]
                            self.assertTrue(candidates)
                            expected=float(x[i,candidates[-1],0]>0)
                            self.assertEqual(float(x[i,-1,2]),-1.)
                        reconstructed.append(expected)
                    self.assertTrue(torch.equal(torch.tensor(reconstructed),label))

    def test_erased_target_has_no_evidence_and_y_unchanged(self):
        for task in NEW_TASKS:
            x,y = new_batch(32,24,task,self.rng(37),self.device)
            erased,y2 = new_batch(32,24,task,self.rng(37),self.device,erase_target=True)
            self.assertTrue(torch.equal(y,y2))
            self.assertTrue(torch.equal(x[:,:,2],erased[:,:,2]))
            self.assertTrue(torch.equal(x[:,-1],erased[:,-1]))
            for i in range(len(y)):
                writes=(x[i,:,2]==1).nonzero().flatten().tolist()
                if task=='order':
                    self.assertTrue(torch.all(erased[i,writes,1]==0).item())
                    self.assertTrue(torch.equal(x[i,:,0],erased[i,:,0]))
                else:
                    selected=x[i,-1,1]
                    for t in writes:
                        if x[i,t,1]==selected:
                            self.assertEqual(float(erased[i,t,0]),0.)
                        else:
                            self.assertEqual(float(x[i,t,0]),float(erased[i,t,0]))

    def test_repeatable_generator(self):
        for task in NEW_TASKS:
            first = new_batch(18,96,task,self.rng(99),self.device)
            second = new_batch(18,96,task,self.rng(99),self.device)
            self.assertTrue(all(torch.equal(a,b) for a,b in zip(first,second)))

    def test_random_label_balance(self):
        for task in NEW_TASKS:
            _, y = new_batch(1500,12,task,self.rng(22),self.device)
            self.assertLess(abs(y.mean().item() - .5),.06)

    def test_legacy_distribution(self):
        x,y = legacy_batch(16,24,self.rng(),self.device)
        self.assertTrue(torch.equal(y,(x[:,0,0]>0).float()))
        self.assertTrue(torch.all(x[:,-1,2]==1).item())

    def test_full_and_sparse_forward(self):
        model = UnoF().eval()
        for task in NEW_TASKS:
            x,y = new_batch(3,12,task,self.rng(),self.device)
            for mode in ('full','prefix1'):
                logits,trace = model.sequence(x,mode=mode)
                self.assertEqual(tuple(logits.shape),(3,))
                self.assertTrue(bool(torch.isfinite(logits).all().item()))
                if mode=='prefix1':self.assertGreater(trace['skipped_blocks'],0)
                else:self.assertEqual(trace['skipped_blocks'],0)
        self.assertLess(model.max_violation(),1e-5)

    def test_hash_verified_pretrained_loading(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp)/'weights_step_000060_research_only.pt'
            torch.save(UnoF().state_dict(),p)
            sha=digest(p)
            p.with_suffix('.sha256.json').write_text(json.dumps({'file':p.name,'sha256':sha}),encoding='utf8')
            self.assertEqual(init_verified(UnoF(),p),sha)
            p.with_suffix('.sha256.json').write_text(json.dumps({'file':p.name,'sha256':'0'*64}),encoding='utf8')
            with self.assertRaises(InputError):init_verified(UnoF(),p)

    def test_checkpoint_missing_refused(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(InputError):latest_checkpoint(Path(temp))

    def test_evaluation_evidence_controls(self):
        model = UnoF().eval()
        guard = Guard(self.device,max_temp=80,max_gpu_used_mib=7000,max_seconds=150)
        for task in NEW_TASKS:
            full=eval_case(model,guard,self.device,task=task,length=12,seed=123,n=16,batch=8)
            erased=eval_case(model,guard,self.device,task=task,length=12,seed=123,n=16,batch=8,erased=True)
            self.assertEqual(full['samples'],16)
            self.assertEqual(erased['samples'],16)
            self.assertTrue(0<=full['accuracy']<=1)

if __name__ == '__main__':unittest.main()
