@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_f_memory_003_gpu"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python not found & goto FAIL)
if not exist "%OUT%\run_manifest.json" (echo ERROR: no previous run to resume & goto FAIL)
"%PY%" uno_long_memory.py --device cuda --output "%OUT%" --resume --steps 60 --batch 32 --eval-samples 256 --max-temp 80 --max-gpu-used-mib 7000 --max-seconds 480
if errorlevel 1 goto FAIL
echo.
echo SUCCESS: %OUT%
pause
exit /b 0
:FAIL
echo.
echo STOPPED OR REFUSED: inspect output above.
pause
exit /b 1
