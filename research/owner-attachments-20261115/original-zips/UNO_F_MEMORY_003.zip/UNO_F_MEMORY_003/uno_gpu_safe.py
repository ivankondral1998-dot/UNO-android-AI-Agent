"""UNO F research pilot: conservative GPU guard, BF16 option, atomic checkpoints.

Research-only. Does not modify UNO production or previous pilot weights.
No external dependencies beyond the existing PyTorch environment.
"""
from __future__ import annotations

import argparse
from contextlib import nullcontext
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import random
import secrets
import subprocess
import sys
import time

import torch
from torch.nn import functional as F

from uno_f_pilot import UnoF, evaluate, make_batch, measure

CORE_SHA256 = "d290ff97eb9c58fd609d97a3c74c2a06c2b5fc0a561a3c9489776e9f8913046a"
VERSION = 2


class SafetyStop(RuntimeError):
    pass


class InputError(RuntimeError):
    pass


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def save_json_new(path: Path, document: dict) -> None:
    with path.open("x", encoding="utf-8") as out:
        json.dump(document, out, indent=2, ensure_ascii=False)
        out.write("\n")


def append_event(outdir: Path, event: dict) -> None:
    with (outdir / "events.jsonl").open("a", encoding="utf-8") as out:
        out.write(json.dumps({"utc": utc(), **event}, ensure_ascii=False, allow_nan=False) + "\n")


def parse_smi_output(s: str) -> dict:
    """Only rely on documented nvidia-smi numeric CSV columns; refuse unknown telemetry."""
    first = s.strip().splitlines()[0] if s.strip() else ""
    cols = [a.strip().strip('"') for a in first.split(",")]
    if len(cols) != 4:
        raise SafetyStop(f"GPU_MONITOR_BAD_CSV: {first[:120]!r}")
    try:
        temp, used, total = [float(cols[i].replace(" MiB", "").replace(" C", "")) for i in range(3)]
    except ValueError as exc:
        raise SafetyStop("GPU_MONITOR_MISSING_TEMPERATURE_OR_MEMORY") from exc
    power = None
    try:
        power = float(cols[3].replace(" W", ""))
    except ValueError:
        pass  # nvidia-smi may report N/A for power on some systems
    if any(not math.isfinite(v) for v in (temp, used, total)) or temp < -30 or total < 256 or not 0 <= used <= total + 1024:
        raise SafetyStop("GPU_MONITOR_INVALID_VALUES")
    return {"gpu_temp_c": temp, "gpu_used_mib": used, "gpu_total_mib": total, "gpu_power_w": power}


class Guard:
    def __init__(self, device: torch.device, *, max_temp: float, max_gpu_used_mib: int, max_seconds: float):
        self.device = device
        self.max_temp = max_temp
        self.max_gpu_used_mib = max_gpu_used_mib
        self.max_seconds = max_seconds
        self.start = time.monotonic()
        self.highest_temp = None
        self.highest_used = None
        self.poll_count = 0

    def poll(self) -> dict:
        seconds = round(time.monotonic() - self.start, 2)
        if seconds >= self.max_seconds:
            raise SafetyStop(f"TIME_BUDGET_REACHED: {seconds:.1f}s >= {self.max_seconds:.1f}s")
        if self.device.type == "cpu":
            return {"elapsed_s": seconds, "device": "cpu"}
        try:
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            p = subprocess.run([
                "nvidia-smi", "--id=0",
                "--query-gpu=temperature.gpu,memory.used,memory.total,power.draw",
                "--format=csv,noheader,nounits"
            ], capture_output=True, text=True, timeout=6, check=False, creationflags=creationflags)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise SafetyStop(f"GPU_MONITOR_UNAVAILABLE: {exc}") from exc
        if p.returncode != 0:
            raise SafetyStop(f"GPU_MONITOR_FAILED: {p.stderr[:200]}")
        metrics = parse_smi_output(p.stdout)
        metrics.update({"elapsed_s": seconds, "device": "cuda"})
        self.poll_count += 1
        t = metrics["gpu_temp_c"]
        mem = metrics["gpu_used_mib"]
        self.highest_temp = max(t, self.highest_temp or t)
        self.highest_used = max(mem, self.highest_used or mem)
        if t >= self.max_temp:
            raise SafetyStop(f"GPU_TEMPERATURE_LIMIT: {t:g}C >= {self.max_temp:g}C")
        if mem >= self.max_gpu_used_mib:
            raise SafetyStop(f"GPU_MEMORY_LIMIT: {mem:g}MiB >= {self.max_gpu_used_mib}MiB")
        return metrics


def precision_context(device: torch.device, precision: str):
    if device.type == "cuda" and precision == "bf16":
        return torch.autocast(device_type="cuda", dtype=torch.bfloat16)
    return nullcontext()


def bf16_preflight(model: UnoF, device: torch.device, task: str, seed: int) -> dict:
    """Numerical sanity check before BF16 training. Not a complete AMP equivalence proof."""
    generator = torch.Generator(device="cpu").manual_seed(seed + 8901)
    x, y = make_batch(64, generator, device, task=task)
    model.eval()
    with torch.no_grad():
        logits32, _ = model.sequence(x)
        with precision_context(device, "bf16"):
            logits16, _ = model.sequence(x)
    delta = (logits32.float() - logits16.float()).abs()
    max_err = delta.max().item()
    mean_err = delta.mean().item()
    flips = ((logits32 >= 0) != (logits16 >= 0)).sum().item()
    report = {"max_abs_logit_delta": max_err, "mean_abs_logit_delta": mean_err, "sign_disagreements": flips, "samples": 64}
    if not math.isfinite(max_err) or max_err > 0.15 or flips > 3:
        raise SafetyStop(f"BF16_PREFLIGHT_FAILED: {report}")
    return report


def checkpoint_payload(model, optimizer, generator, *, step, cfg, device, initial, run_id) -> dict:
    # Only builtins and tensors: torch.load(..., weights_only=True) on restore.
    return {
        "version": VERSION,
        "core_sha256": CORE_SHA256,
        "run_id": run_id,
        "step": step,
        "config": cfg,
        "initial": initial,
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "train_generator_state": generator.get_state(),
        "torch_cpu_rng_state": torch.get_rng_state(),
        "torch_cuda_rng_state": torch.cuda.get_rng_state(device) if device.type == "cuda" else None,
    }


def save_checkpoint(outdir, model, optimizer, generator, *, step, cfg, device, initial, run_id) -> Path:
    path = outdir / f"checkpoint_step_{step:06d}.pt"
    tmp = outdir / f".checkpoint_step_{step:06d}.tmp"
    if path.exists() or tmp.exists():
        raise InputError(f"CHECKPOINT_ALREADY_EXISTS: {path}")
    try:
        torch.save(checkpoint_payload(model, optimizer, generator, step=step, cfg=cfg, device=device, initial=initial, run_id=run_id), tmp)
        sha = digest(tmp)
        # os.replace is atomic on the same volume; never replace an existing checkpoint.
        if path.exists():
            raise InputError(f"CHECKPOINT_ALREADY_EXISTS: {path}")
        os.replace(tmp, path)
        save_json_new(path.with_suffix(".sha256.json"), {"file": path.name, "sha256": sha, "step": step})
    finally:
        if tmp.exists():
            try:
                tmp.unlink()  # only an unfinished temporary file created by this function
            except OSError:
                pass
    return path


def load_checkpoint(path: Path, *, device: torch.device, cfg: dict, run_id: str) -> dict:
    sha_path = path.with_suffix(".sha256.json")
    if not path.is_file() or not sha_path.is_file():
        raise InputError("RESUME_CHECKPOINT_OR_SHA_MISSING")
    sha = json.loads(sha_path.read_text(encoding="utf-8"))
    if sha.get("file") != path.name or sha.get("sha256") != digest(path):
        raise InputError("RESUME_CHECKPOINT_SHA_MISMATCH")
    chk = torch.load(path, map_location=device, weights_only=True)
    if chk.get("version") != VERSION or chk.get("core_sha256") != CORE_SHA256:
        raise InputError("RESUME_CHECKPOINT_FORMAT_OR_SOURCE_MISMATCH")
    if chk.get("run_id") != run_id:
        raise InputError("RESUME_CHECKPOINT_BELONGS_TO_ANOTHER_RUN")
    if chk.get("config") != cfg:
        raise InputError("RESUME_SETTINGS_MISMATCH: seed/batch/lr/task/precision cannot change within a run")
    if chk.get("step") != sha.get("step") or not isinstance(chk.get("step"), int):
        raise InputError("RESUME_STEP_MISMATCH")
    return chk


def save_final_weights(outdir: Path, model, step: int, stats: dict) -> Path:
    path = outdir / f"weights_step_{step:06d}_research_only.pt"
    if path.exists():
        raise InputError(f"WEIGHTS_ALREADY_EXISTS: {path}")
    # Keep the GPU training model alive; move individual tensors to CPU.
    state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
    torch.save(state, path)
    sha = digest(path)
    save_json_new(path.with_suffix(".sha256.json"), {"file": path.name, "sha256": sha})
    stats.update({"weights_file": path.name, "weights_sha256": sha})
    save_json_new(outdir / f"metrics_step_{step:06d}.json", stats)
    return path


def valid_init_weights(path: Path, manifest: Path | None, device: torch.device) -> dict:
    if not path.is_file():
        raise InputError(f"INIT_WEIGHTS_MISSING: {path}")
    if manifest is None:
        raise InputError("INIT_WEIGHTS_REQUIRE_METRICS_MANIFEST_FOR_SHA_VERIFY")
    item = json.loads(manifest.read_text(encoding="utf-8"))
    expected = item.get("weights_sha256")
    if not isinstance(expected, str) or digest(path) != expected:
        raise InputError("INIT_WEIGHTS_SHA_MISMATCH")
    return torch.load(path, map_location=device, weights_only=True)


def train(args):
    if hashlib.sha256((Path(__file__).parent / "uno_f_pilot.py").read_bytes()).hexdigest() != CORE_SHA256:
        raise InputError("UNO_CORE_SHA_MISMATCH: refusing to run changed math code")
    if args.steps < 1 or args.batch < 1 or args.monitor_every < 1 or args.checkpoint_every < 1:
        raise InputError("STEPS_BATCH_MONITOR_AND_CHECKPOINT_MUST_BE_POSITIVE")
    if not 45 <= args.max_temp <= 85 or not 512 <= args.max_gpu_used_mib <= 100000 or args.max_seconds <= 0:
        raise InputError("BAD_SAFETY_LIMIT")
    if not math.isfinite(args.lr) or not 0 < args.lr <= 0.01:
        raise InputError("BAD_LEARNING_RATE")
    if args.resume and args.init_weights:
        raise InputError("RESUME_AND_INIT_WEIGHTS_ARE_MUTUALLY_EXCLUSIVE")
    if bool(args.init_weights) != bool(args.init_metrics):
        raise InputError("INIT_WEIGHTS_AND_INIT_METRICS_MUST_BE_PAIRED")
    if args.precision == "bf16" and args.device != "cuda":
        raise InputError("BF16_ONLY_SUPPORTED_FOR_CUDA_IN_THIS_PILOT")

    device = torch.device(args.device)
    if device.type == "cuda":
        if not torch.cuda.is_available():
            raise SafetyStop("CUDA_UNAVAILABLE: refusing silent CPU fallback")
        if args.precision == "bf16" and not torch.cuda.is_bf16_supported():
            raise SafetyStop("BF16_UNSUPPORTED_ON_THIS_GPU")
    torch.set_num_threads(min(torch.get_num_threads(), 4))
    guard = Guard(device, max_temp=args.max_temp, max_gpu_used_mib=args.max_gpu_used_mib, max_seconds=args.max_seconds)
    sample = guard.poll()  # preflight: if monitoring is unavailable, fail closed
    if device.type == "cuda":
        total = torch.cuda.get_device_properties(0).total_memory / 1048576
        # Leave safety headroom for Windows / other graphics workloads.
        allowed = args.max_gpu_used_mib - sample["gpu_used_mib"] - 256
        if allowed < 512:
            raise SafetyStop("GPU_NOT_ENOUGH_FREE_HEADROOM")
        fraction = max(0.01, min(0.95, allowed / total))
        torch.cuda.set_per_process_memory_fraction(fraction, 0)

    outdir = Path(args.output).resolve()
    cfg = {"seed": args.seed, "batch": args.batch, "lr": args.lr, "task": args.task, "precision": args.precision}
    is_resume = bool(args.resume)
    if is_resume:
        if not outdir.is_dir() or not (outdir / "run_manifest.json").is_file():
            raise InputError("RESUME_OUTPUT_DIRECTORY_NOT_FOUND")
        manifest = json.loads((outdir / "run_manifest.json").read_text(encoding="utf-8"))
        run_id = manifest.get("run_id")
        if not isinstance(run_id, str) or len(run_id) != 32:
            raise InputError("RESUME_RUN_ID_MISSING")
        if manifest.get("config") != cfg or manifest.get("core_sha256") != CORE_SHA256:
            raise InputError("RESUME_MANIFEST_MISMATCH")
    else:
        run_id = secrets.token_hex(16)
        if outdir.exists() and any(outdir.iterdir()):
            raise InputError("OUTPUT_ALREADY_CONTAINS_FILES: choose a new directory")
        outdir.mkdir(parents=True, exist_ok=True)
        save_json_new(outdir / "run_manifest.json", {
            "version": VERSION, "status": "RESEARCH_ONLY", "created_utc": utc(),
            "core_sha256": CORE_SHA256, "config": cfg, "run_id": run_id,
            "init_weights": str(args.init_weights) if args.init_weights else None,
            "init_metrics": str(args.init_metrics) if args.init_metrics else None,
            "safety": {"max_temp_c": args.max_temp, "max_gpu_used_mib": args.max_gpu_used_mib,
                       "max_seconds_per_session": args.max_seconds, "monitor_every_steps": args.monitor_every}
        })

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(args.seed)
        torch.cuda.reset_peak_memory_stats()
    model = UnoF().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0)
    generator = torch.Generator(device="cpu").manual_seed(args.seed + 101)
    step_done = 0
    initial = None
    if is_resume:
        ckpt = load_checkpoint(Path(args.resume), device=device, cfg=cfg, run_id=run_id)
        model.load_state_dict(ckpt["model"], strict=True)
        optimizer.load_state_dict(ckpt["optimizer"])
        generator.set_state(ckpt["train_generator_state"])
        torch.set_rng_state(ckpt["torch_cpu_rng_state"].cpu())
        if device.type == "cuda":
            if ckpt["torch_cuda_rng_state"] is None:
                raise InputError("CUDA_RESUME_RNG_STATE_MISSING")
            torch.cuda.set_rng_state(ckpt["torch_cuda_rng_state"].cpu(), device)
        step_done = ckpt["step"]
        initial = ckpt["initial"]
    elif args.init_weights:
        model.load_state_dict(valid_init_weights(Path(args.init_weights), Path(args.init_metrics), device), strict=True)
        initial = evaluate(model, device, seed=args.seed + 2000, n=256, task=args.task)
    else:
        initial = evaluate(model, device, seed=args.seed + 2000, n=256, task=args.task)

    if step_done >= args.steps:
        raise InputError(f"TARGET_STEPS_NOT_AHEAD: already step {step_done}, requested {args.steps}")
    if model.max_violation() > 1e-5:
        raise InputError("INITIAL_ROW_L1_CONSTRAINT_VIOLATION")

    amp_check = None
    if args.precision == "bf16":
        amp_check = bf16_preflight(model, device, args.task, args.seed)
    session_start = time.monotonic()
    append_event(outdir, {"event": "session_start", "starting_step": step_done, "target_steps": args.steps,
                          "preflight": sample, "amp_check": amp_check})
    print(f"START device={device} precision={args.precision} start_step={step_done} target_step={args.steps}", flush=True)

    try:
        for step in range(step_done + 1, args.steps + 1):
            if step == step_done + 1 or step % args.monitor_every == 0:
                sample = guard.poll()  # stops at step boundary
            model.train()
            x, y = make_batch(args.batch, generator, device, task=args.task)
            optimizer.zero_grad(set_to_none=True)
            with precision_context(device, args.precision):
                logits, _ = model.sequence(x, mode="full")
                loss = F.binary_cross_entropy_with_logits(logits.float(), y)
            if not torch.isfinite(loss).item():
                raise SafetyStop("NONFINITE_LOSS")
            loss.backward()
            grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            if not torch.isfinite(grad_norm).item():
                raise SafetyStop("NONFINITE_GRADIENT")
            optimizer.step()
            model.enforce_constraints()
            step_done = step
            if step == 1 or step % args.log_every == 0 or step == args.steps:
                record = {"event": "train", "step": step, "bce": round(float(loss.item()), 6),
                          "grad_norm": round(float(grad_norm.item()), 6), "hardware": sample}
                append_event(outdir, record)
                print(json.dumps({"step": step, "bce": record["bce"], "temp": sample.get("gpu_temp_c")}), flush=True)
            if step % args.checkpoint_every == 0:
                save_checkpoint(outdir, model, optimizer, generator,
                                step=step_done, cfg=cfg, device=device, initial=initial, run_id=run_id)
                append_event(outdir, {"event": "checkpoint", "step": step_done})
        # One more monitor sample after training, before validation or benchmarks.
        sample = guard.poll()
    except (SafetyStop, KeyboardInterrupt, RuntimeError) as exc:
        # Never label this run successful. Save a resumable snapshot if the
        # last update was completed and a checkpoint for this step doesn't exist.
        reason = "CTRL_C" if isinstance(exc, KeyboardInterrupt) else str(exc)
        try:
            if step_done >= 0 and not (outdir / f"checkpoint_step_{step_done:06d}.pt").exists():
                save_checkpoint(outdir, model, optimizer, generator,
                                step=step_done, cfg=cfg, device=device, initial=initial, run_id=run_id)
        except Exception as save_error:
            reason += f"; EMERGENCY_CHECKPOINT_FAILED={save_error}"
        append_event(outdir, {"event": "stopped", "step": step_done, "reason": reason})
        print(f"STOPPED step={step_done} reason={reason}", file=sys.stderr, flush=True)
        return 2

    # Persist a resumable state BEFORE validation/benchmarks.
    if not (outdir / f"checkpoint_step_{step_done:06d}.pt").exists():
        save_checkpoint(outdir, model, optimizer, generator, step=step_done,
                        cfg=cfg, device=device, initial=initial, run_id=run_id)
    try:
        sample = guard.poll()
        with precision_context(device, args.precision):
            full = evaluate(model, device, seed=args.seed + 2000, n=1024, mode="full", task=args.task)
            sparse = evaluate(model, device, seed=args.seed + 2000, n=1024, mode="prefix1", task=args.task)
            sample = guard.poll()
            bench_full = measure(model, device, "full", repeats=10)
            bench_sparse = measure(model, device, "prefix1", repeats=10)
        sample = guard.poll()
    except (SafetyStop, KeyboardInterrupt, RuntimeError) as exc:
        reason = "CTRL_C" if isinstance(exc, KeyboardInterrupt) else str(exc)
        append_event(outdir, {"event": "validation_stopped", "step": step_done, "reason": reason})
        print(f"STOPPED_AFTER_TRAINING step={step_done} reason={reason}", file=sys.stderr, flush=True)
        return 2
    stats = {
        "status": "RESEARCH_ONLY", "completed": True,
        "device": str(device), "precision": args.precision, "torch_version": torch.__version__,
        "step": step_done, "config": cfg, "initial": initial,
        "final_full": full, "final_fixed_prefix1": sparse,
        "bench_full": bench_full, "bench_fixed_prefix1": bench_sparse,
        "amp_preflight": amp_check, "last_gpu_telemetry": sample,
        "highest_observed_gpu_temp_c": guard.highest_temp,
        "highest_observed_gpu_memory_mib": guard.highest_used,
        "peak_pytorch_allocated_mib": round(torch.cuda.max_memory_allocated(device) / 1048576, 2) if device.type == "cuda" else None,
        "session_seconds": round(time.monotonic() - session_start, 3),
        "max_row_l1_violation": model.max_violation(),
        "limitations": ["synthetic 3-channel memory task", "not full UNO / Astra Θ",
                        "not learned S6 routing", "no Kotlin parity or Android runtime",
                        "temperature measured only at guard polls", "FP32-vs-BF16 gate is not training equivalence"]
    }
    path = save_final_weights(outdir, model, step_done, stats)
    append_event(outdir, {"event": "completed", "step": step_done, "weights": path.name,
                          "accuracy_full": full["accuracy"], "accuracy_sparse": sparse["accuracy"]})
    print("FINAL " + json.dumps({"step": step_done, "full_accuracy": full["accuracy"],
                                  "sparse_accuracy": sparse["accuracy"], "weights_sha256": stats["weights_sha256"]}), flush=True)
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    p.add_argument("--precision", choices=["fp32", "bf16"], default="fp32")
    p.add_argument("--output", required=True)
    p.add_argument("--steps", type=int, default=100, help="TARGET total global steps, including on resume")
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--lr", type=float, default=0.0005)
    p.add_argument("--task", choices=["delayed", "recent"], default="delayed")
    p.add_argument("--seed", type=int, default=11)
    p.add_argument("--checkpoint-every", type=int, default=25)
    p.add_argument("--monitor-every", type=int, default=5)
    p.add_argument("--log-every", type=int, default=10)
    p.add_argument("--max-temp", type=float, default=80.0)
    p.add_argument("--max-gpu-used-mib", type=int, default=7000)
    p.add_argument("--max-seconds", type=float, default=1800)
    p.add_argument("--resume", default=None, help="trusted checkpoint_step_N.pt from output directory")
    p.add_argument("--init-weights", default=None, help="existing prior pilot weights; fresh optimizer")
    p.add_argument("--init-metrics", default=None, help="matching metrics.json with SHA256")
    args = p.parse_args()
    if args.log_every <= 0:
        p.error("--log-every must be positive")
    try:
        return train(args)
    except (SafetyStop, InputError) as exc:
        print(f"REFUSED: {exc}", file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    sys.exit(main())
