"""UNO-F MEMORY-003. Research-only variable-delay challenge.

Uses byte-identical S4/S5 UnoF from GPU_SAFE_002. No changes to UNO GitHub,
previous weights, or architecture. New optimizer is used for a new task.
"""
from __future__ import annotations

import argparse
from contextlib import nullcontext
import hashlib
import json
import math
from pathlib import Path
import secrets
import sys
import time

import torch
from torch.nn import functional as F

from uno_f_pilot import UnoF
from uno_gpu_safe import (Guard, SafetyStop, InputError, digest, utc, save_json_new,
                          append_event, save_checkpoint, load_checkpoint)

CORE_SHA256 = "d290ff97eb9c58fd609d97a3c74c2a06c2b5fc0a561a3c9489776e9f8913046a"
SAFE_SHA256 = "2f4e9d95ad5c9bf0ff699fc5dbacd1b55d506efc40b74063e2cd60f277f6f952"
STUDY = "UNO_F_MEMORY_003_RESEARCH_ONLY"


def long_batch(batch: int, length: int, rng: torch.Generator, device: torch.device, *, erase_first=False):
    """Recall sign of FIRST event's f[0] after unrelated f[1] distractors.

    y is based solely on a. Later events are independent of a. The final f[2]=1
    is the retrieval cue. At length=3, matches previous delayed task's layout.
    """
    if batch < 1 or length < 3:
        raise ValueError("batch>=1 and length>=3 required")
    a = torch.rand(batch, generator=rng) * 2 - 1
    b = torch.rand(batch, generator=rng) * 2 - 1
    c = torch.rand(batch, generator=rng) * 2 - 1
    x = torch.zeros(batch, length, 3)
    x[:, 0, 0] = a
    x[:, 0, 1] = 0.1 * c
    x[:, 1, 1] = b
    if length > 3:
        x[:, 2:length - 1, 1] = torch.rand(batch, length - 3, generator=rng) * 2 - 1
    x[:, -1, 2] = 1.0
    y = (a > 0).float()
    if erase_first:
        x[:, 0, 0] = 0  # Negative control: no information about y remains.
    return x.to(device), y.to(device)


def eval_one(model, guard, device, length, seed, *, mode, n, batch, erase_first=False):
    rng = torch.Generator(device="cpu").manual_seed(seed)
    model.eval()
    correct = 0
    loss_sum = 0.0
    count = 0
    trace = None
    with torch.inference_mode():
        while count < n:
            guard.poll()
            x, y = long_batch(min(batch, n - count), length, rng, device, erase_first=erase_first)
            logits, trace = model.sequence(x, mode=mode)
            loss_sum += F.binary_cross_entropy_with_logits(logits, y, reduction="sum").item()
            correct += ((logits >= 0) == (y >= .5)).sum().item()
            count += y.numel()
    return {"accuracy": correct / count, "bce": loss_sum / count, "n": count,
            "calls": trace, "negative_control": erase_first}


def evaluation_grid(model, guard, device, *, lengths, n, batch, seed):
    result = {}
    for length in lengths:
        row = {}
        for mode in ("full", "prefix1"):
            row[mode] = eval_one(model, guard, device, length, seed + length * 10,
                                 mode=mode, n=n, batch=batch)
        row["first_signal_erased"] = eval_one(model, guard, device, length,
                                                seed + length * 10, mode="full", n=n,
                                                batch=batch, erase_first=True)
        result[str(length)] = row
        print("EVAL " + json.dumps({"length": length,
            "full": round(row["full"]["accuracy"], 4),
            "prefix1": round(row["prefix1"]["accuracy"], 4),
            "erased": round(row["first_signal_erased"]["accuracy"], 4)}), flush=True)
    return result


def verify_source():
    here = Path(__file__).parent
    for name, expected in (("uno_f_pilot.py", CORE_SHA256),
                           ("uno_gpu_safe.py", SAFE_SHA256)):
        got = digest(here / name)
        if got != expected:
            raise InputError(f"SOURCE_SHA_MISMATCH {name} {got}")


def init_verified_weights(model, path: Path):
    manifest = path.with_suffix(".sha256.json")
    if not path.is_file() or not manifest.is_file():
        raise InputError(f"INIT_WEIGHTS_OR_MANIFEST_MISSING: {path}")
    meta = json.loads(manifest.read_text(encoding="utf-8"))
    if meta.get("file") != path.name or meta.get("sha256") != digest(path):
        raise InputError("INIT_WEIGHTS_SHA256_MISMATCH")
    weights = torch.load(path, map_location="cpu", weights_only=True)
    model.load_state_dict(weights, strict=True)
    if model.max_violation() > 1e-5:
        raise InputError("INIT_ROW_L1_VIOLATION")
    return meta["sha256"]


def run(args):
    verify_source()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise InputError("CUDA_NOT_AVAILABLE")
    if args.steps < 1 or args.batch < 1 or args.eval_samples < 16 or args.checkpoint_every < 1:
        raise InputError("INVALID_STEPS_BATCH_OR_EVAL_SAMPLES")
    if args.max_temp < 45 or args.max_temp > 85 or args.max_seconds <= 0:
        raise InputError("INVALID_SAFETY_LIMITS")
    if not args.lengths or any(v < 3 or v > 64 for v in args.lengths) or len(set(args.lengths)) != len(args.lengths):
        raise InputError("INVALID_EVAL_LENGTHS")
    if args.batch > 128 or args.eval_batch > 128:
        raise InputError("BATCH_TOO_LARGE_FOR_CONSERVATIVE_TEST")
    if args.lr <= 0 or args.lr > .01 or not math.isfinite(args.lr):
        raise InputError("INVALID_LEARNING_RATE")
    device = torch.device(args.device)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    torch.manual_seed(args.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(args.seed)
        torch.cuda.reset_peak_memory_stats()
    guard = Guard(device, max_temp=args.max_temp,
                  max_gpu_used_mib=args.max_gpu_used_mib,
                  max_seconds=args.max_seconds)
    out = Path(args.output)
    cfg = {"study": STUDY, "seed": args.seed, "batch": args.batch, "lr": args.lr,
           "train_lengths": [6, 12], "eval_lengths": args.lengths,
           "eval_samples": args.eval_samples, "eval_batch": args.eval_batch,
           "source_core_sha": CORE_SHA256, "source_safe_sha": SAFE_SHA256,
           "checkpoint_format": 2, "target_steps": args.steps}
    model = UnoF().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    rng = torch.Generator(device="cpu").manual_seed(args.seed + 101)
    step_done = 0
    initial = None

    if args.resume:
        manifest_path = out / "run_manifest.json"
        if not manifest_path.is_file():
            raise InputError("RESUME_RUN_MANIFEST_MISSING")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("config") != cfg:
            raise InputError("RESUME_CONFIG_MISMATCH")
        run_id = manifest["run_id"]
        checkpoints = sorted(out.glob("checkpoint_step_*.pt"))
        if not checkpoints:
            raise InputError("RESUME_NO_CHECKPOINTS")
        chk = load_checkpoint(checkpoints[-1], device=device, cfg=cfg, run_id=run_id)
        model.load_state_dict(chk["model"], strict=True)
        optimizer.load_state_dict(chk["optimizer"])
        rng.set_state(chk["train_generator_state"])
        torch.set_rng_state(chk["torch_cpu_rng_state"].cpu())
        if device.type == "cuda":
            if chk["torch_cuda_rng_state"] is None:
                raise InputError("RESUME_NO_GPU_RNG")
            torch.cuda.set_rng_state(chk["torch_cuda_rng_state"].cpu(), device)
        initial = chk["initial"]
        step_done = chk["step"]
    else:
        if out.exists() and any(out.iterdir()):
            raise InputError(f"OUTPUT_DIRECTORY_NOT_EMPTY: {out}")
        init_sha = init_verified_weights(model, Path(args.init_weights))
        run_id = secrets.token_hex(12)
        out.mkdir(parents=True, exist_ok=True)
        save_json_new(out / "run_manifest.json", {
            "study": STUDY, "created_utc": utc(), "run_id": run_id, "config": cfg,
            "initial_weights": str(args.init_weights), "initial_weights_sha256": init_sha,
            "new_optimizer": True, "production_approved": False,
            "guard": {"temperature_c": args.max_temp,
                      "gpu_used_mib": args.max_gpu_used_mib,
                      "session_time_s": args.max_seconds}})
        guard.poll()
        print("BASELINE evaluation (before new training)", flush=True)
        try:
            initial = evaluation_grid(model, guard, device, lengths=args.lengths,
                                      n=args.eval_samples, batch=args.eval_batch,
                                      seed=args.seed + 2000)
        except (SafetyStop, KeyboardInterrupt) as exc:
            append_event(out, {"event": "baseline_stopped", "reason": str(exc)})
            return 2
        save_json_new(out / "initial_metrics.json", initial)
        # Baseline is saved before training so a short run remains useful.

    if step_done >= args.steps:
        print(f"NO_ADDITIONAL_STEPS needed: {step_done}/{args.steps}")
        return 0
    if model.max_violation() > 1e-5:
        raise InputError("ROW_L1_VIOLATION")
    append_event(out, {"event": "start", "step": step_done, "target": args.steps})
    print(f"START {args.device} step={step_done} target={args.steps} lengths=6/12", flush=True)
    last_hw = {}
    training_started = time.monotonic()
    try:
        for step in range(step_done + 1, args.steps + 1):
            if step == step_done + 1 or step % 5 == 0:
                last_hw = guard.poll()
            length = 6 if step % 2 else 12
            x, y = long_batch(args.batch, length, rng, device)
            model.train()
            optimizer.zero_grad(set_to_none=True)
            logits, trace = model.sequence(x, mode="full")
            loss = F.binary_cross_entropy_with_logits(logits, y)
            if not bool(torch.isfinite(loss).item()):
                raise SafetyStop("NONFINITE_LOSS")
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            if not bool(torch.isfinite(norm).item()):
                raise SafetyStop("NONFINITE_GRADIENT")
            optimizer.step()
            model.enforce_constraints()
            step_done = step
            if step == 1 or step % 10 == 0 or step == args.steps:
                record = {"event": "step", "step": step, "length": length,
                          "bce": round(loss.item(), 6), "temperature_c": last_hw.get("gpu_temp_c")}
                append_event(out, record)
                print("TRAIN " + json.dumps(record, ensure_ascii=False), flush=True)
            if step % args.checkpoint_every == 0:
                save_checkpoint(out, model, optimizer, rng, step=step_done,
                                cfg=cfg, device=device, initial=initial, run_id=run_id)
        guard.poll()
    except (SafetyStop, KeyboardInterrupt, RuntimeError) as exc:
        reason = "CTRL_C" if isinstance(exc, KeyboardInterrupt) else str(exc)
        if not (out / f"checkpoint_step_{step_done:06d}.pt").exists():
            try:
                save_checkpoint(out, model, optimizer, rng, step=step_done,
                                cfg=cfg, device=device, initial=initial, run_id=run_id)
            except Exception as save_error:
                reason += "; CHECKPOINT_FAILED:" + str(save_error)
        append_event(out, {"event": "stopped", "step": step_done, "reason": reason})
        print(f"STOPPED at step {step_done}: {reason}", file=sys.stderr, flush=True)
        return 2
    if not (out / f"checkpoint_step_{step_done:06d}.pt").exists():
        save_checkpoint(out, model, optimizer, rng, step=step_done,
                        cfg=cfg, device=device, initial=initial, run_id=run_id)

    print("FINAL evaluation (unseen generator seed)", flush=True)
    try:
        final = evaluation_grid(model, guard, device, lengths=args.lengths,
                                n=args.eval_samples, batch=args.eval_batch,
                                seed=args.seed + 2000)
        guard.poll()
    except (SafetyStop, KeyboardInterrupt) as exc:
        append_event(out, {"event": "validation_stopped", "step": step_done, "reason": str(exc)})
        print(f"Validation stopped: {exc}. Checkpoint remains saved.", file=sys.stderr)
        return 2
    weight_path = out / f"weights_step_{step_done:06d}_research_only.pt"
    if weight_path.exists():
        raise InputError(f"WILL_NOT_OVERWRITE {weight_path}")
    torch.save({k: v.detach().cpu() for k, v in model.state_dict().items()}, weight_path)
    weight_hash = digest(weight_path)
    save_json_new(weight_path.with_suffix(".sha256.json"),
                  {"file": weight_path.name, "sha256": weight_hash})
    report = {"status": "RESEARCH_ONLY", "device": args.device,
              "completed": True, "steps": step_done, "precision": "fp32",
              "weights_file": weight_path.name, "weights_sha256": weight_hash,
              "initial": initial, "final": final,
              "runtime_s_training_and_final_validation": round(time.monotonic() - training_started, 3),
              "highest_observed_gpu_temp_c": guard.highest_temp,
              "highest_observed_gpu_used_mib": guard.highest_used,
              "peak_pytorch_cuda_allocated_mib": round(torch.cuda.max_memory_allocated(device) / 1048576, 2) if args.device == "cuda" else None,
              "max_row_l1_violation": model.max_violation(),
              "limitations": ["synthetic sign recall, not language", "only 399361 parameter S4/S5 pilot", 
                              "fixed masks, not learned S6", "new Adam optimizer, not continuation of old Adam state",
                              "no Android kernel parity", "monitored periodically not hardware-safe guarantee"]}
    save_json_new(out / f"metrics_step_{step_done:06d}.json", report)
    append_event(out, {"event": "completed", "step": step_done, "weights_sha256": weight_hash})
    print("FINAL " + json.dumps({"step": step_done, "accuracy_length_12_full": final.get("12", {}).get("full", {}).get("accuracy"),
                                  "accuracy_length_24_full": final.get("24", {}).get("full", {}).get("accuracy"),
                                  "weights_sha256": weight_hash}), flush=True)
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device", choices=["cpu", "cuda"], default="cuda")
    p.add_argument("--output", required=True)
    p.add_argument("--init-weights", default=r"D:\OwnNeuralNet\uno_gpu_safe_002_fp32\weights_step_000050_research_only.pt")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--steps", type=int, default=60)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--lr", type=float, default=0.0005)
    p.add_argument("--seed", type=int, default=31)
    p.add_argument("--lengths", type=int, nargs="+", default=[3, 6, 12, 24])
    p.add_argument("--eval-samples", type=int, default=256)
    p.add_argument("--eval-batch", type=int, default=64)
    p.add_argument("--checkpoint-every", type=int, default=10)
    p.add_argument("--max-temp", type=float, default=80)
    p.add_argument("--max-gpu-used-mib", type=int, default=7000)
    p.add_argument("--max-seconds", type=float, default=480)
    args = p.parse_args()
    try:
        code = run(args)
    except (InputError, OSError, ValueError, RuntimeError) as err:
        print("ERROR: " + str(err), file=sys.stderr, flush=True)
        code = 1
    return code


if __name__ == "__main__":
    sys.exit(main())
