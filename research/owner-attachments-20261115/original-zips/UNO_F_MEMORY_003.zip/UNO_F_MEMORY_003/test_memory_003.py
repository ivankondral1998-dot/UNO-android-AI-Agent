"""Research-only deterministic checks. Run: python -m unittest test_memory_003.py"""

import json
import tempfile
import unittest
from pathlib import Path

import torch
from uno_f_pilot import UnoF
from uno_long_memory import (long_batch, init_verified_weights, verify_source,
                             eval_one, InputError, digest)
from uno_gpu_safe import Guard


class TestMemory003(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(min(torch.get_num_threads(), 4))
        self.dev = torch.device('cpu')

    def gen(self, seed=5):
        return torch.Generator(device='cpu').manual_seed(seed)

    def test_research_core_hashes(self):
        verify_source()

    def test_labels_are_first_sign(self):
        for length in (3, 6, 12, 24):
            x, y = long_batch(24, length, self.gen(), self.dev)
            self.assertTrue(torch.equal(y, (x[:, 0, 0] > 0).float()))
            self.assertTrue(torch.all(x[:, 1:-1, 2] == 0).item())
            self.assertTrue(torch.all(x[:, -1, 2] == 1).item())

    def test_erase_leaves_same_label_without_signal(self):
        x, y = long_batch(32, 12, self.gen(9), self.dev)
        erased, y2 = long_batch(32, 12, self.gen(9), self.dev, erase_first=True)
        self.assertTrue(torch.equal(y, y2))
        self.assertTrue(torch.equal(x[:, 1:], erased[:, 1:]))
        self.assertTrue(torch.all(erased[:, 0, 0] == 0).item())

    def test_reproducible_generator(self):
        a, ya = long_batch(8, 24, self.gen(9), self.dev)
        b, yb = long_batch(8, 24, self.gen(9), self.dev)
        self.assertTrue(torch.equal(a, b))
        self.assertTrue(torch.equal(ya, yb))

    def test_first_event_is_only_label_source(self):
        x, y = long_batch(80, 12, self.gen(23), self.dev)
        # A different first event flips the answer; all distractors stay unchanged.
        other = x.clone()
        other[:, 0, 0].neg_()
        self.assertTrue(torch.equal((other[:, 0, 0] > 0).float(), 1 - y))
        self.assertTrue(torch.equal(other[:, 1:], x[:, 1:]))

    def test_invalid_length_refused(self):
        with self.assertRaises(ValueError):
            long_batch(4, 2, self.gen(), self.dev)

    def test_model_forward_both_masks(self):
        model = UnoF()
        x, y = long_batch(4, 6, self.gen(), self.dev)
        for mode in ('full', 'prefix1'):
            logits, trace = model.sequence(x, mode=mode)
            self.assertEqual(tuple(logits.shape), (4,))
            self.assertTrue(bool(torch.isfinite(logits).all().item()))
            self.assertGreater(trace['A'], 0)
        self.assertLess(model.max_violation(), 1e-5)

    def test_hash_mismatch_refused(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'example.pt'
            torch.save(UnoF().state_dict(), p)
            p.with_suffix('.sha256.json').write_text(json.dumps({'file': p.name, 'sha256': '0'*64}), encoding='utf-8')
            with self.assertRaises(InputError):
                init_verified_weights(UnoF(), p)

    def test_verified_weights_load(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'example.pt'
            src = UnoF()
            torch.save(src.state_dict(), p)
            p.with_suffix('.sha256.json').write_text(json.dumps({'file': p.name, 'sha256': digest(p)}), encoding='utf-8')
            restored = UnoF()
            self.assertEqual(init_verified_weights(restored, p), digest(p))
            self.assertTrue(all(torch.equal(a,b) for a,b in zip(src.state_dict().values(), restored.state_dict().values())))


if __name__ == '__main__':
    unittest.main()
