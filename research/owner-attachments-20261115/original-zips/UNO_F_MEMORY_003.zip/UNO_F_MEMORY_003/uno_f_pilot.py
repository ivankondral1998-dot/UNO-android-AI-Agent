"""UNO / UNOVYRA research-only S4/S5 pilot. Based on ASTRA R5.3.

This is NOT the complete B2 parameter inventory, S6 learner, Android runtime, or production weights.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import random
import time
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as fn

SOURCE_SHA = "1df9ee7cc592f606939c8f004e1b11edd916b56c"
GEOMETRY = {"d":128,"m":128,"b":64,"chi":4,"J":2,"K":2,"alpha":0.5,"rho":0.5,"input_width":3}


def project_l1_(weight: torch.Tensor, radius: float) -> None:
    """Exact Euclidean projection of each matrix row onto an L1-ball, not radial scaling."""
    with torch.no_grad():
        w = weight.reshape(-1,weight.shape[-1])
        norm = w.abs().sum(dim=1)
        outside = norm > radius
        if not outside.any(): return
        x = w[outside]
        u = x.abs().sort(dim=1, descending=True).values
        cssv = u.cumsum(dim=1)
        i = torch.arange(1,u.shape[1]+1,device=u.device,dtype=u.dtype).unsqueeze(0)
        active = (u - (cssv-radius)/i) > 0
        rho = active.sum(dim=1).clamp(min=1)
        theta = ((cssv.gather(1,(rho-1).unsqueeze(1)).squeeze(1)-radius)/rho).unsqueeze(1)
        w[outside] = x.sign() * (x.abs()-theta).clamp(min=0)


class Branch(nn.Module):
    def __init__(self,d:int,b:int,chi:int):
        super().__init__()
        self.A=nn.Linear(d,chi*b,bias=True)
        self.C=nn.Linear(d,chi*b,bias=False)
        self.B=nn.Linear(chi*b,b,bias=True)


class UnoF(nn.Module):
    """Same smooth S4/S5 equations and block geometry as Kotlin UnoFReference.

    Event feature projection is a 3-channel synthetic pilot; full text/audio/image
    input encoders and all other ASTRA heads are NOT implemented.
    """
    def __init__(self,d=128,m=128,b=64,chi=4,J=2):
        super().__init__()
        assert d % b == 0 and b == 64 and m == 128 and chi == 4 and J == 2
        self.d,self.m,self.b,self.chi,self.J = d,m,b,chi,J
        self.nb=d//b
        self.E=nn.Linear(3,d,bias=False)
        self.Us=nn.Linear(d,d,bias=False)
        self.Ug=nn.Linear(d,d,bias=False)
        self.Wmeta=nn.Linear(32,d,bias=False)
        self.e=nn.Parameter(torch.zeros(d))
        self.bz=nn.Parameter(torch.zeros(d))
        self.Wq=nn.Linear(d,m,bias=False)
        self.Wr=nn.Linear(m,d,bias=False)
        self.branches=nn.ModuleList([nn.ModuleList([Branch(d,b,chi) for _ in range(self.nb)]) for _ in range(J)])
        # Existing ASTRA head: w_conf (confidence / terminal supervised correctness)
        self.w_conf=nn.Linear(d,1,bias=True)
        self.init_projected()

    def constrained(self):
        yield self.E.weight,8.0,False
        yield self.Us.weight,1.0,False
        yield self.Ug.weight,1.0,False
        yield self.Wmeta.weight,8.0,False
        yield self.Wq.weight,2.0,False
        yield self.Wr.weight,2.0,False
        yield self.e,1.0,True
        yield self.bz,1.0,True
        yield self.w_conf.weight,8.0,False
        yield self.w_conf.bias,8.0,True
        for l in range(self.J):
            for j in range(self.nb):
                p=self.branches[l][j]
                yield p.A.weight,1.0,False
                yield p.C.weight,2.0,False
                yield p.B.weight,0.9,False
                yield p.A.bias,8.0,True
                yield p.B.bias,8.0,True

    def init_projected(self):
        for m in self.modules():
            if isinstance(m,nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None: nn.init.zeros_(m.bias)
        with torch.no_grad():
            self.e.uniform_(-0.01,0.01)
            self.bz.zero_()
        self.enforce_constraints()

    def enforce_constraints(self):
        for w,cap,is_bias in self.constrained():
            if is_bias:
                with torch.no_grad(): w.clamp_(-cap,cap)
            else: project_l1_(w,cap)

    def max_violation(self):
        result=0.0
        for w,cap,is_bias in self.constrained():
            if is_bias: mx=w.detach().abs().max().item()
            else: mx=w.detach().abs().sum(-1).max().item()
            result=max(result,mx-cap)
        return max(0,result)

    def forward_event(self, f, s, mask, *, goal=None, meta=None, keys=None, values=None, steps=2, alpha=.5,rho=.5):
        if f.ndim!=2 or f.shape[1]!=3 or s.shape!=(f.shape[0],self.d):raise ValueError("S4 bad feature/state shape")
        if len(mask)!=self.nb or not any(mask) or not 1<=steps<=8: raise ValueError("S5 invalid mask/K")
        if goal is None:goal=torch.zeros_like(s)
        if meta is None:meta=f.new_zeros(f.shape[0],32)
        z0=torch.tanh(self.E(f)+self.Us(s)+self.Ug(goal)+self.Wmeta(meta)+self.e+self.bz)
        q=torch.tanh(self.Wq(z0))
        if keys is None or keys.shape[1]==0:
            r=torch.zeros(f.shape[0],self.m,device=f.device,dtype=f.dtype)
        else:
            if values is None or keys.shape[-1]!=self.m or values.shape!=keys.shape:raise ValueError("S4 memory shape")
            p=torch.softmax((keys*q[:,None,:]).sum(-1)/math.sqrt(self.m),dim=1)
            r=(p[:,:,None]*values).sum(1)
        z=torch.tanh(z0+self.Wr(r))  # even when empty: tanh(z0), NOT z0
        h=rho*s+(1-rho)*z
        # C_j z computed exactly once per admitted block per event (Kotlin oracle).
        cached={}
        trace={"A":0,"B":0,"C":0,"skipped_blocks":self.nb-sum(mask),"K":steps}
        for j in range(self.nb):
            if mask[j]:
                for l in range(self.J):
                    cached[l,j]=self.branches[l][j].C(z)
                    trace["C"]+=1
        for _ in range(steps):
            out=[]  # all active branches use the SAME old h (synchronous recurrence)
            for j in range(self.nb):
                if not mask[j]:out.append(h[:,j*self.b:(j+1)*self.b]);continue
                avg=0
                for l in range(self.J):
                    p=self.branches[l][j]
                    u=torch.tanh(p.A(h)+cached[l,j]);trace["A"]+=1
                    avg=avg+torch.tanh(p.B(u))/self.J;trace["B"]+=1
                old=h[:,j*self.b:(j+1)*self.b]
                out.append((1-alpha)*old+alpha*avg)
            h=torch.cat(out,dim=1)
        return h,trace

    def sequence(self, x, *, mode="full",steps=2,turn_serial=0):
        if x.ndim!=3 or x.shape[2]!=3:raise ValueError("x [batch,time,3] required")
        s=x.new_zeros(x.shape[0],self.d)
        totals={"A":0,"B":0,"C":0,"skipped_blocks":0}
        for t in range(x.shape[1]):
            if mode=="full":mask=[True]*self.nb
            elif mode=="prefix1":
                # ASTRA S6 cyclic prefix geometry. Selected q=1 is fixed comparator.
                mask=[False]*self.nb
                mask[(turn_serial+t)%self.nb]=True
            else:raise ValueError("mode must be full or prefix1")
            s, trace=self.forward_event(x[:,t,:],s,mask,steps=steps)
            for k in totals:totals[k]+=trace[k]
        return self.w_conf(s).squeeze(-1),totals


def make_batch(batch, rng, device, *, task="delayed"):
    # Labels are generated independently from network weights. Train and test RNG differ.
    a=torch.rand(batch,generator=rng)*2-1
    b=torch.rand(batch,generator=rng)*2-1
    c=torch.rand(batch,generator=rng)*2-1
    x=torch.zeros(batch,3,3)
    if task=="delayed":
        x[:,0,0]=a
        x[:,1,1]=b
        x[:,2,2]=1.0
        y=(a>0).float()
    elif task=="recent":
        x[:,0,0]=b
        x[:,1,0]=a
        x[:,2,2]=1.0
        y=(a>0).float()
    else:raise ValueError("unknown task")
    # Small observation noise on unrelated channels at fixed causal times.
    x[:,0,1]=.1*c
    x[:,1,1]=b
    return x.to(device), y.to(device)


def evaluate(model, device, *, seed, n, mode="full",task="delayed",batch=128):
    model.eval()
    rng=torch.Generator(device="cpu").manual_seed(seed)
    numcorrect=0;loss=0.;num=0;ops=None
    with torch.no_grad():
        while num<n:
            x,y=make_batch(min(batch,n-num),rng,device,task=task)
            logits,ops=model.sequence(x,mode=mode)
            loss+=fn.binary_cross_entropy_with_logits(logits,y,reduction="sum").item()
            numcorrect+=((logits>=0)==(y>=0.5)).sum().item();num+=len(y)
    return {"accuracy":numcorrect/num,"bce":loss/num,"samples":num,"calls_per_batch":ops}


def measure(model,device, mode, *,batch=64,repeats=25):
    model.eval();rng=torch.Generator().manual_seed(9001)
    x,_=make_batch(batch,rng,device)
    with torch.inference_mode():
        for _ in range(4):model.sequence(x,mode=mode)
        if device.type=="cuda":torch.cuda.synchronize()
        t0=time.perf_counter()
        for _ in range(repeats):logits,ops=model.sequence(x,mode=mode)
        if device.type=="cuda":torch.cuda.synchronize()
        elapsed=time.perf_counter()-t0
    return {"ms_per_batch":1000*elapsed/repeats,"batch":batch,"repeats":repeats,"kernel_calls":ops,
            "device":str(device)}


def train(args):
    random.seed(args.seed);torch.manual_seed(args.seed)
    torch.set_num_threads(min(torch.get_num_threads(),4))
    device=torch.device("cuda" if args.device=="auto" and torch.cuda.is_available() else ("cpu" if args.device=="auto" else args.device))
    if device.type=="cuda" and not torch.cuda.is_available():raise RuntimeError("CUDA requested but unavailable")
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    model=UnoF().to(device)
    opt=torch.optim.Adam(model.parameters(),lr=args.lr,weight_decay=0.0)
    rng=torch.Generator(device="cpu").manual_seed(args.seed+101)
    baseline=evaluate(model,device,seed=args.seed+2000,n=512,mode="full",task=args.task)
    logs=[];start=time.perf_counter()
    for step in range(1,args.steps+1):
        model.train();x,y=make_batch(args.batch,rng,device,task=args.task)
        opt.zero_grad(set_to_none=True)
        logits,_=model.sequence(x,mode="full")
        loss=fn.binary_cross_entropy_with_logits(logits,y)
        if not torch.isfinite(loss):raise RuntimeError("nonfinite loss")
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0,error_if_nonfinite=True)
        opt.step();model.enforce_constraints()
        if step==1 or step%args.log_every==0 or step==args.steps:
            row={"step":step,"train_bce":round(loss.item(),6)}
            logs.append(row);print(json.dumps(row),flush=True)
    elapsed=time.perf_counter()-start
    after=evaluate(model,device,seed=args.seed+2000,n=1024,mode="full",task=args.task)
    sparse=evaluate(model,device,seed=args.seed+2000,n=1024,mode="prefix1",task=args.task)
    bench_full=measure(model,device,"full",repeats=args.bench_repeats)
    bench_sparse=measure(model,device,"prefix1",repeats=args.bench_repeats)
    weights=out/"weights_research_only.pt"
    # weights-only state dict, not an executable pickle object.
    torch.save(model.cpu().state_dict(),weights)
    sha=hashlib.sha256(weights.read_bytes()).hexdigest()
    cfg={"seed":args.seed,"steps":args.steps,"batch":args.batch,"lr":args.lr,"task":args.task,"geometry":GEOMETRY,
         "source_branch":"research/uno-train-001-20261113","source_reference":"ASTRA_01 S4/S5","AGENTS_main":SOURCE_SHA}
    # Only S5 matrix MACs: C once per event, A/B once per inner step.
    one_active = model.J * (model.chi*model.b*model.d + GEOMETRY["K"] *
                            (model.chi*model.b*model.d + model.b*model.chi*model.b))
    n_events=3
    s5_mac_full = n_events * model.nb * one_active
    s5_mac_prefix = n_events * one_active
    peak_vram=(round(torch.cuda.max_memory_allocated()/1048576,3) if device.type=="cuda" else None)
    result={"status":"RESEARCH_ONLY","runtime_device":str(device),"torch":torch.__version__,"config":cfg,
            "source_code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "dataset_provenance":"Synthetic generated in make_batch(); seed=args.seed+101 for train; seed=args.seed+2000 for holdout; no imported corpus",
            "trainable_parameters":sum(p.numel() for p in model.parameters()),
            "s5_mac_full_per_episode":s5_mac_full,"s5_mac_fixed_prefix1_per_episode":s5_mac_prefix,
            "peak_torch_cuda_memory_mib":peak_vram,
            "initial":baseline,"final_full":after,"final_fixed_prefix1":sparse,
            "bench_full":bench_full,"bench_fixed_prefix1":bench_sparse,
            "seconds_training":round(elapsed,3),"max_row_l1_violation":model.max_violation(),
            "weights_sha256":sha,"weights_file":weights.name,"history":logs,
            "limitations":["not full Astra Θ", "fixed mask/K only, no learned S6/L5 policy", "synthetic 3-channel task not language", "CPU timings are not A52 battery/energy", "no Android ABI/export"]}
    (out/"metrics.json").write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    (out/"config.json").write_text(json.dumps(cfg,indent=2,ensure_ascii=False),encoding="utf-8")
    (out/"SHA256SUMS.txt").write_text(f"{sha}  {weights.name}\n",encoding="utf-8")
    print("FINAL "+json.dumps({"device":str(device),"full_accuracy":after["accuracy"],"sparse_accuracy":sparse["accuracy"],"weights_sha256":sha},ensure_ascii=False))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--steps",type=int,default=400)
    parser.add_argument("--batch",type=int,default=64)
    parser.add_argument("--lr",type=float,default=2e-3,help="EXPERIMENTAL pilot LR, not ASTRA full training grid")
    parser.add_argument("--task",choices=["delayed","recent"],default="delayed")
    parser.add_argument("--device",choices=["auto","cuda","cpu"],default="auto")
    parser.add_argument("--output",default="pilot_result")
    parser.add_argument("--seed",type=int,default=11)
    parser.add_argument("--log-every",type=int,default=25)
    parser.add_argument("--bench-repeats",type=int,default=25)
    a=parser.parse_args()
    if a.steps<=0 or a.batch<=0 or a.bench_repeats<=0:parser.error("steps/batch/bench-repeats must be positive")
    train(a)
if __name__=="__main__":main()
