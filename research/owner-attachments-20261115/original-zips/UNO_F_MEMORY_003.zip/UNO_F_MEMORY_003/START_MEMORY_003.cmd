@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_f_memory_003_gpu"
set "SOURCE=D:\OwnNeuralNet\uno_gpu_safe_002_fp32\weights_step_000050_research_only.pt"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python not found & goto FAIL)
if not exist "%SOURCE%" (echo ERROR: previous weights not found & goto FAIL)
if exist "%OUT%\run_manifest.json" (echo REFUSED: this run exists, use RESUME_MEMORY_003.cmd instead & goto FAIL)
"%PY%" uno_long_memory.py --device cuda --output "%OUT%" --init-weights "%SOURCE%" --steps 60 --batch 32 --eval-samples 256 --max-temp 80 --max-gpu-used-mib 7000 --max-seconds 480
if errorlevel 1 goto FAIL
echo.
echo SUCCESS. Results: %OUT%
pause
exit /b 0
:FAIL
echo.
echo STOPPED OR REFUSED. Previous model files are unchanged.
pause
exit /b 1
