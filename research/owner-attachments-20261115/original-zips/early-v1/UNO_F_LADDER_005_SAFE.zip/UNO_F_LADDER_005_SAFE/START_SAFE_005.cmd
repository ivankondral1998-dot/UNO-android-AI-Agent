@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_ladder_005_gpu"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing & pause & exit /b 1)
"%PY%" uno_ladder_005_safe.py --device cuda --out "%OUT%" --steps 4000 --batch 256 --eval-samples 2048 --save-every 50 --max-temp 80 --max-gpu-used-mib 7000 --max-minutes 90
if errorlevel 1 (echo ERROR: See output and saved checkpoints & pause & exit /b 1)
echo Finished. Existing finished JSON files were not overwritten.
pause
