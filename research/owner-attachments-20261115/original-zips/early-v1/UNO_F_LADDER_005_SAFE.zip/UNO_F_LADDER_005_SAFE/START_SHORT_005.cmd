@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_ladder_005_gpu_short"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing & pause & exit /b 1)
"%PY%" uno_ladder_005_safe.py --device cuda --out "%OUT%" --rungs r1_single,r2_two --models gru,uno_f --steps 1500 --batch 256 --eval-samples 1024 --save-every 50 --max-temp 80 --max-gpu-used-mib 7000 --max-minutes 25
if errorlevel 1 (echo ERROR: See output & pause & exit /b 1)
echo Finished short diagnostic.
pause
