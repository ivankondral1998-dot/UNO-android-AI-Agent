import unittest, torch
import uno_ladder_005 as u


def relabel(x, rung):
    """Recompute label ONLY from the input events (independent of generator internals)."""
    ys = []
    for s in x:
        w = [(float(e[0]), float(e[1])) for e in s if float(e[2]) == 1.0]
        q = s[-1]
        if rung == "r5_order":
            ys.append(float(w[-1][1] > 0)); continue
        qc = float(q[1])
        last = [v for v, c in w if abs(c - qc) < 1e-6][-1]
        ys.append(float(last > 0))
    return torch.tensor(ys)


class T(unittest.TestCase):
    def test_labels_recoverable_from_input(self):
        for r in u.RUNGS:
            for L in (12, 24, 48):
                x, y = u.make_batch(64, L, r, torch.Generator().manual_seed(3))
                self.assertTrue(torch.equal(relabel(x, r), y), (r, L))

    def test_deterministic(self):
        a = u.make_batch(16, 24, "r3_three", torch.Generator().manual_seed(9))
        b = u.make_batch(16, 24, "r3_three", torch.Generator().manual_seed(9))
        self.assertTrue(torch.equal(a[0], b[0]) and torch.equal(a[1], b[1]))

    def test_erase_keeps_labels_changes_input(self):
        for r in u.RUNGS:
            x, y = u.make_batch(64, 24, r, torch.Generator().manual_seed(5))
            xe, ye = u.make_batch(64, 24, r, torch.Generator().manual_seed(5), erase=True)
            self.assertTrue(torch.equal(y, ye))
            self.assertFalse(torch.equal(x, xe))

    def test_erased_label_not_recoverable(self):
        # after erasing, relabeling from input must be ~chance (no leak)
        for r in ("r1_single", "r2_two", "r3_three", "r4_overwrite"):
            xe, y = u.make_batch(2000, 24, r, torch.Generator().manual_seed(6), erase=True)
            w = []
            for s in xe:
                qc = float(s[-1][1])
                vals = [float(e[0]) for e in s if float(e[2]) == 1.0 and abs(float(e[1]) - qc) < 1e-6]
                w.append(float(vals[-1] > 0) if vals else 0.0)
            acc = (torch.tensor(w) == y).float().mean().item()
            self.assertLess(abs(acc - 0.5), 0.06, (r, acc))

    def test_balance_and_noise_everywhere(self):
        for r in u.RUNGS:
            x, y = u.make_batch(4000, 24, r, torch.Generator().manual_seed(7))
            self.assertLess(abs(y.mean().item() - 0.5), 0.05, r)
            noise = x[:, :-1][x[:, :-1, 2] == 0]
            self.assertGreater(noise[:, 0].abs().mean().item(), 0.4)  # value channel is noisy
            self.assertGreater(noise[:, 1].abs().mean().item(), 0.4)  # slot channel is noisy

    def test_params(self):
        self.assertAlmostEqual(sum(p.numel() for p in u.GRUControl().parameters()), 399361, delta=8000)
        self.assertEqual(sum(p.numel() for p in u.UnoWrap().parameters()), 399361)

    def test_core_sha(self):
        from pathlib import Path
        self.assertEqual(u.sha(Path(u.__file__).parent / "uno_f_pilot.py"), u.CORE_SHA)

    def test_smoke_run_cpu(self):
        import tempfile, pathlib
        with tempfile.TemporaryDirectory() as d:
            u.main(["--out", d, "--device", "cpu", "--rungs", "r1_single", "--models", "gru,uno_f", "--steps", "4",
                    "--eval-every", "2", "--eval-samples", "64", "--batch", "16", "--max-minutes", "5"])
            self.assertTrue((pathlib.Path(d) / "SUMMARY.txt").exists())


if __name__ == "__main__":
    unittest.main()
