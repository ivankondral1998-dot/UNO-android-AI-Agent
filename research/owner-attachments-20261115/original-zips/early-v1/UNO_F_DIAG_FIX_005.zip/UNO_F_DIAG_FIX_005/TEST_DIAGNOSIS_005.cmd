@echo off
cd /d "%~dp0"
"D:\OwnNeuralNet\.venv\Scripts\python.exe" test_diagnosis_005.py
set CODE=%ERRORLEVEL%
echo.
if not "%CODE%"=="0" echo TEST FAILED (exit %CODE%)
if "%CODE%"=="0" echo DIAGNOSIS PASS (no GPU training performed)
pause
exit /b %CODE%
