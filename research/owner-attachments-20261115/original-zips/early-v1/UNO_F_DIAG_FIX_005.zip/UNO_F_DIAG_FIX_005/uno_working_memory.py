"""UNO F working-memory challenge 004. Research-only; existing S4/S5 operator unchanged.

Three independent tasks: indexed three-slot recall; last-write-wins overwrite;
order of two writes. Independent nuisance events, randomized time positions, negative
controls, out-of-range sequence lengths, pretrained-task retention. No learned S6.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import secrets
import sys
import time

import torch
from torch.nn import functional as F

from uno_f_pilot import UnoF
from uno_gpu_safe import (Guard, InputError, SafetyStop, append_event, digest,
                          load_checkpoint, save_checkpoint, save_json_new, utc)

CORE_SHA = 'd290ff97eb9c58fd609d97a3c74c2a06c2b5fc0a561a3c9489776e9f8913046a'
SAFE_SHA = '2f4e9d95ad5c9bf0ff699fc5dbacd1b55d506efc40b74063e2cd60f277f6f952'
EXPECTED_PARENT_SHA = '5e5ef81096fabc75be82e3f6498165ed4389a12f5468d3de720110de2533fdde'
STUDY = 'UNO_F_WORKING_MEMORY_004_RESEARCH_ONLY'
TASKS = ('indexed', 'overwrite', 'order', 'legacy')
NEW_TASKS = ('indexed', 'overwrite', 'order')
TRAIN_LENGTHS = (12, 24, 32)
EVAL_LENGTHS = (12, 24, 48, 96)


def check_sources() -> None:
    directory = Path(__file__).parent
    for name, expected in (('uno_f_pilot.py', CORE_SHA), ('uno_gpu_safe.py', SAFE_SHA)):
        actual = digest(directory / name)
        if actual != expected:
            raise InputError(f'SOURCE_SHA_MISMATCH {name}: {actual}')


def new_batch(batch: int, length: int, task: str, rng: torch.Generator,
              device: torch.device, *, erase_target: bool = False):
    """Make fully synthetic, deterministic, independently labeled sequences.

    Input x[..., 0] value; x[..., 1] slot (-1/0/+1); x[..., 2] op:
    +1 write, 0 distractor, -1 indexed query, -2 last-written-slot query.
    All writes occur in the first ~half, so later noise tests recurrent retention.
    Erase_target preserves targets but destroys their causal evidence.
    """
    if batch < 1 or length < 10 or task not in NEW_TASKS:
        raise ValueError('INVALID_NEW_TASK_OR_LENGTH')
    x = torch.empty(batch, length, 3)
    x[..., 0] = torch.rand(batch, length, generator=rng) * 2 - 1
    x[..., 1] = torch.rand(batch, length, generator=rng) * 2 - 1
    x[..., 2].zero_()
    labels = torch.empty(batch)
    slot_codes = (-1., 0., 1.)
    # Distinct random write timestamps in the first part of each sequence.
    # Leave final event solely for the query; it carries no data value.
    window = min(length - 2, max(5, (length + 1) // 2))
    for i in range(batch):
        if task == 'order':
            stamps = sorted(torch.randperm(window, generator=rng)[:2].tolist())
            earlier_positive = bool(torch.randint(0, 2, (1,), generator=rng).item())
            order = [(-1., 1.)[earlier_positive], (1., -1.)[earlier_positive]]
            # order[0] is the earlier write, order[1] is the later write.
            for t, slot in zip(stamps, order):
                x[i, t, 1] = slot
                x[i, t, 2] = 1
            labels[i] = float(order[-1] > 0)
            if erase_target:
                # Remove both identifiers. No evidence remains about write order.
                x[i, stamps, 1] = 0.
            x[i, -1] = torch.tensor([0., 0., -2.])
            continue
        stamps = sorted(torch.randperm(window, generator=rng)[:(4 if task == 'overwrite' else 3)].tolist())
        order = torch.randperm(3, generator=rng).tolist()
        query = int(torch.randint(0, 3, (1,), generator=rng).item())
        overwrite_slot = int(torch.randint(0, 3, (1,), generator=rng).item())
        writes = [int(v) for v in order]
        if task == 'overwrite':
            writes.append(overwrite_slot)
        last_value = {}
        for t, slot in zip(stamps, writes):
            value = float(torch.rand((), generator=rng).item()) * 2 - 1
            x[i, t, 0] = value
            x[i, t, 1] = slot_codes[slot]
            x[i, t, 2] = 1.
            last_value[slot] = value
        labels[i] = float(last_value[query] > 0)
        if erase_target:
            for t, slot in zip(stamps, writes):
                if slot == query:
                    x[i, t, 0] = 0.
        x[i, -1] = torch.tensor([0., slot_codes[query], -1.])
    return x.to(device), labels.to(device)


def legacy_batch(batch: int, length: int, rng: torch.Generator, device: torch.device):
    """Exact old first-signal recall distribution from MEMORY-003; retention only."""
    a = torch.rand(batch, generator=rng) * 2 - 1
    b = torch.rand(batch, generator=rng) * 2 - 1
    c = torch.rand(batch, generator=rng) * 2 - 1
    x = torch.zeros(batch, length, 3)
    x[:, 0, 0] = a
    x[:, 0, 1] = .1 * c
    x[:, 1, 1] = b
    if length > 3:
        x[:, 2:length - 1, 1] = torch.rand(batch, length - 3, generator=rng) * 2 - 1
    x[:, -1, 2] = 1.
    return x.to(device), (a > 0).float().to(device)


def eval_case(model: UnoF, guard: Guard, device: torch.device, *, task: str,
              length: int, seed: int, n: int, batch: int, mode: str = 'full',
              erased: bool = False) -> dict:
    rng = torch.Generator(device='cpu').manual_seed(seed)
    correct, total, summed_loss = 0, 0, 0.
    trace = None
    model.eval()
    with torch.inference_mode():
        while total < n:
            guard.poll()
            b = min(batch, n-total)
            if task == 'legacy':
                x, y = legacy_batch(b, length, rng, device)
            else:
                x, y = new_batch(b, length, task, rng, device, erase_target=erased)
            logits, trace = model.sequence(x, mode=mode)
            correct += int(((logits >= 0) == (y >= .5)).sum().item())
            summed_loss += float(F.binary_cross_entropy_with_logits(logits, y, reduction='sum').item())
            total += b
    return {'accuracy': correct / total, 'bce': summed_loss / total,
            'samples': total, 'mode': mode, 'evidence_erased': erased,
            'kernel_calls_last_batch': trace}


def evaluate(model: UnoF, guard: Guard, device: torch.device, *, seed: int,
             n: int, batch: int, lengths: tuple[int, ...]) -> dict:
    results = {}
    for task in (*NEW_TASKS, 'legacy'):
        lengths_for_task = lengths if task != 'legacy' else (24,)
        results[task] = {}
        for length in lengths_for_task:
            key = str(length)
            shared_seed = seed + 100000 * (*NEW_TASKS, 'legacy').index(task) + length * 10
            row = {'full': eval_case(model,guard,device,task=task,length=length,seed=shared_seed,
                                     n=n,batch=batch)}
            if task != 'legacy' and length in (12, 48):
                row['prefix1'] = eval_case(model,guard,device,task=task,length=length,seed=shared_seed,
                                           n=n,batch=batch,mode='prefix1')
            if task != 'legacy' and length == 48:
                row['evidence_erased'] = eval_case(model,guard,device,task=task,length=length,
                                                  seed=shared_seed,n=n,batch=batch,erased=True)
            results[task][key] = row
            report = {'task':task,'length':length,'full':round(row['full']['accuracy'],4)}
            if 'prefix1' in row: report['prefix1'] = round(row['prefix1']['accuracy'],4)
            if 'evidence_erased' in row: report['erased'] = round(row['evidence_erased']['accuracy'],4)
            print('EVAL ' + json.dumps(report), flush=True)
    return results


def init_verified(model: UnoF, path: Path, expected_sha: str | None = None) -> str:
    sha_path = path.with_suffix('.sha256.json')
    if not path.is_file() or not sha_path.is_file():
        raise InputError('PREVIOUS_MEMORY_003_WEIGHTS_OR_SHA_MISSING: ' + str(path))
    meta = json.loads(sha_path.read_text(encoding='utf-8'))
    if meta.get('file') != path.name or meta.get('sha256') != digest(path):
        raise InputError('PREVIOUS_MEMORY_003_WEIGHTS_SHA_MISMATCH')
    if expected_sha is not None and meta['sha256'] != expected_sha:
        raise InputError('NOT_THE_OWNER_VERIFIED_MEMORY_003_WEIGHTS: expected ' + expected_sha)
    model.load_state_dict(torch.load(path, map_location='cpu', weights_only=True), strict=True)
    if model.max_violation() > 1e-5:
        raise InputError('PREVIOUS_WEIGHT_CONSTRAINT_VIOLATION')
    return meta['sha256']


def latest_checkpoint(folder: Path) -> Path:
    paths = sorted(folder.glob('checkpoint_step_*.pt'))
    if not paths:
        raise InputError('NO_PREVIOUS_CHECKPOINT_TO_RESUME')
    return paths[-1]


def run(args) -> int:
    check_sources()
    if not (1 <= args.steps <= 1000 and 1 <= args.batch <= 64 and 32 <= args.eval_samples <= 4096
            and 1 <= args.eval_batch <= 128 and 1 <= args.checkpoint_every <= 1000):
        raise InputError('INVALID_BATCH_STEPS_OR_EVAL_SIZE')
    if not (0. < args.lr <= .005 and math.isfinite(args.lr)):
        raise InputError('INVALID_LEARNING_RATE')
    if len(args.expected_init_sha) != 64 or any(v not in '0123456789abcdef' for v in args.expected_init_sha):
        raise InputError('INVALID_EXPECTED_PARENT_SHA')
    if not (45 <= args.max_temp <= 85 and 512 <= args.max_gpu_used_mib <= 7000
            and 10 <= args.max_seconds <= 3600):
        raise InputError('INVALID_GUARD_LIMITS')
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise InputError('CUDA_UNAVAILABLE_NO_CPU_FALLBACK')
    if args.device == 'cpu' and args.max_seconds < 10:
        raise InputError('INVALID_CPU_TIME_BUDGET')
    device = torch.device(args.device)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    torch.manual_seed(args.seed)
    if device.type == 'cuda':
        torch.cuda.manual_seed_all(args.seed)
        torch.cuda.reset_peak_memory_stats()
    guard = Guard(device, max_temp=args.max_temp, max_gpu_used_mib=args.max_gpu_used_mib,
                  max_seconds=args.max_seconds)
    guard.poll()
    if device.type == 'cuda':
        total_mib = torch.cuda.get_device_properties(0).total_memory / 1048576
        # PyTorch cap gives headroom in addition to periodic nvidia-smi polling.
        available = args.max_gpu_used_mib - guard.highest_used - 256
        if available < 512: raise SafetyStop('NOT_ENOUGH_FREE_VRAM')
        torch.cuda.set_per_process_memory_fraction(min(.95, available/total_mib), 0)
    out = Path(args.output).resolve()
    cfg = {'study':STUDY,'source_script_sha256':digest(Path(__file__)),
           'core_sha256':CORE_SHA,'safe_sha256':SAFE_SHA,
           'seed':args.seed,'batch':args.batch,'lr':args.lr,'train_lengths':list(TRAIN_LENGTHS),
           'eval_lengths':list(EVAL_LENGTHS),'eval_samples':args.eval_samples,
           'eval_batch':args.eval_batch,'target_steps':args.steps,'checkpoint_every':args.checkpoint_every,
           'precision':'fp32','training_tasks':list(TASKS),
           'expected_parent_sha256':args.expected_init_sha}
    model = UnoF().to(device)
    optimizer = torch.optim.Adam(model.parameters(),lr=args.lr)
    train_rng = torch.Generator(device='cpu').manual_seed(args.seed + 101)
    done, initial = 0, None
    if args.resume:
        if not (out / 'run_manifest.json').is_file():
            raise InputError('NO_PREVIOUS_RUN_TO_RESUME')
        manifest = json.loads((out / 'run_manifest.json').read_text(encoding='utf-8'))
        if manifest.get('config') != cfg:
            raise InputError('RUN_CONFIGURATION_OR_CODE_CHANGED')
        run_id = manifest['run_id']
        checkpoint = load_checkpoint(latest_checkpoint(out),device=device,cfg=cfg,run_id=run_id)
        model.load_state_dict(checkpoint['model'],strict=True)
        optimizer.load_state_dict(checkpoint['optimizer'])
        train_rng.set_state(checkpoint['train_generator_state'])
        torch.set_rng_state(checkpoint['torch_cpu_rng_state'].cpu())
        if device.type == 'cuda':
            cuda_state = checkpoint['torch_cuda_rng_state']
            if cuda_state is None: raise InputError('NO_CUDA_RNG_IN_CHECKPOINT')
            torch.cuda.set_rng_state(cuda_state.cpu(),device)
        initial = checkpoint['initial']
        done = checkpoint['step']
        print('RESUME ' + json.dumps({'step':done,'checkpoint':checkpoint['step']}),flush=True)
    else:
        if out.exists() and any(out.iterdir()):
            raise InputError('OUTPUT_DIRECTORY_NOT_EMPTY: no overwriting')
        init_sha = init_verified(model,Path(args.init_weights),expected_sha=args.expected_init_sha)
        print('BASELINE before new training',flush=True)
        initial = evaluate(model,guard,device,seed=args.seed+2000,
                           n=args.eval_samples,batch=args.eval_batch,lengths=EVAL_LENGTHS)
        guard.poll()
        out.mkdir(parents=True,exist_ok=True)
        run_id = secrets.token_hex(16)
        save_json_new(out/'run_manifest.json',{'run_id':run_id,'created_utc':utc(),
            'config':cfg,'input_weights':str(args.init_weights),'input_sha256':init_sha,
            'safety':{'max_temp_c':args.max_temp,'max_gpu_used_mib':args.max_gpu_used_mib,
                      'max_seconds':args.max_seconds},'claim':'research only'})
        save_json_new(out/'baseline.json',initial)
        save_checkpoint(out,model,optimizer,train_rng,step=0,cfg=cfg,
                        device=device,initial=initial,run_id=run_id)
    if done < args.steps:
        print('TRAIN ' + json.dumps({'device':args.device,'start_step':done,
                                    'target_step':args.steps,'tasks':list(TASKS)}),flush=True)
        try:
            for step in range(done+1,args.steps+1):
                if step == done+1 or step % 5 == 0: telemetry = guard.poll()
                task = TASKS[(step-1) % len(TASKS)]
                length = TRAIN_LENGTHS[((step-1)//len(TASKS)) % len(TRAIN_LENGTHS)]
                if task == 'legacy':
                    x,y = legacy_batch(args.batch,length,train_rng,device)
                else:
                    x,y = new_batch(args.batch,length,task,train_rng,device)
                model.train()
                optimizer.zero_grad(set_to_none=True)
                logits,_ = model.sequence(x,mode='full')
                loss = F.binary_cross_entropy_with_logits(logits,y)
                if not bool(torch.isfinite(loss).item()): raise SafetyStop('NONFINITE_LOSS')
                loss.backward()
                norm = torch.nn.utils.clip_grad_norm_(model.parameters(),1.0,error_if_nonfinite=True)
                if not bool(torch.isfinite(norm).item()): raise SafetyStop('NONFINITE_GRADIENT')
                optimizer.step()
                model.enforce_constraints()
                done = step
                if step==1 or step % 25 == 0 or step == args.steps:
                    row = {'step':step,'task':task,'length':length,
                           'train_bce':round(loss.item(),6),
                           'gpu_temp_c':telemetry.get('gpu_temp_c')}
                    print('STEP ' + json.dumps(row),flush=True)
                    append_event(out,row)
                if step % args.checkpoint_every == 0:
                    save_checkpoint(out,model,optimizer,train_rng,step=done,cfg=cfg,
                                    device=device,initial=initial,run_id=run_id)
            guard.poll()
        except (SafetyStop,RuntimeError,KeyboardInterrupt) as exc:
            reason = 'CTRL_C' if isinstance(exc,KeyboardInterrupt) else str(exc)
            if not (out / f'checkpoint_step_{done:06d}.pt').is_file():
                try: save_checkpoint(out,model,optimizer,train_rng,step=done,cfg=cfg,
                                     device=device,initial=initial,run_id=run_id)
                except Exception as save_exc: reason += '; CHECKPOINT_FAILED: ' + str(save_exc)
            append_event(out,{'event':'stopped','at_step':done,'reason':reason})
            print('STOPPED ' + reason, file=sys.stderr, flush=True)
            return 2
    final_name = out/f'metrics_step_{done:06d}.json'
    if final_name.is_file():
        print('ALREADY_COMPLETE; no files overwritten',flush=True)
        return 0
    if not (out/f'checkpoint_step_{done:06d}.pt').is_file():
        save_checkpoint(out,model,optimizer,train_rng,step=done,cfg=cfg,
                        device=device,initial=initial,run_id=run_id)
    print('FINAL unseen-seed evaluation',flush=True)
    try:
        after = evaluate(model,guard,device,seed=args.seed+2000,
                         n=args.eval_samples,batch=args.eval_batch,lengths=EVAL_LENGTHS)
        guard.poll()
    except (SafetyStop, KeyboardInterrupt) as exc:
        append_event(out,{'event':'final_eval_interrupted','reason':str(exc)})
        print('STOPPED final evaluation; checkpoint is saved. Use RESUME.',file=sys.stderr)
        return 2
    weight_file = out/f'weights_step_{done:06d}_research_only.pt'
    if weight_file.exists():
        # If interrupted after writing the weights, verify and reuse the same
        # immutable file rather than overwriting it.
        sha_path = weight_file.with_suffix('.sha256.json')
        if not sha_path.is_file(): raise InputError('FINAL_WEIGHTS_WITHOUT_SHA_MANIFEST')
        metadata = json.loads(sha_path.read_text(encoding='utf-8'))
        weight_sha = digest(weight_file)
        if metadata.get('file') != weight_file.name or metadata.get('sha256') != weight_sha:
            raise InputError('FINAL_WEIGHTS_SHA_MISMATCH')
    else:
        torch.save({k:v.detach().cpu() for k,v in model.state_dict().items()},weight_file)
        weight_sha = digest(weight_file)
        save_json_new(weight_file.with_suffix('.sha256.json'),{'file':weight_file.name,'sha256':weight_sha})
    report = {'study':STUDY,'status':'RESEARCH_ONLY','complete':True,
        'step':done,'device':str(device),'model_parameters':sum(p.numel() for p in model.parameters()),
        'weights_file':weight_file.name,'weights_sha256':weight_sha,
        'baseline':initial,'final':after,
        'max_row_l1_violation':model.max_violation(),
        'peak_pytorch_cuda_allocated_mib':(round(torch.cuda.max_memory_allocated(device)/1048576,2)
                                           if device.type=='cuda' else None),
        'highest_polled_temperature_c':guard.highest_temp,
        'highest_polled_gpu_used_mib':guard.highest_used,
        'limitations':['small 399361-parameter experimental S4/S5','3 numeric channels; no language',
                       'no learned S6; prefix1 is fixed comparator','synthetic independent examples only',
                       'new Adam optimizer (continuing weights not optimizer)',
                       'periodic telemetry cannot guarantee hardware safety',
                       'not a proof of general intelligence or Android parity']}
    save_json_new(final_name,report)
    append_event(out,{'event':'complete','step':done,'weights_sha256':weight_sha})
    summary = {'step':done,'legacy_24':after['legacy']['24']['full']['accuracy'],
               'indexed_48':after['indexed']['48']['full']['accuracy'],
               'overwrite_48':after['overwrite']['48']['full']['accuracy'],
               'order_48':after['order']['48']['full']['accuracy'],
               'weights_sha256':weight_sha}
    print('FINAL ' + json.dumps(summary),flush=True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', choices=('cuda','cpu'), default='cuda')
    parser.add_argument('--output',required=True)
    parser.add_argument('--init-weights',default=r'D:\OwnNeuralNet\uno_f_memory_003_gpu\weights_step_000060_research_only.pt')
    parser.add_argument('--expected-init-sha',default=EXPECTED_PARENT_SHA)
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--steps',type=int,default=240)
    parser.add_argument('--batch',type=int,default=24)
    parser.add_argument('--lr',type=float,default=.0004)
    parser.add_argument('--seed',type=int,default=47)
    parser.add_argument('--eval-samples',type=int,default=192)
    parser.add_argument('--eval-batch',type=int,default=48)
    parser.add_argument('--checkpoint-every',type=int,default=20)
    parser.add_argument('--max-temp',type=float,default=80.)
    parser.add_argument('--max-gpu-used-mib',type=int,default=7000)
    parser.add_argument('--max-seconds',type=float,default=600.)
    args = parser.parse_args()
    try: return run(args)
    except (InputError,SafetyStop,OSError,ValueError,RuntimeError) as exc:
        print('ERROR: '+str(exc),file=sys.stderr,flush=True)
        return 1

if __name__ == '__main__': sys.exit(main())
