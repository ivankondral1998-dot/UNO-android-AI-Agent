"""Read-only diagnosis of MEMORY-004 training path and deterministic memory protocol."""
import torch
from uno_f_pilot import UnoF
from uno_diag_fix_005 import diag_no_memory, exact_bank_reference, seeded_batch, build_bank


def main():
    torch.manual_seed(17)
    device = torch.device('cpu')
    net = UnoF()
    probe = diag_no_memory(net, device)
    assert probe['Wq_grad'] == 'NONE', probe
    assert probe['Wr_grad_max_abs'] == 0.0, probe
    print('PASS 004_UNUSED_MEMORY', probe, flush=True)

    for task in ('indexed', 'overwrite', 'order'):
        for length in (12, 24, 48, 96):
            x, y = seeded_batch(task, 64, length, seed=111+length, device=device)
            result = exact_bank_reference(x)
            assert torch.equal(result, y), (task, length)
            print('PASS ADDRESSED_MEMORY', task, length, flush=True)
    print('DIAG_005_PASS=13', flush=True)

if __name__ == '__main__':
    main()
