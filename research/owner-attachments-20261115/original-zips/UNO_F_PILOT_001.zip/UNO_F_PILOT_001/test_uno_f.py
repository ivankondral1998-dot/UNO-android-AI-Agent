import math
import torch
from uno_f_pilot import UnoF,project_l1_,make_batch

def test():
    torch.manual_seed(11);torch.set_num_threads(2)
    m=UnoF().double()
    assert m.max_violation()<=1e-6
    a=torch.tensor([[2.0,1.0],[-2.,-1.]],dtype=torch.double)
    project_l1_(a,1.0)
    assert torch.allclose(a,torch.tensor([[1.,0.],[-1.,0.]],dtype=torch.double),atol=1e-14)
    x=torch.tensor([[.7,0.,0.]],dtype=torch.double);s=torch.zeros(1,128,dtype=torch.double)
    z0=torch.tanh(m.E(x)+m.Us(s)+m.Ug(s)+m.Wmeta(x.new_zeros(1,32))+m.e+m.bz)
    with torch.no_grad():
        m.Wr.weight.zero_()
    h,trace=m.forward_event(x,s,[True,False],steps=2)
    # S4 with empty memory must still do second tanh.
    assert torch.allclose(h[:,64:],.5*torch.tanh(z0)[:,64:])
    assert not torch.allclose(torch.tanh(z0),z0,atol=1e-8)
    assert trace=={"A":4,"B":4,"C":2,"skipped_blocks":1,"K":2}
    assert m.forward_event(x,s,[True,True],steps=2)[1]=={"A":8,"B":8,"C":4,"skipped_blocks":0,"K":2}
    # If block 1 is OFF, perturbing only its expensive parameters cannot change the output.
    before=m.forward_event(x,s,[True,False],steps=2)[0]
    with torch.no_grad():m.branches[0][1].A.weight[0,0]+=.01
    after=m.forward_event(x,s,[True,False],steps=2)[0]
    assert torch.equal(before,after)
    with torch.no_grad():m.branches[0][1].A.weight[0,0]-=.01
    # Reverse S5 gradient vs central finite difference for a shared A coefficient (K2).
    p=m.branches[0][0].A.weight
    m.zero_grad(set_to_none=True)
    objective=(m.forward_event(x,s,[True,False],steps=2)[0]*torch.arange(1,129,dtype=torch.double).view(1,-1)/128).sum()
    objective.backward();analytic=p.grad[0,0].item();orig=p[0,0].item();eps=1e-5
    with torch.no_grad():p[0,0]=orig+eps
    plus=(m.forward_event(x,s,[True,False],steps=2)[0]*torch.arange(1,129,dtype=torch.double).view(1,-1)/128).sum().item()
    with torch.no_grad():p[0,0]=orig-eps
    minus=(m.forward_event(x,s,[True,False],steps=2)[0]*torch.arange(1,129,dtype=torch.double).view(1,-1)/128).sum().item()
    with torch.no_grad():p[0,0]=orig
    numeric=(plus-minus)/(2*eps)
    assert math.isclose(analytic,numeric,rel_tol=1e-4,abs_tol=2e-9),(analytic,numeric)
    # No expensive work/gradients at an inactive block.
    m.zero_grad(set_to_none=True)
    m.forward_event(x,s,[True,False],steps=2)[0].sum().backward()
    assert m.branches[0][1].A.weight.grad is None
    # Memory singleton gives zero Wq influence, yet S4 memory contributes via Wr.
    # The single memory entry score is irrelevant because softmax([v]) == 1.
    keys=torch.ones(1,1,128,dtype=torch.double)
    values=torch.ones_like(keys)*.25
    m.zero_grad(set_to_none=True)
    m.forward_event(x,s,[True,True],steps=2,keys=keys,values=values)[0].sum().backward()
    grad=m.Wq.weight.grad
    assert grad is None or grad.abs().max().item()<1e-12
    assert m.max_violation() <= 0.02 # slight finite-difference perturbation restored
    # Two independent RNG streams give different examples.
    r1=torch.Generator().manual_seed(100);r2=torch.Generator().manual_seed(200)
    b1,y1=make_batch(64,r1,torch.device('cpu'));b2,y2=make_batch(64,r2,torch.device('cpu'))
    assert not torch.equal(b1,b2)
    # ASTRA W2 exact geometry.
    d=1024;V=32768;mm=128;bb=64;chi=4;J=2;H=902
    p_count=V*d+951*d+2*d*d+4*mm*d+J*(2*chi*d*d+chi*bb*d+(chi+1)*d)+H*(d+1)+V+(d//bb)*(2*d+5)+33
    assert p_count==55451639
    print('UNO_F_PILOT_TESTS_PASS=9')
if __name__=='__main__':test()
