"""Verify the independent research-only state_dict checkpoint (never execute pickle code)."""
import hashlib
import json
import sys
from pathlib import Path

import torch
from uno_f_pilot import UnoF, evaluate

if __name__ == "__main__":
    w = Path(sys.argv[1]) if len(sys.argv)>1 else Path("cpu_trial/weights_research_only.pt")
    mpath = Path(sys.argv[2]) if len(sys.argv)>2 else w.with_name("metrics.json")
    manifest = json.loads(mpath.read_text(encoding="utf-8"))
    computed = hashlib.sha256(w.read_bytes()).hexdigest()
    assert computed == manifest["weights_sha256"], "SHA256 MISMATCH"
    state = torch.load(w,map_location="cpu",weights_only=True)
    model=UnoF().cpu(); model.load_state_dict(state,strict=True)
    assert model.max_violation() < 1e-5,"ROW-L1 CAP VIOLATION"
    result = evaluate(model,torch.device("cpu"),seed=manifest["config"]["seed"]+2000,
                      n=1024,mode="full",task=manifest["config"]["task"])
    assert abs(result["accuracy"]-manifest["final_full"]["accuracy"])<0.02,"EVAL DIVERGED"
    print("WEIGHTS_SHA256_PASS="+computed)
    print("RESTORED_MODEL_ACCURACY="+str(result["accuracy"]))
    print("ROW_L1_CAP_PASS=1")
