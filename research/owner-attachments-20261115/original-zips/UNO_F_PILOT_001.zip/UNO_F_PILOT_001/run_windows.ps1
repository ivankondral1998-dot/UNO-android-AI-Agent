$ErrorActionPreference = "Stop"
$python = "D:\OwnNeuralNet\.venv\Scripts\python.exe"
if (!(Test-Path $python)) { throw "Не найден Python: $python" }
$env:TEMP = "D:\OwnNeuralNet\tmp"
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Set-Location $PSScriptRoot
& $python test_uno_f.py
if ($LASTEXITCODE -ne 0) { throw "Проверки F не прошли" }
& $python uno_f_pilot.py --device cuda --steps 150 --batch 64 --task delayed --output "D:\OwnNeuralNet\uno_f_pilot_001_gpu" --bench-repeats 50
if ($LASTEXITCODE -ne 0) { throw "Обучение завершилось ошибкой" }
