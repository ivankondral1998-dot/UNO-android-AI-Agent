$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
Get-Content .\SHA256SUMS.txt | ForEach-Object {
    $line = $_.Trim()
    if ($line -eq '') { return }
    $parts = $line -split '\s+',2
    if ($parts.Count -ne 2) { throw "Bad manifest line: $line" }
    $actual = (Get-FileHash -LiteralPath (Join-Path $root $parts[1].Trim()) -Algorithm SHA256).Hash
    if ($actual.ToLowerInvariant() -ne $parts[0].ToLowerInvariant()) { throw "HASH MISMATCH: $($parts[1])" }
    Write-Host "HASH PASS: $($parts[1])"
}
