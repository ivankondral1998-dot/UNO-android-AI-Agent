@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "SRC=D:\OwnNeuralNet\uno_f_pilot_001_gpu"
set "OUT=D:\OwnNeuralNet\uno_gpu_safe_002_fp32"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python venv not found & goto FAIL)
if not exist "%SRC%\weights_research_only.pt" (echo ERROR: original weights not found & goto FAIL)
if not exist "%SRC%\metrics.json" (echo ERROR: original metrics not found & goto FAIL)
if exist "%OUT%\run_manifest.json" (echo REFUSED: output run already exists, do not overwrite & goto FAIL)
"%PY%" uno_gpu_safe.py --device cuda --precision fp32 --steps 50 --batch 64 --lr 0.0005 --checkpoint-every 10 --monitor-every 5 --max-temp 80 --max-gpu-used-mib 7000 --max-seconds 600 --init-weights "%SRC%\weights_research_only.pt" --init-metrics "%SRC%\metrics.json" --output "%OUT%"
if errorlevel 1 goto FAIL
echo.
echo SUCCESS: %OUT%
pause
exit /b 0
:FAIL
echo.
echo STOPPED OR REFUSED: read error details above. Previous weights remain untouched.
pause
exit /b 1
