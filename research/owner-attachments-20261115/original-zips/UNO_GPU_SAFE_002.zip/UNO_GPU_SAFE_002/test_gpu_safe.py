"""CPU-only regression checks; no access to user's RTX is implied."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

import torch

from uno_gpu_safe import (
    Guard, InputError, SafetyStop, digest, load_checkpoint, parse_smi_output,
    valid_init_weights, main,
)


class SafetyTests(unittest.TestCase):
    def test_smi_parser(self):
        self.assertEqual(parse_smi_output('45, 1234, 8192, 99.5\n')['gpu_used_mib'], 1234)
        self.assertIsNone(parse_smi_output('45, 1234, 8192, N/A')['gpu_power_w'])
        with self.assertRaises(SafetyStop):
            parse_smi_output('N/A, 100, 8192, 50')

    def test_temperature_cutoff(self):
        fake = Mock(returncode=0, stdout='80, 300, 8192, 50\n', stderr='')
        with patch('uno_gpu_safe.subprocess.run', return_value=fake):
            with self.assertRaisesRegex(SafetyStop, 'TEMPERATURE_LIMIT'):
                Guard(torch.device('cuda'), max_temp=80, max_gpu_used_mib=7000, max_seconds=100).poll()

    def test_vram_cutoff(self):
        fake = Mock(returncode=0, stdout='60, 7000, 8192, 50\n', stderr='')
        with patch('uno_gpu_safe.subprocess.run', return_value=fake):
            with self.assertRaisesRegex(SafetyStop, 'MEMORY_LIMIT'):
                Guard(torch.device('cuda'), max_temp=80, max_gpu_used_mib=7000, max_seconds=100).poll()

    def test_mon_fail_closed(self):
        with patch('uno_gpu_safe.subprocess.run', side_effect=FileNotFoundError()):
            with self.assertRaisesRegex(SafetyStop, 'MONITOR_UNAVAILABLE'):
                Guard(torch.device('cuda'), max_temp=80, max_gpu_used_mib=7000, max_seconds=100).poll()

    def test_cpu_resume_equals_uninterrupted(self):
        # Train 4 updates uninterrupted, and 2 then resume to 4. No checkpoint
        # identity trick: compare independent runs' final tensor values.
        from uno_gpu_safe import train
        from argparse import Namespace
        def args(path, steps, resume=None):
            return Namespace(device='cpu', precision='fp32', output=str(path),
                  steps=steps, batch=8, lr=0.0005, task='delayed', seed=1234,
                  checkpoint_every=2, monitor_every=1, log_every=2,
                  max_temp=80., max_gpu_used_mib=7000, max_seconds=1800.,
                  resume=str(resume) if resume else None,
                  init_weights=None, init_metrics=None)
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / 'all', Path(tmp) / 'split'
            self.assertEqual(train(args(a,4)), 0)
            self.assertEqual(train(args(b,2)), 0)
            self.assertEqual(train(args(b,4,b/'checkpoint_step_000002.pt')), 0)
            ca = torch.load(a/'checkpoint_step_000004.pt', weights_only=True)
            cb = torch.load(b/'checkpoint_step_000004.pt', weights_only=True)
            self.assertEqual(ca['step'], cb['step'])
            for key in ca['model']:
                self.assertTrue(torch.equal(ca['model'][key], cb['model'][key]), key)
            # No silent overwrite and wrong owner run checks.
            with self.assertRaisesRegex(InputError, 'BELONGS_TO_ANOTHER_RUN'):
                load_checkpoint(a/'checkpoint_step_000004.pt',
                    device=torch.device('cpu'), cfg=ca['config'], run_id=cb['run_id'])
            with self.assertRaisesRegex(InputError, 'OUTPUT_ALREADY_CONTAINS_FILES'):
                train(args(a,2))
            # Corrupt a COPY and make sure checksum gate rejects it.
            clone=b/'corrupt.pt'
            clone.write_bytes((b/'checkpoint_step_000002.pt').read_bytes()+b'X')
            clone.with_suffix('.sha256.json').write_text((b/'checkpoint_step_000002.sha256.json').read_text())
            with self.assertRaisesRegex(InputError, 'SHA_MISMATCH'):
                load_checkpoint(clone, device=torch.device('cpu'),
                    cfg=ca['config'], run_id=cb['run_id'])

    def test_legacy_weights_sha(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)
            path=folder/'old.pt'
            torch.save({'x':torch.tensor([1.])}, path)
            m=folder/'metrics.json'
            m.write_text(json.dumps({'weights_sha256':digest(path)}))
            original = valid_init_weights(path,m,torch.device('cpu'))
            self.assertTrue(torch.equal(original['x'],torch.tensor([1.])))
            m.write_text(json.dumps({'weights_sha256':'bad'}))
            with self.assertRaisesRegex(InputError, 'SHA_MISMATCH'):
                valid_init_weights(path,m,torch.device('cpu'))

if __name__=='__main__':
    unittest.main(verbosity=2)
