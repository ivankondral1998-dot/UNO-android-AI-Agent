@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
set "OUT=D:\OwnNeuralNet\uno_ladder_005_gpu"
cd /d "%~dp0"
if not exist "%PY%" (echo ERROR: Python missing: %PY% & goto FAIL)
"%PY%" uno_ladder_005.py --device cuda --out "%OUT%" --steps 4000 --batch 256 --eval-samples 2048 --max-temp 80 --max-gpu-used-mib 7000 --max-minutes 90
if errorlevel 1 goto FAIL
echo.
echo DONE. See %OUT%\SUMMARY.txt . If it says TIME LIMIT, just run this file again: finished runs are skipped.
pause
exit /b 0
:FAIL
echo.
echo STOPPED. Finished runs are kept; run again to continue.
pause
exit /b 1
