@echo off
setlocal
set "PY=D:\OwnNeuralNet\.venv\Scripts\python.exe"
cd /d "%~dp0"
"%PY%" -m unittest -v test_ladder_005
if errorlevel 1 (echo TESTS FAILED & pause & exit /b 1)
echo TESTS PASSED
pause
