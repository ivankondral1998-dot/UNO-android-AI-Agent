@echo off
cd /d "%~dp0"
"D:\OwnNeuralNet\.venv\Scripts\python.exe" check_owner_weights_005.py
set CODE=%ERRORLEVEL%
echo.
if not "%CODE%"=="0" echo CHECK FAILED (exit %CODE%)
if "%CODE%"=="0" echo CHECK FINISHED. No weights were changed.
pause
exit /b %CODE%
