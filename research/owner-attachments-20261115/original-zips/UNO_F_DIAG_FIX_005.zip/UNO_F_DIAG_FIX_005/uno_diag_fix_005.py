"""UNO F diagnostic/fix 005. Experimental external 4-key memory plus S4 read.

Not a full learned memory controller, not production UNO, does not modify 003/004.
The memory write/address protocol is deterministic for this three-channel synthetic task.
The S4 query/read pathway and new task head are trained. The original F and legacy
head are preserved. Input labels are never used to construct the memory bank.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import secrets
import sys
import time

import torch
from torch import nn
from torch.nn import functional as F

from uno_f_pilot import UnoF
from uno_working_memory import new_batch, legacy_batch, init_verified
from uno_gpu_safe import Guard, InputError, SafetyStop, append_event, digest, load_checkpoint, save_checkpoint, save_json_new, utc

SOURCE_SHAS = {
    'uno_f_pilot.py': 'd290ff97eb9c58fd609d97a3c74c2a06c2b5fc0a561a3c9489776e9f8913046a',
    'uno_gpu_safe.py': '2f4e9d95ad5c9bf0ff699fc5dbacd1b55d506efc40b74063e2cd60f277f6f952',
    'uno_working_memory.py': 'cb40043d91facb622736525bc5753ddc86a6d5fb5cae678aca4c44a792edd4f1',
}
OWNER_PARENT_SHA = '5e5ef81096fabc75be82e3f6498165ed4389a12f5468d3de720110de2533fdde'
OWNER_004_SHA = '6f4f3a917a0000d8e4ac041a90beed3b75b5d2ef6d8d2657a2744d5a4bc8ca99'
NEW_TASKS = ('indexed','overwrite','order')


def verify_sources():
    for name, expected in SOURCE_SHAS.items():
        real = digest(Path(__file__).parent/name)
        if real != expected:
            raise InputError(f'REFUSED_SOURCE_MISMATCH: {name}: {real}')


def build_bank(x:torch.Tensor, *, erase:bool=False):
    """Deterministic event-addressed bank, no labels, no trainable write controller.

    Three values reside in slots -1/0/+1. A fourth record stores last written
    slot identity for the `order` task. A write overwrites earlier slot value.
    All bank updates use only the observed op/slot/value channels, never y.
    """
    if x.ndim!=3 or x.shape[-1]!=3 or x.shape[1]<3:
        raise ValueError('BAD_INPUT_TO_BANK')
    batch, length, _ = x.shape
    device = x.device
    codes=x.new_tensor([-1.,0.,1.])
    mem=x.new_zeros((batch,4,128))
    # Keep a validity mask to prevent distractors updating the bank.
    for t in range(length-1):
        f=x[:,t]
        writing = f[:,2] > .5
        addr = (f[:,1,None]-codes[None,:]).abs().argmin(1)
        for j in range(3):
            take=writing & (addr==j)
            mem[:,j,0]=torch.where(take,f[:,0],mem[:,j,0])
        mem[:,3,0]=torch.where(writing,codes[addr],mem[:,3,0])
    keys=x.new_zeros((batch,4,128))
    for j in range(4):
        keys[:,j,j]=8*math.sqrt(128)
    return keys,mem


def exact_bank_reference(x:torch.Tensor):
    """Answer sign using only event-addressed memory. Mechanistic upper bound."""
    _,values=build_bank(x)
    code=x[:,-1,1]
    is_order=x[:,-1,2]<-1.5
    slot=(code[:,None]-code.new_tensor([-1.,0.,1.])[None,:]).abs().argmin(1)
    selected=values[torch.arange(x.shape[0],device=x.device),slot,0]
    selected=torch.where(is_order,values[:,3,0],selected)
    return (selected>0).float()


class MemoryFix(nn.Module):
    def __init__(self):
        super().__init__()
        self.core=UnoF()
        self.new_head=nn.Linear(self.core.d+1,1)
        with torch.no_grad():
            self.new_head.weight.zero_()
            self.new_head.weight[0,-1]=1.
        # Frozen old F and frozen old head: retained skill has no training path.
        for p in self.core.parameters(): p.requires_grad_(False)
        # S4 query and semantic read can be trained without touching old F.
        self.core.Wq.weight.requires_grad_(True)
        self.core.Wr.weight.requires_grad_(True)
        nn.init.zeros_(self.new_head.bias)

    def forward_new(self,x:torch.Tensor,*, zero_memory=False,return_attention=False):
        if x.ndim!=3 or x.shape[-1]!=3: raise ValueError('SHAPE')
        # The frozen recurrent prefix does not depend on Wq/Wr because its
        # memory is empty: this no_grad path is exact for trainable parameters.
        with torch.no_grad():
            s=x.new_zeros((x.shape[0],self.core.d))
            for t in range(x.shape[1]-1):
                s,_=self.core.forward_event(x[:,t],s,[True]*self.core.nb)
        keys,values=build_bank(x)
        if zero_memory:
            values=torch.zeros_like(values)
        h,_=self.core.forward_event(x[:,-1],s,[True]*self.core.nb,keys=keys,values=values)
        f=x[:,-1]
        z0=torch.tanh(self.core.E(f)+self.core.Us(s)+self.core.e+self.core.bz)
        query=torch.tanh(self.core.Wq(z0))
        attention_scores=(keys*query[:,None,:]).sum(-1)/math.sqrt(self.core.m)
        reading=(attention_scores.softmax(dim=1)[:,:,None]*values).sum(dim=1)
        # Experimental *separate memory readout*, not an Astra-approved production head.
        logits=self.new_head(torch.cat([h,reading[:,:1]],dim=1)).squeeze(-1)
        if return_attention:
            slot=(f[:,1,None]-f.new_tensor([-1.,0.,1.])[None,:]).abs().argmin(1)
            target=torch.where(f[:,2]<-1.5,torch.full_like(slot,3),slot)
            return logits,attention_scores,target
        return logits

    def forward_legacy(self,x:torch.Tensor):
        with torch.inference_mode():
            return self.core.sequence(x)[0]

    def enforce(self):
        # Project ONLY trainable rows. The original recurrent F and head are byte-stable.
        from uno_f_pilot import project_l1_
        project_l1_(self.core.Wq.weight,2.)
        project_l1_(self.core.Wr.weight,2.)
        project_l1_(self.new_head.weight,8.)
        with torch.no_grad():self.new_head.bias.clamp_(-8,8)


def seeded_batch(task,batch,length,seed,device,erased=False):
    gen=torch.Generator(device='cpu').manual_seed(seed)
    if task=='legacy':return legacy_batch(batch,length,gen,device)
    return new_batch(batch,length,task,gen,device,erase_target=erased)


def evaluate(model,guard,device,*,seed,n=192,lengths=(12,24,48,96)):
    model.eval()
    out={}
    with torch.inference_mode():
        for task in (*NEW_TASKS,'legacy'):
            out[task]={}
            for length in (lengths if task!='legacy' else (24,)):
                guard.poll()
                total=correct=0
                loss_sum=0.
                correct_exact=0
                for offset in range(0,n,48):
                    b=min(48,n-offset)
                    x,y=seeded_batch(task,b,length,seed+length*101+offset+NEW_TASKS.index(task) * 100003 if task!='legacy' else seed+80124+offset,device)
                    if task=='legacy': logits=model.forward_legacy(x)
                    else:
                        logits=model.forward_new(x)
                        correct_exact+=int((exact_bank_reference(x)==y).sum().item())
                    correct+=int(((logits>=0)==(y>=.5)).sum().item())
                    loss_sum+=float(F.binary_cross_entropy_with_logits(logits,y,reduction='sum').item())
                    total+=b
                out[task][str(length)]={'accuracy':correct/total,'bce':loss_sum/total,'samples':total}
                if task!='legacy':out[task][str(length)]['exact_bank_reference']=correct_exact/total
                row={'task':task,'length':length,'accuracy':round(correct/total,4)}
                if task!='legacy':row['exact_bank_reference']=round(correct_exact/total,4)
                print('EVAL '+json.dumps(row),flush=True)
    return out


def diag_no_memory(core:UnoF,device:torch.device):
    """Directly establish whether Wq/Wr get a training signal in original 004."""
    core.train()
    x,y=seeded_batch('indexed',8,12,991,device)
    core.zero_grad(set_to_none=True)
    logits,_=core.sequence(x)
    F.binary_cross_entropy_with_logits(logits,y).backward()
    wq=core.Wq.weight.grad
    wr=core.Wr.weight.grad
    return {'original_004_passes_keys_values':False,
            'Wq_grad':('NONE' if wq is None else float(wq.detach().abs().max().item())),
            'Wr_grad_max_abs':('NONE' if wr is None else float(wr.detach().abs().max().item())),
            'reason':'sequence() calls forward_event() without keys and values; r=0'}


def check_old(core,old:torch.Tensor,device):
    core.eval()
    x,_=seeded_batch('legacy',20,24,9912,device)
    with torch.inference_mode():p=core.sequence(x)[0]
    return bool(torch.equal(old,p))


def run(args):
    verify_sources()
    if args.device=='cuda' and not torch.cuda.is_available(): raise InputError('CUDA_NOT_AVAILABLE')
    if not (1<=args.steps<=2000 and 1<=args.batch<=64 and 32<=args.eval_samples<=1024 and
            1<=args.checkpoint_every<=1000 and 0<args.lr<=.005 and 30<=args.max_seconds<=3600):
        raise InputError('BAD_CONFIG')
    device=torch.device(args.device)
    torch.set_num_threads(min(4,torch.get_num_threads()))
    torch.manual_seed(args.seed)
    if device.type=='cuda':torch.cuda.manual_seed_all(args.seed)
    guard=Guard(device,max_temp=80,max_gpu_used_mib=7000,max_seconds=args.max_seconds)
    guard.poll()
    if device.type=='cuda':
        mib=torch.cuda.get_device_properties(0).total_memory/1048576
        free=7000-(guard.highest_used or 0)-256
        if free<512:raise SafetyStop('INSUFFICIENT_FREE_VRAM')
        torch.cuda.set_per_process_memory_fraction(min(.95,free/mib),0)
    model=MemoryFix().to(device)
    opt=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=args.lr)
    rng=torch.Generator(device='cpu').manual_seed(args.seed+101)
    out=Path(args.output).resolve()
    conf={'study':'UNO_005_ISOLATED_S4_MEMORY_FIX','source_sha':digest(Path(__file__)),
          'model_source_sha':SOURCE_SHAS,'init_sha':args.expected_sha,'steps':args.steps,
          'batch':args.batch,'lr':args.lr,'seed':args.seed,'eval_samples':args.eval_samples,
          'checkpoint_every':args.checkpoint_every}
    done=0
    if args.resume:
        manifest_file=out/'run_manifest.json'
        if not manifest_file.is_file():raise InputError('NO_PREVIOUS_RUN_TO_RESUME')
        manifest=json.loads(manifest_file.read_text(encoding='utf-8'))
        if manifest.get('config')!=conf:raise InputError('RESUME_CONFIG_MISMATCH')
        run_id=manifest['run_id']
        checkpoints=sorted(out.glob('checkpoint_step_*.pt'))
        if not checkpoints:raise InputError('NO_CHECKPOINT_TO_RESUME')
        chk=load_checkpoint(checkpoints[-1],device=device,cfg=conf,run_id=run_id)
        model.load_state_dict(chk['model'],strict=True)
        opt.load_state_dict(chk['optimizer'])
        rng.set_state(chk['train_generator_state'])
        torch.set_rng_state(chk['torch_cpu_rng_state'].cpu())
        if device.type=='cuda':torch.cuda.set_rng_state(chk['torch_cuda_rng_state'].cpu(),device)
        done=chk['step']
        before=chk['initial']
        print('RESUME '+json.dumps({'step':done}),flush=True)
    else:
        if out.is_dir() and any(out.iterdir()):raise InputError('OUTPUT_NOT_EMPTY')
        src_sha=init_verified(model.core,Path(args.init_weights),expected_sha=args.expected_sha)
        # Reusing the core's output head on legacy must remain bit-identical.
        print('DIAG '+json.dumps(diag_no_memory(model.core,device)),flush=True)
        print('BASELINE (old pretrained core + untrained separate memory head)',flush=True)
        before=evaluate(model,guard,device,seed=args.seed+5000,n=args.eval_samples)
        out.mkdir(parents=True,exist_ok=True)
        run_id=secrets.token_hex(12)
        save_json_new(out/'run_manifest.json',{'run_id':run_id,'config':conf,
            'source_weights':str(args.init_weights),'source_weights_sha256':src_sha,
            'note':'3-slot bank deterministic write, 4th last-slot record, S4 read learned; F frozen'})
        save_json_new(out/'baseline.json',before)
        save_checkpoint(out,model,opt,rng,step=0,cfg=conf,device=device,initial=before,run_id=run_id)
    # Store exact old legacy logits for immutable functionality assertion.
    x_legacy,_=seeded_batch('legacy',20,24,9912,device)
    with torch.inference_mode():old_legacy_logits=model.core.sequence(x_legacy)[0].clone()
    if done<args.steps:
        print('TRAIN '+json.dumps({'step':done,'target':args.steps,'device':str(device),
            'trainable':['core.Wq.weight','core.Wr.weight','new_head.weight','new_head.bias']}),flush=True)
        try:
            for step in range(done+1,args.steps+1):
                if step==done+1 or step%10==0:guard.poll()
                task=NEW_TASKS[(step-1)%3]
                length=(12,24,48)[((step-1)//3)%3]
                x,y=new_batch(args.batch,length,task,rng,device)
                opt.zero_grad(set_to_none=True)
                logits,attn,target=model.forward_new(x,return_attention=True)
                loss=F.binary_cross_entropy_with_logits(logits,y)+0.6*F.cross_entropy(attn,target)
                if not bool(torch.isfinite(loss).item()):raise SafetyStop('NONFINITE_LOSS')
                loss.backward()
                norm=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.,error_if_nonfinite=True)
                if not bool(torch.isfinite(norm).item()):raise SafetyStop('NONFINITE_GRADIENT')
                opt.step()
                model.enforce()
                done=step
                if step==1 or step%25==0 or step==args.steps:
                    row={'step':step,'task':task,'length':length,'bce':round(float(loss.item()),6)}
                    print('STEP '+json.dumps(row),flush=True);append_event(out,row)
                if step%args.checkpoint_every==0:
                    save_checkpoint(out,model,opt,rng,step=step,cfg=conf,device=device,initial=before,run_id=run_id)
            guard.poll()
        except (SafetyStop,KeyboardInterrupt,RuntimeError) as exc:
            msg='CTRL_C' if isinstance(exc,KeyboardInterrupt) else str(exc)
            if not (out/f'checkpoint_step_{done:06d}.pt').exists():
                try:save_checkpoint(out,model,opt,rng,step=done,cfg=conf,device=device,initial=before,run_id=run_id)
                except Exception as e:msg+='; CHECKPOINT_FAILED '+str(e)
            print('STOPPED '+msg,file=sys.stderr,flush=True)
            return 2
    final_path=out/f'metrics_step_{done:06d}.json'
    if final_path.exists():
        print('ALREADY_COMPLETE',flush=True);return 0
    if not (out/f'checkpoint_step_{done:06d}.pt').exists():
        save_checkpoint(out,model,opt,rng,step=done,cfg=conf,device=device,initial=before,run_id=run_id)
    print('FINAL evaluation',flush=True)
    try:after=evaluate(model,guard,device,seed=args.seed+5000,n=args.eval_samples)
    except (SafetyStop,KeyboardInterrupt):
        print('STOPPED final evaluation. Resume from saved checkpoint',flush=True);return 2
    with torch.inference_mode():
        new_legacy_logits=model.core.sequence(x_legacy)[0]
    exact_old_preserved=torch.equal(old_legacy_logits,new_legacy_logits)
    if not exact_old_preserved:raise InputError('FROZEN_LEGACY_PATH_CHANGED')
    filename=out/f'weights_step_{done:06d}_isolated_memory_research_only.pt'
    if filename.exists():
        saved=json.loads(filename.with_suffix('.sha256.json').read_text())
        if digest(filename)!=saved.get('sha256'):raise InputError('EXISTING_WEIGHTS_CORRUPTED')
        sha=saved['sha256']
    else:
        torch.save({k:v.detach().cpu() for k,v in model.state_dict().items()},filename)
        sha=digest(filename)
        save_json_new(filename.with_suffix('.sha256.json'),{'file':filename.name,'sha256':sha})
    report={'study':conf['study'],'completed':True,'model_parameters':sum(p.numel() for p in model.parameters()),
            'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
            'steps':done,'device':str(device),'before':before,'after':after,
            'legacy_logits_bit_identical_in_this_session':exact_old_preserved,
            'source_weights_sha256':conf['init_sha'],'result_weights_sha256':sha,
            'result_weights_file':filename.name,'core_row_violation':model.core.max_violation(),
            'temperature_peak_polled_c':guard.highest_temp,
            'warning':'deterministic memory write+address, no learned write gate, no Android integration; not full UNO'}
    save_json_new(final_path,report)
    print('FINAL '+json.dumps({'step':done,'legacy_before':before['legacy']['24']['accuracy'],
      'legacy_after':after['legacy']['24']['accuracy'],'new_12':{t:after[t]['12']['accuracy'] for t in NEW_TASKS},
      'new_48':{t:after[t]['48']['accuracy'] for t in NEW_TASKS},'legacy_exact':exact_old_preserved,
      'sha256':sha}),flush=True)
    return 0


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--init-weights',default=r'D:\OwnNeuralNet\uno_f_memory_003_gpu\weights_step_000060_research_only.pt')
    p.add_argument('--expected-sha',default=OWNER_PARENT_SHA)
    p.add_argument('--output',default=r'D:\OwnNeuralNet\uno_f_diag_fix_005_gpu')
    p.add_argument('--steps',type=int,default=450)
    p.add_argument('--batch',type=int,default=24)
    p.add_argument('--lr',type=float,default=.001)
    p.add_argument('--seed',type=int,default=67)
    p.add_argument('--eval-samples',type=int,default=192)
    p.add_argument('--checkpoint-every',type=int,default=50)
    p.add_argument('--max-seconds',type=int,default=600)
    p.add_argument('--resume',action='store_true')
    args=p.parse_args()
    try: return run(args)
    except (InputError,SafetyStop,RuntimeError,OSError,ValueError) as e:
        print('ERROR '+str(e),file=sys.stderr,flush=True)
        return 1
if __name__=='__main__':sys.exit(main())
