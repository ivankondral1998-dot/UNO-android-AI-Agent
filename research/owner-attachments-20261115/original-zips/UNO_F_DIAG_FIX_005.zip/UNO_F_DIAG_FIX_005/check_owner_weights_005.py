"""Read-only owner checkpoint comparison. Does not train or write files."""
import hashlib
import json
from pathlib import Path
import sys
import torch
from torch.nn import functional as F
from uno_f_pilot import UnoF
from uno_working_memory import new_batch, legacy_batch
from uno_diag_fix_005 import OWNER_PARENT_SHA, OWNER_004_SHA, diag_no_memory, verify_sources

BEFORE=Path(r'D:\OwnNeuralNet\uno_f_memory_003_gpu\weights_step_000060_research_only.pt')
AFTER=Path(r'D:\OwnNeuralNet\uno_f_working_memory_004_gpu\weights_step_000240_research_only.pt')

def load(path,expected):
    if not path.is_file():raise RuntimeError('FILE_NOT_FOUND '+str(path))
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=expected:raise RuntimeError('UNEXPECTED_SHA '+str(path)+' '+actual)
    manifest=path.with_suffix('.sha256.json')
    if not manifest.is_file():raise RuntimeError('MISSING_SHA_MANIFEST '+str(manifest))
    data=json.loads(manifest.read_text(encoding='utf-8'))
    if data.get('sha256')!=actual:raise RuntimeError('MANIFEST_SHA_MISMATCH '+str(path))
    model=UnoF()
    model.load_state_dict(torch.load(path,map_location='cpu',weights_only=True),strict=True)
    return model

def evaluate(model,task,length=24,n=256):
    model.eval()
    gen=torch.Generator().manual_seed(50005+length+{'legacy':0,'indexed':100000,'order':200000,'overwrite':300000}[task])
    acc=loss=0
    with torch.inference_mode():
        for start in range(0,n,32):
            b=min(32,n-start)
            if task=='legacy': x,y=legacy_batch(b,length,gen,torch.device('cpu'))
            else:x,y=new_batch(b,length,task,gen,torch.device('cpu'))
            logits,_=model.sequence(x)
            acc+=int(((logits>=0)==(y>=.5)).sum().item())
            loss+=float(F.binary_cross_entropy_with_logits(logits,y,reduction='sum').item())
    return {'accuracy':round(acc/n,4),'bce':round(loss/n,5)}

def main():
    torch.set_num_threads(min(4,torch.get_num_threads()))
    verify_sources()
    pre=load(BEFORE,OWNER_PARENT_SHA)
    post=load(AFTER,OWNER_004_SHA)
    base=pre.state_dict(); newer=post.state_dict()
    diff={k:float((newer[k]-base[k]).abs().max().item()) for k in base}
    print('CHECK SHA VERIFIED 003 AND 004',flush=True)
    print('CHECK Wq',diff.get('Wq.weight'),'Wr',diff.get('Wr.weight'),flush=True)
    print('CHECK TOP_CHANGED '+json.dumps(sorted(diff.items(),key=lambda kv:kv[1],reverse=True)[:8]),flush=True)
    print('CHECK MEMORY_PATH_GRADS '+json.dumps(diag_no_memory(pre,torch.device('cpu'))),flush=True)
    for task,length in (('legacy',24),('indexed',12),('overwrite',12),('order',12)):
        print('EVAL '+json.dumps({'task':task,'length':length,'before':evaluate(pre,task,length),
                                   'after':evaluate(post,task,length)}),flush=True)
    print('OWNER_WEIGHTS_DIAG_005_FINISHED_READ_ONLY',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('ERROR '+str(e),file=sys.stderr,flush=True)
        sys.exit(1)
